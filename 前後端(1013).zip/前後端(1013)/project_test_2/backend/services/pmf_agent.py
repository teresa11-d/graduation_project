# backend/services/pmf_agent.py
"""
PMF (Product-Market Fit) Agent — 即時客戶分析版
====================================================
把三份 notebook 的流程串成一次性、單次呼叫的 pipeline：

  1. keyword_analyse_final(...) 的關鍵字萃取
     -> 直接吃 extractor.py 已經萃取好的 content_text（不重新讀檔），
        丟給 Gemini 萃取 product_type / core_features / style /
        target_audience / trend_keywords / Long-tail_Keywords。
        （檔案本身的 PDF/Word 解析交給 file_reader.py 統一處理，
         這裡不重複做，做法跟 CopywritingAgent / MarketPriceAgent 一致）

  2. trend_score_analysis_final(...) 的市場熱度查詢
     -> 用 Gemini 萃取出的 trend_keywords 查 Google Trends；
        查無資料再改用 Long-tail_Keywords。
        方法順序：先 pytrends_modern，抓不到才試 trendspy。

  3. calculate_pmf_final(...) 的 PMF 四項指標合併
     -> (a) 同類近期成功率 / (d) 市場飽和度：查詢 zeczec_history.db
        (b) Google 趨勢：來自步驟 2
        (c) 爆款相似度：沒有 MongoDB/embedding 來源，先給預設中位數

這是給「客戶端即時分析」用的簡化版：
  - 不寫入任何資料庫 / CSV / checkpoint，跑一次、回傳一次結果即可。
  - 拿掉多金鑰輪替、斷路器、本地 NLP 備援等保護機制（之後要加可以再補）。
  - pytrends 呼叫邏輯（_mean_interest_from_df 等）與
    trend_score_analysis_final.ipynb 保持一致，只是拿掉保護層。
"""

import os
import re
import json
import sqlite3

import requests


# ========================================
# Gemini 設定
# ========================================
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL_NAME = "gemini-3.5-flash-lite"
GEMINI_REST_ENDPOINT = (
    "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
)

# ========================================
# Google Trends 設定（與 trend_score_analysis_final.ipynb 一致）
# ========================================
TRENDS_GEO = "TW"                 # 台灣地區搜尋熱度（ZecZec 是台灣平台）
TRENDS_TIMEFRAME = "today 12-m"   # 過去 12 個月
MAX_KEYWORDS_PER_QUERY = 5        # Google Trends 一次最多比較 5 個關鍵字


def _mean_interest_from_df(interest_df, keywords):
    """從 interest_over_time 的結果，算出這組關鍵字的平均搜尋熱度分數（0~100）"""
    if interest_df is None or interest_df.empty:
        return None
    cols = [c for c in keywords if c in interest_df.columns]
    if not cols:
        return None
    return float(interest_df[cols].mean().mean())


def _try_pytrends_modern(keywords):
    from pytrends_modern import TrendReq
    pytrends = TrendReq(hl="zh-TW", tz=480)
    pytrends.build_payload(kw_list=keywords, timeframe=TRENDS_TIMEFRAME, geo=TRENDS_GEO)
    interest_df = pytrends.interest_over_time()
    return _mean_interest_from_df(interest_df, keywords)


def _try_trendspy(keywords):
    from trendspy import Trends
    tr = Trends()
    interest_df = tr.interest_over_time(keywords, geo=TRENDS_GEO, timeframe=TRENDS_TIMEFRAME)
    return _mean_interest_from_df(interest_df, keywords)


def get_trend_score(keywords):
    """
    簡化版查詢（無多層防護、無 proxy）：
      - 只取前 MAX_KEYWORDS_PER_QUERY 個關鍵字
      - 先試 pytrends_modern，抓不到（例外或空結果）才試 trendspy
      - 回傳 (score, method)；全部失敗回傳 (None, None)
    """
    keywords = [k for k in keywords if k][:MAX_KEYWORDS_PER_QUERY]
    if not keywords:
        return None, None

    try:
        score = _try_pytrends_modern(keywords)
        if score is not None:
            return score, "pytrends_modern"
    except Exception:
        pass

    try:
        score = _try_trendspy(keywords)
        if score is not None:
            return score, "trendspy"
    except Exception:
        pass

    return None, None


def _clean_ocr_noise(text):
    """簡易清洗，去除亂碼字元、多餘空白（沿用原本 notebook 的邏輯）"""
    text = re.sub(r'[^\u4e00-\u9fff\w\s，。！？、：；「」【】（）\-]', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


# ========================================
# Prompt（與你提供的內容完全一致）
# ========================================
def _build_prompt(cleaned_text, has_images=False):
    image_note = ""
    if has_images:
        image_note = (
            "\n- 本次額外提供了此募資專案的產品圖片，請將圖片中呈現的「產品外觀、包裝、"
            "色彩、材質、使用情境」也一併納入判斷，讓 style、core_features、"
            "trend_keywords 與 Long-tail_Keywords 更貼近圖片中實際呈現的樣貌，"
            "而不要只依賴文字內容。\n"
        )

    prompt = f"""你是一個專業的群眾募資分析師。
以下是一個募資專案的內文（可能含有OCR識別錯誤）{"，並附上該專案的產品圖片" if has_images else ""}。

請注意：
- 忽略退款條款、物流出貨、客服聯絡、法律聲明等行政與免責文字。
- 專注於「這個產品的核心功能、應用場景、設計風格、獨特賣點 (USP) 或背景故事」。
- trend_keywords 必須是「台灣消費者在網購或尋找此類產品時，真正會輸入 Google 的大方向通用關鍵字」（例如：恐怖遊戲、獨立遊戲、解謎桌遊）。請絕對避免將專案特有的劇情、專有名詞或冷門詞彙（如：東歐、精神實驗）當作搜尋關鍵字，以免搜尋量為零。
- 請嚴格確保所有輸出的內容與關鍵字，都必須是『台灣在地化用語』與『繁體中文』，絕對不可出現簡體字。
- 請提供 5 個『長尾關鍵字（Long-tail Keywords）』。不要只輸出『寵物玩具』這種大範圍詞彙，請務必結合產品的『特殊材質（如貓草）』、『功能（如嗅聞、放電）』或『解決的痛點（如焦慮、無聊）』來生成，以符合實際消費者的搜尋習慣。{image_note}

請完全「根據下方的專案內文」進行客觀判斷，絕不可自行發明或套用無關的風格。只輸出以下JSON格式，不要輸出其他任何說明文字：

{{
  "product_type": "<填入精準的產品類型，例如判斷是桌遊、家電或背包>",
  "core_features": ["<填入實際提及的核心特色1>", "<填入實際提及的核心特色2>", "<填入實際提及的核心特色3>"],
  "style": "<萃取內文提及的視覺設計或整體風格，如無明確提及請填『無』>",
  "target_audience": "<填入最精準的目標客群描述>",
  "trend_keywords": ["<通用關鍵字1>", "<通用關鍵字2>", "<通用關鍵字3>"],
  "Long-tail_Keywords": ["<長尾關鍵字1>", "<長尾關鍵字2>", "<長尾關鍵字3>", "<長尾關鍵字4>", "<長尾關鍵字5>"]
}}

專案內文：
{cleaned_text}"""
    return prompt


# ========================================
# 呼叫 Gemini
# ========================================
def _post_gemini(payload):
    resp = requests.post(
        GEMINI_REST_ENDPOINT.format(model=GEMINI_MODEL_NAME),
        params={"key": GEMINI_API_KEY},
        json=payload,
        timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()
    text = data["candidates"][0]["content"]["parts"][0]["text"]
    return json.loads(text)


def extract_keywords_from_text(content_text: str) -> dict:
    """
    直接吃已經萃取好的文案文字（file_reader.py 解析 .docx/.pdf 之後的結果），
    送 Gemini 萃取關鍵字與特徵。跟 CopywritingAgent.analyze(text) 是同一種用法，
    不重新處理檔案格式，PDF/Word 的解析統一交給 file_reader.py 負責。

    回傳 Gemini 解析出的 dict：
      product_type / core_features / style / target_audience /
      trend_keywords / Long-tail_Keywords
    """
    cleaned = _clean_ocr_noise(content_text or "")
    prompt = _build_prompt(cleaned, has_images=False)
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseMimeType": "application/json",
            "temperature": 0.1,
        },
    }
    return _post_gemini(payload)


# ========================================
# PMFAgent：整合 (a)(d) 歷史資料庫 + (b) Google Trends + (c) 預設值
# ========================================
class PMFAgent:
    """負責處理即時客戶分析用的 PMF 四項指標（簡化版，不寫入任何資料庫）"""

    def __init__(self, db_path: str = "zeczec_history.db"):
        self.db_path = db_path

    def _compute_a_and_d(self, category: str) -> dict:
        """(a) 同類近期成功率 + (d) 市場飽和度：查詢歷史 SQLite"""
        result = {
            "pmf_a_recent_category_success_rate": 0.0,
            "pmf_d_market_saturation_count": 0,
        }
        if not os.path.exists(self.db_path):
            return result

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT 募資狀態 FROM projects_summary WHERE 次分類=?", (category,)
        )
        rows = cursor.fetchall()
        conn.close()

        if rows:
            success_count = sum(1 for r in rows if r[0] == "成功")
            result["pmf_a_recent_category_success_rate"] = round(success_count / len(rows), 4)
            result["pmf_d_market_saturation_count"] = len(rows)

        return result

    def _compute_b(self, gemini_result: dict) -> dict:
        """(b) Google 趨勢：先用 trend_keywords 查，查不到再用 Long-tail_Keywords"""
        trend_keywords = gemini_result.get("trend_keywords", []) or []
        long_tail_keywords = gemini_result.get("Long-tail_Keywords", []) or []

        score, method = get_trend_score(trend_keywords)
        if score is None and long_tail_keywords:
            score, method = get_trend_score(long_tail_keywords)

        return {
            "pmf_b_trend_level": round(score, 4) if score is not None else 0.0,
            "pmf_b_trend_source": method,  # 'pytrends_modern' / 'trendspy' / None
        }

    def analyze(self, category: str, content_text: str) -> dict:
        """
        主流程（取代原本三份 notebook）：
          1. extract_keywords_from_text()：用 Gemini 從已萃取的文案文字算出關鍵字與特徵
          2. self._compute_b()：用萃取出的關鍵字查 Google Trends
          3. self._compute_a_and_d()：查歷史資料庫算成功率/飽和度
          4. 合併成完整 PMF 四項指標回傳（不寫入任何資料庫）

        category: 專案的「次分類」（例如「設計」），對應 extractor.py 傳進來的 category
        content_text: extractor.py 用 file_reader.py 從上傳檔案（.txt/.pdf/.docx）
                      解析出來的純文字，跟傳給 CopywritingAgent 的是同一份文字
        """
        if not content_text:
            # 沒有文案內容就不打 Gemini，直接回傳沒有 (b)(c) 的預設值，
            # 避免拿空字串去問 Gemini 產生沒有意義的關鍵字
            results = {"pmf_c_hit_similarity": 0.5, "pmf_b_trend_level": 0.0, "pmf_b_trend_source": None}
            results.update(self._compute_a_and_d(category))
            return results

        gemini_result = extract_keywords_from_text(content_text)

        results = {
            "pmf_c_hit_similarity": 0.5,  # 沒有 MongoDB/embedding 爆款相似度來源，先給預設中位數
        }
        results.update(self._compute_a_and_d(category))
        results.update(self._compute_b(gemini_result))
        results["gemini_analysis"] = gemini_result  # 一併回傳萃取出的原始分析結果，方便前端顯示

        return results