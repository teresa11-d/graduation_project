// 全局暫存後端傳回來的報告資料，方便標籤切換時重新渲染
let currentDiagnosisReport = [];

// 1. 導覽切換
function switchView(viewId, navIndex) {
    document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
    document.getElementById('view-' + viewId).classList.add('active');

    document.querySelectorAll('.nav-item').forEach((el, idx) => {
        if (idx === navIndex) el.classList.add('active');
        else el.classList.remove('active');
    });
    
    if (viewId === 'scores' || viewId === 'form') renderCharts();
}

// 2. 檔名更新
function updateFileText(inputId, statusId) {
    const input = document.getElementById(inputId);
    const status = document.getElementById(statusId);
    status.innerText = (input.files && input.files[0]) ? input.files[0].name : "未選擇任何檔案";
}

// 動態產生各層價格輸入框
function generatePriceFields() {
    const tiersInput = document.getElementById('priceTiersInput');
    const container = document.getElementById('priceFieldsContainer');
    if (!tiersInput || !container) return;

    // 取得使用者輸入的層數（若未輸入或小於 1，則預設為 1 層；最多限制 10 層避免介面爆掉）
    let count = parseInt(tiersInput.value, 10);
    if (isNaN(count) || count < 1) count = 1;
    if (count > 10) {
        count = 10;
        tiersInput.value = 10;
    }

    // 將中文數字寫入陣列，讓提示文字更人性化（第一層、第二層...）
    const chineseNumbers = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十'];

    // 清空現有的輸入框
    container.innerHTML = '';

    // 根據層數動態建立 <input>
    for (let i = 0; i < count; i++) {
        const inputEl = document.createElement('input');
        inputEl.type = 'number';
        inputEl.className = 'form-input';  // 套用原本 style.css 的精美樣式[cite: 4, 6]
        inputEl.name = 'prices';           // 保持同名，FastAPI 才能用 List[str] 接收整串陣列[cite: 7]
        
        const numStr = chineseNumbers[i] || (i + 1);
        inputEl.placeholder = `第${numStr}層如：${(i + 1) * 2000 + 1000}`;
        inputEl.style.flex = '1';
        inputEl.style.minWidth = '130px';  // 確保格子不會縮太小，排不下時會自動換行
        
        container.appendChild(inputEl);
    }
}

// 3. 手風琴選單
function toggleAccordion(headerEl) {
    const item = headerEl.parentElement;
    item.classList.toggle('open');
    const icon = headerEl.querySelector('.fa-caret-up, .fa-caret-down');
    icon.className = item.classList.contains('open') ? "fa-solid fa-caret-up" : "fa-solid fa-caret-down";
}

// 4. 標籤篩選與報告列表渲染 (重要修改點)
function filterReport(tabEl, filterKey) {
    document.querySelectorAll('.tab-pill').forEach(el => el.classList.remove('active'));
    tabEl.classList.add('active');

    // 將 HTML 傳入的英文 key 映射為後端回傳的中文維度名稱
    const dimensionMap = {
        'all': '專案執行力',
        'price': '價格競爭力',
        'document': '文案說服力',
        'video': '影像吸引力',
        'pmf': '產品市場契合度'
    };
    const targetDimension = dimensionMap[filterKey] || '專案執行力';

    renderReportCards(targetDimension);
}

// 將診斷建議畫到網頁上
function renderReportCards(dimensionFilter = null) {
    const container = document.getElementById('reportListContainer');
    if (!container) return;
    container.innerHTML = '';

    // 依據維度過濾（若為空則顯示全部）
    const filteredList = dimensionFilter 
        ? currentDiagnosisReport.filter(item => item.dimension === dimensionFilter)
        : currentDiagnosisReport;

    if (filteredList.length === 0) {
        container.innerHTML = `<div style="text-align:center; padding: 30px; color:#8A7865;">在這個維度中，目前沒有需要特別注意的改善建議喔！🎉</div>`;
        return;
    }

    filteredList.forEach(item => {
        let cardClass = 'green', tagClass = 'green', tagText = '請繼續保持';
        if (item.tag_type === 'negative' || item.tag_type === 'red') {
            cardClass = 'red'; tagClass = 'red'; tagText = '建議立即修改';
        } else if (item.tag_type === 'warning' || item.tag_type === 'yellow') {
            cardClass = 'yellow'; tagClass = 'yellow'; tagText = '建議進行優化';
        }

        const cardHtml = `
            <div class="report-box ${cardClass}">
                <div style="margin-bottom:10px;"><span class="tag-pill ${tagClass}">${tagText}</span><b style="font-size:1.05rem;">${item.title}</b></div>
                <div style="font-size:0.9rem; color:#8A7865; margin-bottom:8px;">${item.original_setting}</div>
                <div style="font-size:0.95rem; line-height:1.5;"><b>${item.suggestion}</b></div>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', cardHtml);
    });
}

// 5. 雷達圖繪製 (Chart.js)
let chartInstance1 = null, chartInstance2 = null;

function renderCharts(radarScores = [85, 85, 85, 85, 85]) {
    const chartData = {
        labels: ['專案執行力', '價格競爭力', '文案說服力', '影像吸引力', '產品市場契合度'],
        datasets: [{
            data: radarScores,
            backgroundColor: 'rgba(242, 203, 87, 0.5)',
            borderColor: '#f7d200',
            borderWidth: 2,
            pointRadius: 3.5,
            pointBackgroundColor: '#ffff'
        }, {
            data: [75, 70, 60, 75, 60],
            backgroundColor: 'rgba(200, 200, 200, 0.2)',
            borderColor: '#a09e9a',
            borderWidth: 1.5,
            pointBackgroundColor: '#a09e9a',
            pointRadius: 1.5
        }]
    };
    const options = { layout:{padding:10}, scales: { r: { min: 0, max: 100, ticks: { display: false }, pointLabels:{ font:{size:14},color:'#333333',padding:5} } }, plugins: { legend: { display: false } } };

    const ctx1 = document.getElementById('previewRadarChart');
    if (ctx1) {
        if (chartInstance1) chartInstance1.destroy();
        chartInstance1 = new Chart(ctx1, { type: 'radar', data: chartData, options: options });
    }

    const ctx2 = document.getElementById('detailRadarChart');
    if (ctx2) {
        if (chartInstance2) chartInstance2.destroy();
        chartInstance2 = new Chart(ctx2, { type: 'radar', data: chartData, options: options });
    }
}

// 6. 表單送出與 API 串接
async function handleFormSubmit(event) {
    event.preventDefault();
    const formEl = document.getElementById('diagnoseForm');
    const formData = new FormData(formEl);
    const submitBtn = formEl.querySelector('button[type="submit"]');
    
    submitBtn.innerText = "AI 診斷運算中...";
    submitBtn.disabled = true;

    try {
        const response = await fetch('http://127.0.0.1:8000/api/v1/diagnose', {
            method: 'POST',
            body: formData
        });
        if (!response.ok) throw new Error("API 連線異常");
        const data = await response.json();
        updateUIWithData(data);
    } catch (error) {
        console.warn("後端連線失敗，自動套用展示用 Mock Data:", error);
        // 若後端沒開，採用備援展示數據
        updateUIWithData({ 
            success_rate: 80, 
            radar_chart_data: { "專案執行力": 85, "價格競爭力": 85, "文案說服力": 85, "影像吸引力": 85, "產品市場契合度": 85 },
            diagnosis_report: []
        });
    } finally {
        submitBtn.innerText = "開始診斷 ➔";
        submitBtn.disabled = false;
    }
}

// 7. 將後端 API 數據全面更新到整個網頁 UI (核心升級區)
function updateUIWithData(data) {
    const previewCard = document.getElementById('resultPreviewCard');
    previewCard.style.display = 'block';

    // 更新總分與雷達圖
    document.getElementById('previewScoreText').innerText = (data.success_rate || 80) + '%';
    const scores = data.radar_chart_data ? Object.values(data.radar_chart_data) : [85, 85, 85, 85, 85];
    renderCharts(scores);

    // 更新各維度手風琴細項評分 (View 2)
    if (data.dimensions_evaluation && data.dimensions_evaluation.length > 0) {
        const accordionHeaders = document.querySelectorAll('#view-scores .accordion-header');
        data.dimensions_evaluation.forEach((dim, idx) => {
            if (accordionHeaders[idx]) {
                const scoreTextEl = accordionHeaders[idx].querySelector('div:nth-child(2) b');
                if (scoreTextEl) scoreTextEl.innerText = `${dim.score}分`;
                
                const bodyEl = accordionHeaders[idx].nextElementSibling;
                if (bodyEl && dim.features) {
                    let subHtml = '<div class="score-box">';
                    dim.features.forEach(f => {
                        subHtml += `<div class="sub-score-row"><span>${f.feature_name}</span><b>  ${f.score}分</b></div>`;
                    });
                    subHtml += '</div>';
                    bodyEl.innerHTML = subHtml;
                }
            }
        });
    }

    // 更新紅黃綠卡片計數與診斷卡片列表 (View 3)
    if (data.diagnosis_report) {
        currentDiagnosisReport = data.diagnosis_report;
        let redCount = 0, yellowCount = 0, greenCount = 0;
        
        currentDiagnosisReport.forEach(item => {
            if (item.tag_type === 'negative' || item.tag_type === 'red') redCount++;
            else if (item.tag_type === 'warning' || item.tag_type === 'yellow') yellowCount++;
            else if (item.tag_type === 'positive' || item.tag_type === 'green') greenCount++;
        });

        const sumCards = document.querySelectorAll('.summary-cards-grid .sum-card');
        if (sumCards.length >= 3) {
            sumCards[0].querySelector('.sum-content-row div:nth-child(2)').innerHTML = `${redCount} <small style="font-size:1rem; color:#7A6855;">處</small>`;
            sumCards[1].querySelector('.sum-content-row div:nth-child(2)').innerHTML = `${yellowCount} <small style="font-size:1rem; color:#7A6855;">處</small>`;
            sumCards[2].querySelector('.sum-content-row div:nth-child(2)').innerHTML = `${greenCount} <small style="font-size:1rem; color:#7A6855;">處</small>`;
        }

        // 預設切換到第一個分頁「專案執行力」並渲染報告
        const firstTab = document.querySelector('.filter-tabs .tab-pill');
        if (firstTab) filterReport(firstTab, 'all');
    }

    // 自動平滑滾動到預覽卡片處
    previewCard.scrollIntoView({ behavior: 'smooth' });
}

window.onload = () => { renderCharts(); };

// PDF 下載功能
function downloadFullPagePDF() {
    const element = document.getElementById('view-report');
    const opt = { 
        margin: 10, 
        filename: `募資診斷報告_${new Date().toISOString().split("T")[0]}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, scrollY: 0 },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait', compress: true },
        pagebreak: { mode: ["avoid-all", "css", "legacy"] }
    };
    html2pdf().set(opt).from(element).save();
}