from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import uvicorn

app = FastAPI(title="群眾募資多模態分析之評分與診斷系統 API")

# 設定 CORS，允許前端 (任意 Port) 發送請求給後端
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 定義回傳給前端的 JSON 資料結構
class FeatureScore(BaseModel):
    feature_name: str
    score: int

class DimensionDetail(BaseModel):
    dimension_name: str
    score: int
    weight: str
    features: List[FeatureScore]

class DiagnosisAdvice(BaseModel):
    tag_type: str
    dimension: str
    title: str
    original_setting: str
    suggestion: str

class DiagnosisResponse(BaseModel):
    success_rate: int
    radar_chart_data: dict
    dimensions_evaluation: List[DimensionDetail]
    diagnosis_report: List[DiagnosisAdvice]

@app.post("/api/v1/diagnose", response_model=DiagnosisResponse)
async def run_diagnosis(
    project_type: str = Form(...),
    category: str = Form(...),
    funding_days: int = Form(...),
    price_tiers: int = Form(...),
    prices: List[str] = Form(...),  # <--- 修改點 1：改用 List[str] 才能接收多層價格
    content_file: Optional[UploadFile] = File(None),
    media_file: Optional[UploadFile] = File(None),
    faq_file: Optional[UploadFile] = File(None)
):
    try:
        # 修改點 2：提供包含全部 5 大維度的完整 Mock 回傳資料，方便前端實時測試
        mock_response = {
            "success_rate": 82,
            "radar_chart_data": {
                "專案執行力": 85,
                "價格競爭力": 70,
                "文案說服力": 90,
                "影像吸引力": 80,
                "產品市場契合度": 85
            },
            "dimensions_evaluation": [
                {
                    "dimension_name": "專案執行力", "score": 85, "weight": "權重15%",
                    "features": [{"feature_name": "募資天數", "score": 85}, {"feature_name": "目標金額", "score": 60}]
                },
                {
                    "dimension_name": "價格競爭力", "score": 70, "weight": "權重15%",
                    "features": [{"feature_name": "回饋方案層數", "score": 85}, {"feature_name": "回饋方案金額中位數", "score": 65}, {"feature_name": "定價區間合理性", "score": 60}]
                },
                {
                    "dimension_name": "文案說服力", "score": 90, "weight": "權重15%",
                    "features": [{"feature_name": "文案字數", "score": 90}, {"feature_name": "文案感情字詞比例", "score": 85}, {"feature_name": "文案規格字詞比例", "score": 80}, {"feature_name": "FAQ題數與FAQ更新比例", "score": 95}]
                },
                {
                    "dimension_name": "影像吸引力", "score": 80, "weight": "權重15%",
                    "features": [{"feature_name": "每百字多媒體密度", "score": 85}, {"feature_name": "是否包含影片", "score": 90}, {"feature_name": "實際操作情境影片", "score": 65}]
                },
                {
                    "dimension_name": "產品市場契合度", "score": 85, "weight": "權重15%",
                    "features": [{"feature_name": "平台內同類商品近期成功率", "score": 85}, {"feature_name": "Google趨勢斜率", "score": 90}, {"feature_name": "爆款相似度", "score": 75}, {"feature_name": "市場飽和度", "score": 70}]
                }
            ],
            "diagnosis_report": [
                {
                    "tag_type": "negative", "dimension": "專案執行力",
                    "title": "建議立即修改：目標金額",
                    "original_setting": "原設定：新台幣 300 萬元",
                    "suggestion": "修改建議：建議調降初始目標金額！請精算您的「最低開模/印刷成本（MVP）」，將初始目標金額下修至 30 萬至 50 萬元之間。"
                },
                {
                    "tag_type": "warning", "dimension": "價格競爭力",
                    "title": "建議進行優化：定價區間合理性",
                    "original_setting": "原設定：方案售價高於同類平均 35%",
                    "suggestion": "修改建議：建議增加「限時超早鳥（7折左右）」階層，以拉低首批消費者的比價心理阻力。"
                },
                {
                    "tag_type": "positive", "dimension": "文案說服力",
                    "title": "請繼續保持：FAQ 完整度",
                    "original_setting": "原設定：已提供 12 題常問解答",
                    "suggestion": "修改建議：無需修改，完善的 FAQ 能有效降低消費者的購買疑慮與客服成本。"
                }
            ]
        }
        return mock_response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)