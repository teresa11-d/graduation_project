# backend/services/video_agent.py
# backend/services/video_agent.py
import cv2
import numpy as np
import json
import os
import re
import time
from google import genai
from google.genai import types


class VideoAgent:
    """負責處理 4. 影像吸引力 (基於兩階段架構：OpenCV 規則篩選 + Gemini 視覺評分)"""

    GEMINI_BATCH_PROMPT = """你是產品短影音的畫面審核員。以下依序提供 {n} 張影片截圖。
請針對「每一張」各自評估其呈現「產品實際使用情境（例如：人物實際操作、穿戴、使用產品或展示產品功能運作）」的程度（0~100 整數）。
請只回答一個 JSON 整數陣列（長度必須剛好為 {n}），例如：[80, 20, 65]，絕對不可有其他文字或說明。"""

    # 每支影片最多送幾張關鍵畫面給 Gemini，避免單次請求圖片過多導致 Timeout 或 429/503
    MAX_CANDIDATES_PER_VIDEO = 12

    def __init__(self, api_key: str = ""):
        key = api_key or os.environ.get("GEMINI_API_KEY", "")
        self.client = genai.Client(api_key=key) if key else None
        self.model_name = os.environ.get("GEMINI_MODEL_OVERRIDE", "gemini-3.5-flash-lite")

    def analyze_videos(self, video_paths: list) -> dict:
        if not video_paths:
            return self._empty_result()

        results = []
        valid_durations = []

        for path in video_paths:
            filename = os.path.basename(path)
            frames, duration = self._sample_frames(path, interval_sec=2.0)
            print(f"🎬 [VideoAgent] 讀取影片「{filename}」：時長 {duration:.2f} 秒，擷取 {len(frames)} 張基礎影格", flush=True)

            if duration > 0:
                valid_durations.append(duration)

            candidates = self._cv_rule_filter(frames)
            print(f"   ↳ 通過 OpenCV 清晰度與動態篩選：{len(candidates)} 張候選畫面", flush=True)

            # 若沒有畫面通過篩選，但有成功擷取到影格，保底取正中間那張影格送審
            if not candidates and frames:
                candidates = [frames[len(frames) // 2]]

            # 均勻抽樣至多 MAX_CANDIDATES_PER_VIDEO 張，避免單次 API 請求負載過大
            if len(candidates) > self.MAX_CANDIDATES_PER_VIDEO:
                idxs = np.linspace(0, len(candidates) - 1, self.MAX_CANDIDATES_PER_VIDEO, dtype=int)
                sampled_candidates = [candidates[i] for i in idxs]
            else:
                sampled_candidates = candidates

            scores = self._gemini_batch_score(sampled_candidates)

            if scores:
                # 以實際送審的張數為分母計算比例，避免因抽樣上限而被低估
                denom = len(sampled_candidates) if sampled_candidates else 1
                ratio = sum(1 for s in scores if s >= 50) / denom
                soft_ratio = (sum(scores) / 100.0) / denom
                avg_score = sum(scores) / len(scores)
                print(f"   ✅ Gemini 影片評分完成：平均分數 {avg_score:.1f}，情境比例 {soft_ratio:.4f}", flush=True)
                results.append((duration, ratio, soft_ratio, avg_score))
            else:
                print(f"   ⚠️ 影片「{filename}」未能取得 Gemini 評分，僅保留基礎時長資訊", flush=True)

        # 若所有影片的 Gemini 評分都失敗，仍保留 OpenCV 實際測得的影片總時長，不再全部歸零
        if not results:
            empty_res = self._empty_result()
            if valid_durations:
                empty_res["total_video_duration"] = round(sum(valid_durations), 2)
                empty_res["videos_excluded_low_coverage"] = len(video_paths)
            return empty_res

        durations = [r[0] for r in results]
        ratios = [r[1] for r in results]
        soft_ratios = [r[2] for r in results]
        avg_scores = [r[3] for r in results]

        total_dur = sum(valid_durations) if valid_durations else sum(durations)
        dur_sum_for_weight = sum(durations)
        weighted_ratio = (
            sum(r * d for r, d in zip(ratios, durations)) / dur_sum_for_weight
            if dur_sum_for_weight > 0 else (sum(ratios) / len(ratios))
        )

        return {
            "videos_included": len(results),
            "videos_excluded_low_coverage": len(video_paths) - len(results),
            "total_video_duration": round(total_dur, 2),
            "primary_usage_scene_soft_ratio": round(soft_ratios[0], 4),
            "primary_gemini_avg_score": round(avg_scores[0], 2),
            "mean_usage_scene_soft_ratio": round(sum(soft_ratios) / len(soft_ratios), 4),
            "max_usage_scene_soft_ratio": round(max(soft_ratios), 4),
            "mean_gemini_avg_score": round(sum(avg_scores) / len(avg_scores), 2),
            "duration_weighted_usage_scene_ratio": round(weighted_ratio, 4),
        }

    def _sample_frames(self, path: str, interval_sec: float):
        cap = cv2.VideoCapture(path)
        if not cap.isOpened():
            print(f"❌ [VideoAgent] OpenCV 無法開啟影片檔案：{path}", flush=True)
            return [], 0.0

        fps = cap.get(cv2.CAP_PROP_FPS)
        if not fps or fps <= 0 or np.isnan(fps):
            fps = 25.0

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        step = max(1, int(fps * interval_sec))
        frames, idx = [], 0

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            if idx % step == 0:
                frames.append(frame)
            idx += 1
        cap.release()

        # 若容器 header 的 total_frames 異常為 0，改用實際讀到的 idx 推算秒數
        actual_frames = total_frames if total_frames > 0 else idx
        duration = actual_frames / fps if fps > 0 else 0.0
        return frames, duration

    def _cv_rule_filter(self, frames: list):
        candidates = []
        last_gray = None
        for frame in frames:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            mean_b = gray.mean()
            # 排除全黑或全白過曝畫面
            if not (10 < mean_b < 245):
                continue

            # 排除過度模糊或純色無細節畫面
            edges = cv2.Canny(gray, 50, 150)
            if np.count_nonzero(edges) / edges.size < 0.02:
                continue

            # 排除與上一張幾乎靜止重複的畫面
            if last_gray is not None and cv2.absdiff(gray, last_gray).mean() < 6.0:
                continue

            last_gray = gray
            candidates.append(frame)
        return candidates

    def _gemini_batch_score(self, candidates: list) -> list[float]:
        if not candidates or not self.client:
            return []

        parts = [types.Part.from_text(text=self.GEMINI_BATCH_PROMPT.format(n=len(candidates)))]
        for frame in candidates:
            # 將畫面等比例縮小至最大寬度 512px，大幅加快上傳與推論速度
            h, w = frame.shape[:2]
            if w > 512:
                scale = 512.0 / w
                frame = cv2.resize(frame, (512, int(h * scale)), interpolation=cv2.INTER_AREA)

            success, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
            if success:
                parts.append(types.Part.from_bytes(data=buf.tobytes(), mime_type="image/jpeg"))

        max_retries = 3
        for attempt in range(max_retries):
            try:
                resp = self.client.models.generate_content(
                    model=self.model_name,
                    contents=parts,
                    config=types.GenerateContentConfig(
                        temperature=0.1,
                    ),
                )
                raw_text = (resp.text or "").strip()
                m = re.search(r'\[[\s\S]*?\]', raw_text)
                if m:
                    parsed = json.loads(m.group(0))
                    if isinstance(parsed, list) and len(parsed) > 0:
                        return [float(x) for x in parsed if isinstance(x, (int, float))]
                print(f"⚠️ [VideoAgent] Gemini 回傳格式無法解析為陣列：{raw_text[:100]}", flush=True)
                return []
            except Exception as e:
                err_msg = str(e)
                if attempt < max_retries - 1 and ("503" in err_msg or "429" in err_msg or "quota" in err_msg.lower()):
                    wait_sec = (attempt + 1) * 4
                    print(f"⚠️ [VideoAgent] Gemini 伺服器忙碌 ({err_msg[:40]}...)，等待 {wait_sec} 秒後重試...", flush=True)
                    time.sleep(wait_sec)
                    continue
                print(f"❌ [VideoAgent] Gemini 視覺評分失敗：{e}", flush=True)
                return []
        return []

    def _empty_result(self):
        return {
            "videos_included": 0,
            "videos_excluded_low_coverage": 0,
            "total_video_duration": 0.0,
            "primary_usage_scene_soft_ratio": 0.0,
            "primary_gemini_avg_score": 0.0,
            "mean_usage_scene_soft_ratio": 0.0,
            "max_usage_scene_soft_ratio": 0.0,
            "mean_gemini_avg_score": 0.0,
            "duration_weighted_usage_scene_ratio": 0.0,
        }