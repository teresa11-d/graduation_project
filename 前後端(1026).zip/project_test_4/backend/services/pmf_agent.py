# backend/services/pmf_agent.py
"""
PMF (Product-Market Fit) Agent — 即時客戶分析版
====================================================
把三份 notebook 的流程串成一次性、單次呼叫的 pipeline：

  1. keyword_analyse_final(...) 的關鍵字萃取
     -> 直接吃 extractor.py 已經萃取好的 content_text（不重新讀檔），
        丟給 Gemini 萃取 product_type / core_features / style /
        target_audience / trend_keywords / Long-tail_Keywords。

  2. trend_score_analysis_final(...) 的市場熱度查詢
     -> 用 Gemini 萃取出的 trend_keywords 查 Google Trends；
        查無資料再改用 Long-tail_Keywords。
        方法順序：先 pytrends_modern，抓不到才試 trendspy。

  3. calculate_pmf_final(...) 的 PMF 四項指標合併
     -> (a) 同類近期成功率 / (d) 市場飽和度：查詢 zeczec_history.db
        (b) Google 趨勢：來自步驟 2
        (c) 爆款相似度：【本版改為與 calculate_pmf_final.ipynb 相同做法】
            從 zeczec_history.db 抓「達標率(%) >= 門檻」的專案當作爆款，
            去 MongoDB 撈這些專案的關鍵字/特色文字，用本地
            sentence-transformers 多語言模型算 embedding，
            再算客戶專案與所有爆款的「最大餘弦相似度」。
            爆款向量只算一次（記憶體 + .npy 磁碟快取），之後每次請求只需
            encode 一筆客戶文字，很快。

依賴：pip install sentence-transformers pymongo numpy
環境變數：GEMINI_API_KEY、MONGODB_URI
"""

import os
import re
import json
import sqlite3
import threading

import numpy as np
import requests

# 進度回報（job_manager 內有 report_progress 才會生效；沒有就當作空函式，
# 避免還沒改 job_manager 時這支檔案 import 失敗）
try:
    from services.job_manager import report_progress
except Exception:  # pragma: no cover
    def report_progress(step, message, total=6):
        pass


# ========================================
# Gemini 設定
# ========================================
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL_NAME = "gemini-3.5-flash-lite"
GEMINI_REST_ENDPOINT = (
    "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
)

# ========================================
# Google Trends 設定（與 trend_score_analysis_final.ipynb 一致）
# ========================================
TRENDS_GEO = "TW"                 # 台灣地區搜尋熱度（ZecZec 是台灣平台）
TRENDS_TIMEFRAME = "today 12-m"   # 過去 12 個月
MAX_KEYWORDS_PER_QUERY = 5        # Google Trends 一次最多比較 5 個關鍵字

# ========================================
# (c) 爆款相似度設定（與 calculate_pmf_final.ipynb 一致）
# ========================================
HIT_THRESHOLD_PERCENT = 300       # 達標率(%) >= 這個數字視為「爆款」
EMBEDDING_MODEL_NAME = "paraphrase-multilingual-MiniLM-L12-v2"
MONGODB_URI = os.environ.get("MONGODB_URI", "")
MONGO_DB_NAME = "zeczec_db"
MONGO_COLLECTION = "keyword_analysis"

_model_lock = threading.Lock()
_hit_lock = threading.Lock()
_embed_model = None
_hit_embeddings = None            # shape (爆款數, 向量維度)，載入後常駐記憶體


def _mean_interest_from_df(interest_df, keywords):
    """從 interest_over_time 的結果，算出這組關鍵字的平均搜尋熱度分數（0~100）"""
    if interest_df is None or interest_df.empty:
        return None
    cols = [c for c in keywords if c in interest_df.columns]
    if not cols:
        return None
    return float(interest_df[cols].mean().mean())


def _try_pytrends_modern(keywords):
    from pytrends_modern import TrendReq
    pytrends = TrendReq(hl="zh-TW", tz=480)
    pytrends.build_payload(kw_list=keywords, timeframe=TRENDS_TIMEFRAME, geo=TRENDS_GEO)
    interest_df = pytrends.interest_over_time()
    return _mean_interest_from_df(interest_df, keywords)


def _try_trendspy(keywords):
    from trendspy import Trends
    tr = Trends()
    interest_df = tr.interest_over_time(keywords, geo=TRENDS_GEO, timeframe=TRENDS_TIMEFRAME)
    return _mean_interest_from_df(interest_df, keywords)


def get_trend_score(keywords):
    """
    簡化版查詢（無多層防護、無 proxy）：
      - 只取前 MAX_KEYWORDS_PER_QUERY 個關鍵字
      - 先試 pytrends_modern，抓不到（例外或空結果）才試 trendspy
      - 回傳 (score, method)；全部失敗回傳 (None, None)
    """
    keywords = [k for k in keywords if k][:MAX_KEYWORDS_PER_QUERY]
    if not keywords:
        return None, None

    try:
        score = _try_pytrends_modern(keywords)
        if score is not None:
            return score, "pytrends_modern"
    except Exception:
        pass

    try:
        score = _try_trendspy(keywords)
        if score is not None:
            return score, "trendspy"
    except Exception:
        pass

    return None, None


def _clean_ocr_noise(text):
    """簡易清洗，去除亂碼字元、多餘空白（沿用原本 notebook 的邏輯）"""
    text = re.sub(r'[^\u4e00-\u9fff\w\s，。！？、：；「」【】（）\-]', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


# ========================================
# Prompt（與你提供的內容完全一致）
# ========================================
def _build_prompt(cleaned_text, has_images=False):
    image_note = ""
    if has_images:
        image_note = (
            "\n- 本次額外提供了此募資專案的產品圖片，請將圖片中呈現的「產品外觀、包裝、"
            "色彩、材質、使用情境」也一併納入判斷，讓 style、core_features、"
            "trend_keywords 與 Long-tail_Keywords 更貼近圖片中實際呈現的樣貌，"
            "而不要只依賴文字內容。\n"
        )

    prompt = f"""你是一個專業的群眾募資分析師。
以下是一個募資專案的內文（可能含有OCR識別錯誤）{"，並附上該專案的產品圖片" if has_images else ""}。

請注意：
- 忽略退款條款、物流出貨、客服聯絡、法律聲明等行政與免責文字。
- 專注於「這個產品的核心功能、應用場景、設計風格、獨特賣點 (USP) 或背景故事」。
- trend_keywords 必須是「台灣消費者在網購或尋找此類產品時，真正會輸入 Google 的大方向通用關鍵字」（例如：恐怖遊戲、獨立遊戲、解謎桌遊）。請絕對避免將專案特有的劇情、專有名詞或冷門詞彙（如：東歐、精神實驗）當作搜尋關鍵字，以免搜尋量為零。
- 請嚴格確保所有輸出的內容與關鍵字，都必須是『台灣在地化用語』與『繁體中文』，絕對不可出現簡體字。
- 請提供 5 個『長尾關鍵字（Long-tail Keywords）』。不要只輸出『寵物玩具』這種大範圍詞彙，請務必結合產品的『特殊材質（如貓草）』、『功能（如嗅聞、放電）』或『解決的痛點（如焦慮、無聊）』來生成，以符合實際消費者的搜尋習慣。{image_note}

請完全「根據下方的專案內文」進行客觀判斷，絕不可自行發明或套用無關的風格。只輸出以下JSON格式，不要輸出其他任何說明文字：

{{
  "product_type": "<填入精準的產品類型，例如判斷是桌遊、家電或背包>",
  "core_features": ["<填入實際提及的核心特色1>", "<填入實際提及的核心特色2>", "<填入實際提及的核心特色3>"],
  "style": "<萃取內文提及的視覺設計或整體風格，如無明確提及請填『無』>",
  "target_audience": "<填入最精準的目標客群描述>",
  "trend_keywords": ["<通用關鍵字1>", "<通用關鍵字2>", "<通用關鍵字3>"],
  "Long-tail_Keywords": ["<長尾關鍵字1>", "<長尾關鍵字2>", "<長尾關鍵字3>", "<長尾關鍵字4>", "<長尾關鍵字5>"]
}}

專案內文：
{cleaned_text}"""
    return prompt


# ========================================
# 呼叫 Gemini
# ========================================
def _post_gemini(payload):
    resp = requests.post(
        GEMINI_REST_ENDPOINT.format(model=GEMINI_MODEL_NAME),
        params={"key": GEMINI_API_KEY},
        json=payload,
        timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()
    text = data["candidates"][0]["content"]["parts"][0]["text"]
    return json.loads(text)


def extract_keywords_from_text(content_text: str) -> dict:
    """
    直接吃已經萃取好的文案文字（file_reader.py 解析 .docx/.pdf 之後的結果），
    送 Gemini 萃取關鍵字與特徵。

    回傳 Gemini 解析出的 dict：
      product_type / core_features / style / target_audience /
      trend_keywords / Long-tail_Keywords
    """
    cleaned = _clean_ocr_noise(content_text or "")
    prompt = _build_prompt(cleaned, has_images=False)
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseMimeType": "application/json",
            "temperature": 0.1,
        },
    }
    return _post_gemini(payload)


# ========================================
# (c) 爆款相似度：embedding 相關函式
# ========================================
def build_project_text(doc):
    """與 calculate_pmf_final.ipynb 的 build_project_text 完全相同"""
    parts = [
        doc.get('product_type', ''),
        doc.get('style', ''),
        doc.get('target_audience', ''),
        '、'.join(doc.get('core_features', []) or []),
        '、'.join(doc.get('trend_keywords', []) or []),
        '、'.join(doc.get('Long-tail_Keywords', []) or []),
    ]
    return '。'.join(p for p in parts if p and p != '無')


def _get_embed_model():
    """載入本地 embedding 模型（只載入一次，之後共用）"""
    global _embed_model
    with _model_lock:
        if _embed_model is None:
            from sentence_transformers import SentenceTransformer
            _embed_model = SentenceTransformer(EMBEDDING_MODEL_NAME)
        return _embed_model


def _project_id_to_key(project_id: str):
    """
    MongoDB 的 project_id 長得像：
      '出版_New_ZecZec_Dataset/預購式專案/出版/成功/PS18_metoo'
    轉成 zeczec_history.db 的比對鍵：(主分類, 次分類, 募資狀態, 專案編號)
    （與 notebook 的 build_project_id_index 邏輯相同）
    """
    parts = (project_id or "").replace("\\", "/").split("/")
    if len(parts) < 5:
        return None
    return (parts[1], parts[2], parts[3], parts[4].split("_")[0])


def _load_hit_embeddings(db_path: str):
    """
    取得所有「爆款」專案的 embedding。
    第一次：SQLite 抓爆款清單 -> MongoDB 撈文字 -> 本地模型算向量 -> 存 .npy
    之後：直接用記憶體（或磁碟快取）。失敗或沒有爆款回傳 None。

    ⚠️ 歷史資料庫或 HIT_THRESHOLD_PERCENT 有更新時，
       刪掉 db 旁邊的 hit_embeddings_<門檻>.npy 即可強制重算。
    """
    global _hit_embeddings
    with _hit_lock:
        if _hit_embeddings is not None:
            return _hit_embeddings

        cache_path = os.path.join(
            os.path.dirname(os.path.abspath(db_path)),
            f"hit_embeddings_{HIT_THRESHOLD_PERCENT}.npy",
        )
        if os.path.exists(cache_path):
            _hit_embeddings = np.load(cache_path)
            return _hit_embeddings

        if not os.path.exists(db_path):
            return None
        if not MONGODB_URI:
            print("[PMF (c)] 未設定環境變數 MONGODB_URI，無法載入爆款文字")
            return None

        # 1) 從 SQLite 抓「達標率 >= 門檻」的爆款專案
        conn = sqlite3.connect(db_path)
        rows = conn.execute(
            'SELECT 主分類, 次分類, 募資狀態, 專案編號 FROM projects_summary '
            'WHERE CAST("達標率(%)" AS REAL) >= ?',
            (HIT_THRESHOLD_PERCENT,),
        ).fetchall()
        conn.close()
        hit_keys = set(rows)
        if not hit_keys:
            return None

        # 2) 去 MongoDB 撈這些專案的關鍵字／特色文字
        from pymongo import MongoClient
        client = MongoClient(MONGODB_URI, serverSelectionTimeoutMS=8000)
        try:
            docs = client[MONGO_DB_NAME][MONGO_COLLECTION].find({}, {
                'project_id': 1, 'product_type': 1, 'style': 1, 'target_audience': 1,
                'core_features': 1, 'trend_keywords': 1, 'Long-tail_Keywords': 1,
                'needs_reanalysis': 1,
            })
            texts = []
            for d in docs:
                # 本地 Jieba 備援產生的低品質資料，不當作爆款樣本
                if d.get('needs_reanalysis'):
                    continue
                if _project_id_to_key(d.get('project_id')) in hit_keys:
                    t = build_project_text(d)
                    if t.strip():
                        texts.append(t)
        finally:
            client.close()

        if not texts:
            return None

        # 3) 本地 embedding（normalize 後，內積 = 餘弦相似度）
        emb = _get_embed_model().encode(
            texts, normalize_embeddings=True, show_progress_bar=False
        )
        try:
            np.save(cache_path, emb)
        except Exception as e:
            print(f"[PMF (c)] 爆款向量快取寫入失敗（不影響運作）：{e}")
        _hit_embeddings = emb
        print(f"✅ 已載入 {len(texts)} 筆爆款專案 embedding")
        return _hit_embeddings


# ========================================
# PMFAgent：整合 (a)(d) 歷史資料庫 + (b) Google Trends + (c) 爆款相似度
# ========================================
class PMFAgent:
    """負責處理即時客戶分析用的 PMF 四項指標（簡化版，不寫入任何資料庫）"""

    def __init__(self, db_path: str = "zeczec_history.db"):
        self.db_path = db_path

    def _compute_a_and_d(self, category: str) -> dict:
        """(a) 同類近期成功率 + (d) 市場飽和度：查詢歷史 SQLite"""
        result = {
            "pmf_a_recent_category_success_rate": 0.0,
            "pmf_d_market_saturation_count": 0,
        }
        if not os.path.exists(self.db_path):
            return result

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT 募資狀態 FROM projects_summary WHERE 次分類=?", (category,)
        )
        rows = cursor.fetchall()
        conn.close()

        if rows:
            success_count = sum(1 for r in rows if r[0] == "成功")
            result["pmf_a_recent_category_success_rate"] = round(success_count / len(rows), 4)
            result["pmf_d_market_saturation_count"] = len(rows)

        return result

    def _compute_b(self, gemini_result: dict) -> dict:
        """(b) Google 趨勢：先用 trend_keywords 查，查不到再用 Long-tail_Keywords"""
        trend_keywords = gemini_result.get("trend_keywords", []) or []
        long_tail_keywords = gemini_result.get("Long-tail_Keywords", []) or []

        score, method = get_trend_score(trend_keywords)
        if score is None and long_tail_keywords:
            score, method = get_trend_score(long_tail_keywords)

        return {
            "pmf_b_trend_level": round(score, 4) if score is not None else 0.0,
            "pmf_b_trend_source": method,  # 'pytrends_modern' / 'trendspy' / None
        }

    def _compute_c(self, gemini_result: dict) -> dict:
        """
        (c) 爆款相似度：客戶專案文字（Gemini 萃取的關鍵字/特色）
            vs 所有爆款專案，取最大餘弦相似度。
        任何一步失敗（MongoDB 連不上、套件沒裝、沒有爆款資料）都退回預設值 0.5，
        不讓整個診斷流程因此失敗。
        """
        fallback = {"pmf_c_hit_similarity": 0.5, "pmf_c_source": "fallback_default"}
        try:
            text = build_project_text(gemini_result)
            hits = _load_hit_embeddings(self.db_path)
            if not text.strip() or hits is None or len(hits) == 0:
                return fallback

            vec = _get_embed_model().encode(
                [text], normalize_embeddings=True, show_progress_bar=False
            )[0]
            sim = float((hits @ vec).max())
            return {
                "pmf_c_hit_similarity": round(sim, 4),
                "pmf_c_source": "embedding",
            }
        except Exception as e:
            print(f"[PMF (c) 爆款相似度計算失敗，改用預設值 0.5] {e}")
            return fallback

    @staticmethod
    def warmup(db_path: str = "zeczec_history.db"):
        """伺服器啟動時預先載入模型與爆款向量，避免第一位客戶等很久"""
        try:
            _get_embed_model()
            _load_hit_embeddings(db_path)
        except Exception as e:
            print(f"[PMF warmup 失敗] {e}")

    def analyze(self, category: str, content_text: str) -> dict:
        """
        主流程：
          1. extract_keywords_from_text()：Gemini 從文案萃取關鍵字與特徵
          2. _compute_a_and_d()：歷史資料庫算成功率/飽和度
          3. _compute_b()：用萃取出的關鍵字查 Google Trends
          4. _compute_c()：embedding 比對歷史爆款專案
          5. 合併成完整 PMF 四項指標回傳（不寫入任何資料庫）

        category: 專案的「次分類」（例如「設計」）
        content_text: file_reader.py 解析出來的文案純文字
        """
        if not content_text:
            # 沒有文案內容就不打 Gemini，直接回傳預設值
            results = {"pmf_c_hit_similarity": 0.5, "pmf_b_trend_level": 0.0, "pmf_b_trend_source": None}
            results.update(self._compute_a_and_d(category))
            return results

        report_progress(3, "AI 正在從文案萃取市場關鍵字…")
        gemini_result = extract_keywords_from_text(content_text)

        results = {}

        report_progress(3, "正在計算同類專案的成功率與市場飽和度…")
        results.update(self._compute_a_and_d(category))

        report_progress(3, "正在查詢 Google 搜尋趨勢…")
        results.update(self._compute_b(gemini_result))

        report_progress(3, "正在比對歷史爆款專案的語意相似度…")
        results.update(self._compute_c(gemini_result))

        results["gemini_analysis"] = gemini_result  # 一併回傳萃取出的原始分析結果

        return results