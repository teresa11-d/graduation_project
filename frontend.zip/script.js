// 1. 導覽切換
function switchView(viewId, navIndex) {
    document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
    document.getElementById('view-' + viewId).classList.add('active');

    document.querySelectorAll('.nav-item').forEach((el, idx) => {
        if (idx === navIndex) el.classList.add('active');
        else el.classList.remove('active');
    });
    
    if (viewId === 'scores' || viewId === 'form') renderCharts();
}

// 2. 檔名更新
function updateFileText(inputId, statusId) {
    const input = document.getElementById(inputId);
    const status = document.getElementById(statusId);
    status.innerText = (input.files && input.files[0]) ? input.files[0].name : "未選擇任何檔案";
}

// 3. 手風琴選單
function toggleAccordion(headerEl) {
    const item = headerEl.parentElement;
    item.classList.toggle('open');
    const icon = headerEl.querySelector('.fa-caret-up, .fa-caret-down');
    icon.className = item.classList.contains('open') ? "fa-solid fa-caret-up" : "fa-solid fa-caret-down";
}

// 4. 標籤篩選
function filterReport(tabEl) {
    document.querySelectorAll('.tab-pill').forEach(el => el.classList.remove('active'));
    tabEl.classList.add('active');
}

// 5. 雷達圖繪製 (Chart.js)
let chartInstance1 = null, chartInstance2 = null;

function renderCharts(radarScores = [85, 85, 85, 85, 85]) {
    const chartData = {
        labels: ['專案執行力', '價格競爭力', '文案說服力', '影像吸引力', '產品市場契合度'],
        datasets: [{
            data: radarScores,
            backgroundColor: 'rgba(242, 203, 87, 0.5)',
            borderColor: '#f7d200',
            borderWidth: 2,
            pointRadius: 3.5,
            pointBackgroundColor: '#ffff'
        }, {
            data: [75, 70, 60, 75, 60],
            backgroundColor: 'rgba(200, 200, 200, 0.2)',
            borderColor: '#a09e9a',
            borderWidth: 1.5,
            pointBackgroundColor: '#a09e9a',
            pointRadius: 1.5
        }]
    };
    const options = { layout:{padding:10}, scales: { r: { min: 0, max: 100, ticks: { display: false }, pointLabels:{ font:{size:14},color:'#333333',padding:5} } }, plugins: { legend: { display: false } } };

    const ctx1 = document.getElementById('previewRadarChart');
    if (ctx1) {
        if (chartInstance1) chartInstance1.destroy();
        chartInstance1 = new Chart(ctx1, { type: 'radar', data: chartData, options: options });
    }

    const ctx2 = document.getElementById('detailRadarChart');
    if (ctx2) {
        if (chartInstance2) chartInstance2.destroy();
        chartInstance2 = new Chart(ctx2, { type: 'radar', data: chartData, options: options });
    }
}

// 6. 表單送出與 API 串接
async function handleFormSubmit(event) {
    event.preventDefault();
    const formEl = document.getElementById('diagnoseForm');
    const formData = new FormData(formEl);
    const submitBtn = formEl.querySelector('button[type="submit"]');
    
    submitBtn.innerText = "AI 診斷運算中...";
    submitBtn.disabled = true;

    try {
        const response = await fetch('http://127.0.0.1:8000/api/v1/diagnose', {
            method: 'POST',
            body: formData
        });
        if (!response.ok) throw new Error("API 連線異常");
        const data = await response.json();
        updateUIWithData(data);
    } catch (error) {
        console.warn("後端連線失敗，自動套用展示用 Mock Data:", error);
        updateUIWithData({ success_rate: 80, radar_scores: [85, 85, 85, 85, 85] });
    } finally {
        submitBtn.innerText = "開始診斷 ➔";
        submitBtn.disabled = false;
    }
}

function updateUIWithData(data) {
    const previewCard = document.getElementById('resultPreviewCard');
    previewCard.style.display = 'block';
    document.getElementById('previewScoreText').innerText = (data.success_rate || 80) + '%';
    renderCharts(data.radar_chart_data ? Object.values(data.radar_chart_data) : [85, 85, 85, 85, 85]);
    previewCard.scrollIntoView({ behavior: 'smooth' });
}

window.onload = () => { renderCharts(); };


//PDF下載功能 (未完整的)
/**
function downloadFullPagePDF() {
    const element = document.getElementById('view-report');
    const opt={ margin:0,filename:`募資診斷報告_${new Date().toISOString().split("T")[0]}.pdf`,
                image:{type:'jpeg',quality:0.98},
                html2canvas:{scale:2,useCORS:true,scrollY:0},
                jsPDF:{unit:'mm',format:'a4',orientation:'portrait',compress:true},
                pagebreak: { mode: ["avoid-all", "css", "legacy"] }
            };
    
  

    html2pdf().set(opt).from(element).save();

}
**/