// 1. 導覽切換
function switchView(viewId, navIndex) {
    document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
    document.getElementById('view-' + viewId).classList.add('active');

    document.querySelectorAll('.nav-item').forEach((el, idx) => {
        if (idx === navIndex) el.classList.add('active');
        else el.classList.remove('active');
    });
    
    if (viewId === 'scores' || viewId === 'form') renderCharts();
}

// 2. 檔名更新
function updateFileText(inputId, statusId) {
    const input = document.getElementById(inputId);
    const status = document.getElementById(statusId);
    status.innerText = (input.files && input.files[0]) ? input.files[0].name : "未選擇任何檔案";
}

// 3. 手風琴選單
function toggleAccordion(headerEl) {
    const item = headerEl.parentElement;
    item.classList.toggle('open');
    const icon = headerEl.querySelector('.fa-caret-up, .fa-caret-down');
    icon.className = item.classList.contains('open') ? "fa-solid fa-caret-up" : "fa-solid fa-caret-down";
}

// 4. 標籤篩選
function filterReport(tabEl) {
    document.querySelectorAll('.tab-pill').forEach(el => el.classList.remove('active'));
    tabEl.classList.add('active');
}

// 5. 雷達圖繪製 (Chart.js)
let chartInstance1 = null, chartInstance2 = null;

function renderCharts(radarScores = [85, 85, 85, 85, 85]) {
    const chartData = {
        labels: ['專案執行力', '價格競爭力', '文案說服力', '影像吸引力', '產品市場契合度'],
        datasets: [{
            data: radarScores,
            backgroundColor: 'rgba(242, 203, 87, 0.5)',
            borderColor: '#E5AF24',
            borderWidth: 2,
            pointBackgroundColor: '#E5AF24'
        }, {
            data: [75, 80, 70, 75, 80],
            backgroundColor: 'rgba(200, 200, 200, 0.2)',
            borderColor: '#CCCCCC',
            borderWidth: 1.5,
            pointRadius: 0
        }]
    };
    const options = { scales: { r: { min: 0, max: 100, ticks: { display: false } } }, plugins: { legend: { display: false } } };

    const ctx1 = document.getElementById('previewRadarChart');
    if (ctx1) {
        if (chartInstance1) chartInstance1.destroy();
        chartInstance1 = new Chart(ctx1, { type: 'radar', data: chartData, options: options });
    }

    const ctx2 = document.getElementById('detailRadarChart');
    if (ctx2) {
        if (chartInstance2) chartInstance2.destroy();
        chartInstance2 = new Chart(ctx2, { type: 'radar', data: chartData, options: options });
    }
}

// 6. 表單送出與 API 串接
async function handleFormSubmit(event) {
    event.preventDefault();
    const formEl = document.getElementById('diagnoseForm');
    const formData = new FormData(formEl);
    const submitBtn = formEl.querySelector('button[type="submit"]');
    
    submitBtn.innerText = "AI 診斷運算中...";
    submitBtn.disabled = true;

    try {
        const response = await fetch('http://127.0.0.1:8000/api/v1/diagnose', {
            method: 'POST',
            body: formData
        });
        if (!response.ok) throw new Error("API 連線異常");
        const data = await response.json();
        updateUIWithData(data);
    } catch (error) {
        console.warn("後端連線失敗，自動套用展示用 Mock Data:", error);
        updateUIWithData({ success_rate: 80, radar_scores: [85, 85, 85, 85, 85] });
    } finally {
        submitBtn.innerText = "開始診斷 ➔";
        submitBtn.disabled = false;
    }
}

function updateUIWithData(data) {
    const previewCard = document.getElementById('resultPreviewCard');
    previewCard.style.display = 'block';
    document.getElementById('previewScoreText').innerText = (data.success_rate || 80) + '%';
    renderCharts(data.radar_chart_data ? Object.values(data.radar_chart_data) : [85, 85, 85, 85, 85]);
    previewCard.scrollIntoView({ behavior: 'smooth' });
}

window.onload = () => { renderCharts(); };