# 負責載入 joblib、跑 XGBoost 與 SHAP 解釋
import joblib
import shap
import pandas as pd
import numpy as np
from scipy.special import expit
import xgboost as xgb
import os
from services.feature_labels import get_feature_label, get_dimension_for_feature

class MLService:
    def __init__(self, model_path: str = "model_bundle_production.joblib"):
        try:
            self.bundle = joblib.load(model_path)

            self.model = xgb.XGBClassifier()
            xgb_model_path = os.path.join(
                os.path.dirname(model_path), self.bundle["xgb_model_path_relative"]
            )
            self.model.load_model(xgb_model_path)

            self.iso = self.bundle.get("isotonic")
            self.all_features = self.bundle["all_features"]
            self.dimension_map = self.bundle["dimension_map"]

            self.explainer = shap.TreeExplainer(
                self.model, feature_perturbation="tree_path_dependent", model_output="raw"
            )
            self.is_ready = True
            print("✅ 模型載入成功！")
        except Exception as e:
            print(f"⚠️ 模型載入失敗，將啟動 Mock 模式。原因: {e}")
            self.is_ready = False

    def predict_and_format(self, x_row: pd.DataFrame) -> dict:
        """
        跑模型預測、計算 SHAP，並將結果轉換為前端要求的 DiagnosisResponse 格式
        """
        if not self.is_ready:
            raise RuntimeError("模型未準備就緒")

        # 記錄這次輸入裡「真的有值」的特徵——還沒被分析出來的（NaN）不該被拿去
        # 生成「強勢特徵」「需優化弱點」這種聽起來很篤定的建議卡片。SHAP 對
        # 缺值算出來的貢獻，只是模型內部學到的「沒資料時的預設分支」反應，
        # 不代表對這個專案的真實判斷，講出來等於是沒根據的斷言。
        known_features = set(x_row.columns[x_row.notna().iloc[0]])

        # 1. 執行推論與 SHAP 解釋 (沿用 colab 中的核心邏輯)
        shap_values = self.explainer.shap_values(x_row)
        base_log_odds = self.explainer.expected_value
        if isinstance(base_log_odds, (list, np.ndarray)):
            base_log_odds = base_log_odds[0]

        feat_shap = shap_values[0]
        total_log_odds = base_log_odds + feat_shap.sum()

        base_prob = float(expit(base_log_odds))
        raw_prob = float(expit(total_log_odds))
        final_prob = float(self.iso.transform([raw_prob])[0]) if self.iso else raw_prob
        score_100 = int(round(final_prob * 100))

        # 計算特徵貢獻百分比
        sum_abs_shap = np.sum(np.abs(feat_shap))
        feature_contrib_pct = (feat_shap / sum_abs_shap) * 100 if sum_abs_shap > 0 else np.zeros_like(feat_shap)

        feature_report = sorted(
            zip(self.all_features, feature_contrib_pct, feat_shap),
            key=lambda t: abs(t[1]), reverse=True,
        )

        # 2. 將 SHAP 維度分數轉換為雷達圖所需的 0-100 分制
        radar_chart_data = {}
        dimensions_evaluation = []

        for dim, feats in self.dimension_map.items():
            idxs = [self.all_features.index(f) for f in feats]
            dim_known = any(f in known_features for f in feats)

            dim_pct = feature_contrib_pct[idxs].sum()
            dim_score = min(max(int(70 + (dim_pct * 2)), 0), 100)
            clean_dim_name = dim.split(". ")[-1]  # 移除 "1. ", "2. " 前綴

            # 這個維度底下全部特徵都還沒被分析（例如「市場契合度(PMF)」目前
            # 唯一的欄位還沒接 Google Trends），就不要顯示一個看起來煞有其事
            # 的分數，回傳 None，讓前端顯示「尚未分析」。
            radar_chart_data[clean_dim_name] = dim_score if dim_known else None

            feature_scores = []
            for f in feats:
                f_idx = self.all_features.index(f)
                f_score = min(max(int(70 + (feature_contrib_pct[f_idx] * 2)), 0), 100)
                feature_scores.append({
                    "feature_name": get_feature_label(f),
                    "score": f_score if f in known_features else None,
                })

            dimensions_evaluation.append({
                "dimension_name": clean_dim_name,
                "score": dim_score if dim_known else None,
                "weight": "權重15%",  # 可依實際邏輯調整
                "features": feature_scores
            })

        # 3. 整理正負面特徵為報告卡片——只從「真的有值」的特徵裡挑
        # 貢獻強度分三段：|貢獻| < 1% 算「影響輕微，建議優化」（黃），
        # 其餘依正負號分「強勢特徵」（綠）／「需優化弱點」（紅）
        diagnosis_report = []
        WEAK_CONTRIBUTION_THRESHOLD = 1.0

        strong_pos_feats = [(f, p) for f, p, s in feature_report if s > 0 and f in known_features and abs(p) >= WEAK_CONTRIBUTION_THRESHOLD][:5]
        strong_neg_feats = [(f, p) for f, p, s in feature_report if s < 0 and f in known_features and abs(p) >= WEAK_CONTRIBUTION_THRESHOLD][:5]
        weak_feats = [(f, p) for f, p, s in feature_report if f in known_features and abs(p) < WEAK_CONTRIBUTION_THRESHOLD][:5]

        for f, p in strong_neg_feats:
            diagnosis_report.append({
                "tag_type": "negative",
                "dimension": get_dimension_for_feature(f, self.dimension_map),
                "title": f"需優化弱點：{get_feature_label(f)}",
                "original_setting": f"該特徵拉低了成功率約 {abs(p):.1f}%",
                "suggestion": "建議針對此項目重新檢視定價或補充相關資料。"
            })

        for f, p in weak_feats:
            diagnosis_report.append({
                "tag_type": "warning",
                "dimension": get_dimension_for_feature(f, self.dimension_map),
                "title": f"影響輕微：{get_feature_label(f)}",
                "original_setting": f"該特徵目前對成功率的影響約 {p:+.1f}%（幅度不大）",
                "suggestion": "此項目目前影響有限，若有餘力可作為次要優化項目。"
            })

        for f, p in strong_pos_feats:
            diagnosis_report.append({
                "tag_type": "positive",
                "dimension": get_dimension_for_feature(f, self.dimension_map),
                "title": f"強勢特徵：{get_feature_label(f)}",
                "original_setting": f"該特徵提升了成功率約 {p:.1f}%",
                "suggestion": "此項目表現極佳，請繼續保持並在行銷上放大此優勢！"
            })

        return {
                    "success_rate": score_100,
                    "radar_chart_data": radar_chart_data,
                    "dimensions_evaluation": dimensions_evaluation,
                    "diagnosis_report": diagnosis_report
        }