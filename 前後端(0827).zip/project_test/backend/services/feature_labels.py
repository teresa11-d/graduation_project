# 英文特徵名稱 -> 中文顯示名稱、以及「哪個特徵屬於哪個維度」的查找工具。
#
# 為什麼獨立成一個檔案：這份對照表會被 ml_service.py（組報告用）用到，
# 未來如果前端也想要「不透過後端組字串、直接拿到特徵中文名」也可以直接
# import 這個檔案的 FEATURE_LABELS 字典，不用重複維護兩份。
#
# 注意：這份清單是照目前 model_bundle_production.joblib 裡 all_features
# 的 27 個欄位建的。如果之後重新訓練、特徵集合有變動（例如共線性剔除的
# 名單不一樣了），這裡沒對應到的欄位會自動 fallback 顯示原始英文名稱
# （見 get_feature_label 的實作），不會噴錯，但建議看到 fallback 出現時
# 回來補上新特徵的翻譯，才能讓報告維持易讀。

FEATURE_LABELS: dict[str, str] = {
    # 1. 專案執行力
    "funding_duration_days": "募資天數",
    "target_amount": "目標金額",

    # 2. 價格競爭力
    "market_price_max": "市場同類商品最高價",
    "price_deviation_ratio": "定價偏離市場比例",
    "is_price_competitive": "定價是否具競爭力",
    "needs_manual_review": "定價是否需人工複核",
    "innovation_label_is_innovative": "是否具創新標籤",
    "reward_tier_count": "回饋方案層數",
    "reward_price_min": "回饋方案最低金額",
    "reward_price_max": "回饋方案最高金額",
    "reward_price_median": "回饋方案金額中位數",

    # 3. 文案說服力
    "feat_text_spec_ratio_rule": "文案規格字詞比例",
    "feat_text_risk_ratio": "文案風險提示字詞比例",
    "feat_has_social_link": "文案是否附社群連結",
    "feat_punct_intensity": "文案標點符號強度",
    "feat_emotional_ratio": "文案情感字詞比例",

    # 5. 市場契合度 (PMF)
    "pmf_b_trend_level": "Google 趨勢斜率",

    # 6. 專案屬性（類別 one-hot）
    "category_出版": "類別：出版",
    "category_教育": "類別：教育",
    "category_時尚": "類別：時尚",
    "category_社會": "類別：社會",
    "category_科技": "類別：科技",
    "category_設計": "類別：設計",
    "category_遊戲": "類別：遊戲",
    "category_飲食": "類別：飲食",

    # 6. 專案屬性（平台 one-hot）
    "platform_群眾募資": "募資模式：群眾募資",
    "platform_預購式專案": "募資模式：預購式專案",
}


def get_feature_label(feature_name: str) -> str:
    """查不到對照表就直接回傳原始英文名稱，不讓報告因為漏建對照表而壞掉，
    只是那筆的顯示會退回英文，提醒開發者記得補翻譯。"""
    return FEATURE_LABELS.get(feature_name, feature_name)


def get_dimension_for_feature(feature_name: str, dimension_map: dict) -> str:
    """給一個特徵英文名，反查它屬於 dimension_map 裡的哪個維度，
    回傳去掉編號前綴後的中文維度名（例如 "2. 價格競爭力" -> "價格競爭力"）。
    找不到就回傳「自動診斷」當保底分類，不會噴錯。"""
    for dim, feats in dimension_map.items():
        if feature_name in feats:
            return dim.split(". ", 1)[-1]
    return "自動診斷"