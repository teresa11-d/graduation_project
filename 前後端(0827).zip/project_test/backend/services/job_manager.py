# 簡易的「提交工作、之後輪詢結果」機制。
#
# 為什麼需要這個：CopywritingAgent（Gemini 情感分析）跟 MarketPriceAgent
# （多平台比價 + Gemini）单次呼叫可能要幾秒到幾十秒，如果直接在
# /api/v1/diagnose 這個 route handler 裡同步等待，使用者的瀏覽器會卡住
# 整個請求週期，遇到 Gemini 額度限制時（market_price.py 裡看到的重試邏輯）
# 甚至可能等到瀏覽器自己 timeout。
#
# 這裡用最簡單的記憶體 dict 存工作狀態，適合這種規模的專題/demo。
# ⚠️ 限制：只在單一 process 內有效——如果之後用多個 uvicorn worker
# （例如 --workers 4）或重啟伺服器，工作記錄會消失/找不到。正式產品
# 規模需要換成 Redis 或資料庫存工作狀態，這裡先用最簡單的方式讓功能動起來。

import uuid
import time
import traceback
from typing import Callable
from concurrent.futures import ThreadPoolExecutor

_jobs: dict[str, dict] = {}
_executor = ThreadPoolExecutor(max_workers=4)

# 工作記錄保留多久（秒）。超過這個時間的舊工作，下次有人提交新工作時
# 會被順手清掉，避免長時間開著伺服器、_jobs 字典一直長大不會縮小。
# 不用額外開一個排程執行緒定期清理，靠「每次提交順手掃一次」就夠用，
# 這種規模的流量不會造成效能問題。
_JOB_TTL_SECONDS = 30 * 60  # 30 分鐘


def _cleanup_expired_jobs():
    now = time.time()
    expired_ids = [
        job_id for job_id, job in _jobs.items()
        if now - job["created_at"] > _JOB_TTL_SECONDS
    ]
    for job_id in expired_ids:
        del _jobs[job_id]


def submit_job(func: Callable, *args, **kwargs) -> str:
    """把一個耗時函式丟進背景執行緒池，立刻回傳 job_id，不等待完成。"""
    _cleanup_expired_jobs()

    job_id = str(uuid.uuid4())
    _jobs[job_id] = {"status": "processing", "result": None, "error": None, "created_at": time.time()}

    def _run():
        try:
            result = func(*args, **kwargs)
            _jobs[job_id] = {"status": "done", "result": result, "error": None, "created_at": _jobs[job_id]["created_at"]}
        except Exception as e:
            _jobs[job_id] = {
                "status": "failed", "result": None,
                "error": f"{e}\n{traceback.format_exc()}",
                "created_at": _jobs[job_id]["created_at"],
            }

    _executor.submit(_run)
    return job_id


def get_job(job_id: str) -> dict | None:
    return _jobs.get(job_id)