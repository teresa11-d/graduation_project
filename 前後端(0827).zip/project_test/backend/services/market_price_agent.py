# 檔案名稱：zeczec_market_price.py
# 版本：v18.0（CSV欄位精簡 + 核心價/市場價差距過大自動標記人工複核）
#
# ── 本版新增 ──────────────────────────────────────────────────────
#   1. CSV欄位從24欄精簡為15欄（_CSV_FIELDS），只保留判讀「核心價 vs
#      市場價」比較結果所需的最少欄位；若需要完整溯源/除錯細節，
#      batch_run(..., full_output=True) 可輸出33欄完整版（_CSV_FIELDS_FULL）
#   2. 新增 needs_manual_review / review_reason 欄位：core_price 與市場
#      行情中位數偏離超過±50%（DEVIATION_REVIEW_THRESHOLD）、樣本數過少、
#      或完全沒有市場資料時，自動標記為1並附上具體原因，方便直接篩選
#      出需要人工複核的專案，不需要逐筆比對deviation數字
#   3. 創新商品（is_innovative_product=1）也會被標記 needs_manual_review，
#      但review_reason會明確說明「deviation數字本身不具參考意義，複核
#      重點應放在關鍵字/matched_product_titles是否合理」，跟「一般商品
#      但差距過大，可能是核心價解析錯誤或市場關鍵字不準確」的情況區分開
#
# 版本：v9.0（新增真實比價：直接驗證商品頁面結構化資料，非AI詮釋）
#
# ── 本版新增：真實比價模組（_verify_real_prices）─────────────────────
#   在原本「網頁片段 + Gemini解讀」之上，新增最高優先的一層：直接抓取
#   蝦皮/momo/PChome/博客來等商品頁面的 JSON-LD 結構化資料（網站自己寫
#   給 Google 購物比價卡片看的正確 price 欄位），不透過 AI 詮釋文字，
#   找到就直接採用，並附上原始網址可回頭核對。
#   標記為 is_verified_market_price=True、data_quality="verified"。
#
#   已知限制（誠實揭露）：
#     - 蝦皮反爬蟲防護強，直接請求常被擋下或拿到空頁面，這種情況會
#       自動跳過該筆候選，改看其他平台
#     - momo / PChome / 博客來對一般請求通常較寬容
#     - 完全獨創、市場無對應品項的商品，本來就不會有結果，這是正確
#       行為，會自動退到下一層（網頁片段+Gemini解讀 → AI知識推斷 →
#       核心售價±30%保底），不會假裝驗證到不存在的商品
#
#
# ── 本版新增/修正重點 ────────────────────────────────────────────────
#   1. 市場搜尋改用「免費 DDGS 網路檢索 + Gemini 一般對話呼叫」取代 Google
#      Search Grounding，繞過 Grounding 額度被限制到 0 的問題
#   2. 關鍵字判斷失敗（未分類商品）時，不再直接放棄改用「核心售價±30%」
#      這種脫離商品本質的猜測，而是：
#        a. 先強化 Call 1 提示詞，讓它幾乎不會真的判斷失敗（至少給廣泛品類）
#        b. 真的失敗時，本地免費比對品類字典（無需額外API），找出「這大概
#           是哪一類商品」，改用類似/替代品的市場行情，遠比純價格推算準確
#        c. 兩者都失敗，才退回核心售價±30%作為最後手段
#   3. json_mode 重新打開（不再受 Grounding 限制），避免模型偶爾回傳非JSON
#      格式導致解析失敗
#   4. 平台名稱正規化，避免「PChome」「PChome 24h購物」重複計算灌水信任度
#   5. 新增 market_has_real_search（是否有真實網頁佐證）與
#      keyword_is_category_fallback（是否用了本地品類猜測）兩個透明度欄位
#
# ── 這支檔案做什麼 ──────────────────────────────────────────────────
# 讀取募資專案的 plans.txt（方案定價）與 content.txt（募資文案），算出：
#   1. plans_core_price：這個專案「最合理可比價」的核心售價
#   2. market_price_min / market_price_max：對應的台灣市場行情區間
#   3. price_deviation_ratio / is_price_competitive：核心價跟市場行情的偏離程度
#
# ── 核心售價怎麼算（PlansParser._pick_core） ──────────────────────────
#   優先序：0.明確標示「單入/單本/單件」的方案 → 1.排除法推論的標準單入
#          → 2.標準多入(拆算單價) → 3.早鳥單入 → 4.兜底(納入組合包)
#   每一層都用「同標題方案分組→組內取最高價（排除早鳥異常低價）→
#   跨組取中位數」而不是直接取全體最高價，避免被離群的高價方案拉高。
#   「＋/+」組合包、加購方案一律不列入候選，除非所有方案都是組合包才兜底納入。
#
# ── 市場行情怎麼查（MarketPriceAgent，每個商品最多 2 次 Gemini 呼叫）──
#   Call 1：判斷「含規格特徵的關鍵字」＋核心售價（若 plans.txt 已提供則沿用）
#   Call 2：開啟 Google Search Grounding，在同一次生成內自行嘗試
#           精準搜尋 → 放寬品類 → AI知識推斷 三層策略，要求盡量跨 ≥2 個
#           台灣主要電商平台（蝦皮/PChome/momo/Yahoo/樂天等）比對，
#           規格類似即可（不需完全相同），但保證「絕對要有價格」——
#           就算 Gemini 完全無回應，也會用核心售價 ±30% 做本地保底估算
#           （標記為 low 品質，不會跟真實查到的行情混淆）。
#   同一份文案 / 同一個關鍵字重複執行不會重打 API（雜湊快取），
#   失敗結果不會被快取（下次會自動重試），啟動時也會自動清除舊版殘留的
#   失敗快取紀錄。
#
# ── 額度管理 ───────────────────────────────────────────────────────
#   模型用 gemini-flash-latest 別名（自動指向當前最新穩定 Flash 模型，
#   不受單一版本下架影響；可用環境變數 GEMINI_MODEL_OVERRIDE 指定固定版本）。
#   429 限流錯誤會解析 Google 回傳的 quotaId/retryDelay，精準判斷是每分鐘
#   還是每日額度，並用建議的等待秒數重試；判定為每日額度用完時，批次處理
#   會立即停止（不會對剩餘專案繼續徒勞重試），已完成的結果不會遺失。
#
# ── 使用方式 ────────────────────────────────────────────────────────
#   單一專案測試：
#     from zeczec_market_price import run_test
#     run_test("PF1_plans.txt", "PF1_content.txt")
#
#   批次處理整個資料集（走訪含 *_content.txt 的資料夾，輸出成 CSV）：
#     from zeczec_market_price import batch_run
#     batch_run(root_dir="ZecZec_Dataset_E&G", output_csv="market_price_results.csv")
#
#   API Key 設定（三選一，優先序：環境變數 → Colab Secrets → 互動輸入）：
#     os.environ["GEMINI_API_KEY"] = "AIza..."          # 本機/Jupyter
#     Colab 左側 🔑 面板新增 GEMINI_API_KEY               # Colab
#     不設定的話，執行時會跳出 getpass 輸入框請你貼上         # 兩者皆可

import subprocess, sys

def _pip_install(pkg):
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", pkg])

# ▼ 修改點 1：加上 ("duckduckgo-search", "duckduckgo_search") 讓雲端自動安裝免費搜尋工具
for pkg, imp in [("google-genai", "google.genai"), ("numpy", "numpy"),
                 ("requests", "requests"), ("ddgs", "ddgs")]:
    try:
        __import__(imp)
    except ImportError:
        _pip_install(pkg)

import os, re, json, time, hashlib, warnings
import numpy as np
import requests
from google import genai
from google.genai import types
from typing import Optional, Dict, Any, Tuple, List

#==========================================#
# 雲端硬碟連線（僅 Colab 環境需要，其他環境自動略過）#
#==========================================#
try:
    from google.colab import drive
    drive.mount('/content/drive')
except ImportError:
    pass  # 非 Colab 環境（本機/伺服器），不需要掛載雲端硬碟

#==========================================#

# ══════════════════════════════════════════════════════════════════════
# 真實比價：直接呼叫電商平台自己的搜尋 API，取得當下真實上架商品
# ══════════════════════════════════════════════════════════════════════
# ⚠️ 重要說明：以下兩個端點是蝦皮／PChome「網頁本身」用來渲染搜尋結果的
# API，並非官方公開文件化的介面，沒有金鑰、不需授權，但也隨時可能因
# 平台改版或加強反爬蟲機制而失效或被擋。設計上完全採「失敗就安靜跳過」，
# 不會讓整體流程中斷——抓不到真實上架資料時會自動退回下一層
# （DDGS網路檢索 + Gemini 分析 → 本地品類猜測 → 核心售價±30%）。
# 這一段呼叫的是「真實網路請求」，不是 Gemini，不消耗任何 Gemini 額度。

def _relevance_score(keyword: str, title: str) -> float:
    """估算關鍵字跟商品標題的相關程度（0~1）：用中文字元的重疊比例，
    並加入長度懲罰。
    用途：獨創/小眾商品在電商平台上常常找不到完全對應的東西，如果抓回來的
    商品標題跟關鍵字幾乎沒有重疊，代表這根本不是同類商品，不應該被拿來比價
    —— 與其硬湊一個不相關的價格，不如誠實判定「找不到直接可比對象」，
    讓上層退到品類層級去找替代品。
    ⚠️ v9 修正：原本只除以「關鍵字字元數」，會讓標題落落長、關鍵字剛好
    都零星出現在裡面的不相關商品（例如「藍牙耳機收納盒」對「藍牙耳機」）
    被誤判成高相關。改除以「關鍵字與標題字元數的較大值」，避免這種情況。"""
    kw_chars = set(re.sub(r'[\s\d]+', '', keyword))
    title_chars = set(re.sub(r'[\s\d]+', '', title))
    if not kw_chars or not title_chars:
        return 0.0
    overlap = len(kw_chars & title_chars)
    return overlap / max(len(kw_chars), len(title_chars))


def _scrape_shopee(keyword: str, limit: int = 20) -> List[Dict[str, Any]]:
    """直接呼叫蝦皮的搜尋 API，取得目前真實上架商品的標題與價格。"""
    url = "https://shopee.tw/api/v4/search/search_items"
    params = {
        "by": "relevancy", "keyword": keyword, "limit": limit,
        "newest": 0, "order": "desc", "page_type": "search",
        "scenario": "PAGE_GLOBAL_SEARCH", "version": 2,
    }
    headers = {
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"),
        "Referer": f"https://shopee.tw/search?keyword={keyword}",
        "Accept": "application/json",
    }
    items: List[Dict[str, Any]] = []
    try:
        resp = requests.get(url, params=params, headers=headers, timeout=8)
        resp.raise_for_status()
        data = resp.json()
        for entry in (data.get("items") or []):
            item = entry.get("item_basic") or entry.get("item") or {}
            name = str(item.get("name", "")).strip()
            price_raw = item.get("price", 0) or 0
            price = round(price_raw / 100000)  # 蝦皮價格單位是「新台幣的十萬分之一」
            if name and 10 < price < 500_000:
                items.append({"title": name, "price": int(price), "platform": "蝦皮購物"})
    except Exception as e:
        print(f"  ⚠️  蝦皮真實比價查詢失敗（{type(e).__name__}），略過此來源")
    return items


def _scrape_pchome(keyword: str, limit: int = 20) -> List[Dict[str, Any]]:
    """直接呼叫 PChome 24h 購物的搜尋 API，取得目前真實上架商品。"""
    url = "https://ecshweb.pchome.com.tw/search/v3.3/all/results"
    params = {"q": keyword, "page": 1, "sort": "sale/dc"}
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
    items: List[Dict[str, Any]] = []
    try:
        resp = requests.get(url, params=params, headers=headers, timeout=8)
        resp.raise_for_status()
        data = resp.json()
        for p in (data.get("prods") or [])[:limit]:
            name = str(p.get("name", "")).strip()
            price = p.get("price", 0) or 0
            if name and 10 < price < 500_000:
                items.append({"title": name, "price": int(price), "platform": "PChome 24h購物"})
    except Exception as e:
        print(f"  ⚠️  PChome真實比價查詢失敗（{type(e).__name__}），略過此來源")
    return items


def _fetch_real_listings(keyword: str, min_relevance: float = 0.35
                         ) -> Tuple[int, int, List[str], List[Dict[str, Any]]]:
    """真實比價主流程：直接查詢多個平台的真實上架商品，用相關度過濾掉
    不相關的雜訊，只保留跟關鍵字夠像的商品，再從這些真實價格算出區間。
    完全不經過 Gemini，回傳的每一筆價格都對應一個真實商品標題可供核對。

    回傳：(price_min, price_max, 命中的平台清單, 匹配到的商品明細列表)
    找不到足夠相關的真實商品時，price_min/max 會是 0，代表這是一件
    "獨創/小眾商品，市場上找不到直接對應物"，應該讓上層退到品類層級比對。
    """
    all_items = _scrape_shopee(keyword) + _scrape_pchome(keyword)
    if not all_items:
        return 0, 0, [], []

    matched = []
    for it in all_items:
        score = _relevance_score(keyword, it["title"])
        if score >= min_relevance:
            it["relevance"] = round(score, 2)
            matched.append(it)

    if len(matched) < 2:
        # 相關度夠高的真實商品不到2筆，代表這個關鍵字在市場上找不到足夠
        # 直接可比對的東西（很可能是獨創/小眾商品），誠實回報找不到，
        # 讓上層退到「品類層級」去找替代品比價，而不是硬湊。
        return 0, 0, [], matched

    matched.sort(key=lambda x: -x["relevance"])
    prices = sorted(it["price"] for it in matched)
    p_min = int(np.percentile(prices, 25))
    p_max = int(np.percentile(prices, 75))
    if p_min == p_max:
        p_min, p_max = int(p_min * 0.85), int(p_max * 1.15)
    platforms = sorted({it["platform"] for it in matched})
    return p_min, p_max, platforms, matched


# ══════════════════════════════════════════════════════════════════════
# 真實比價模組：直接從商品頁面抓取結構化價格資料（非 AI 詮釋文字）
# ══════════════════════════════════════════════════════════════════════
# 原理：電商網站為了讓 Google 購物比價卡片能正確顯示，商品頁 HTML 裡通常
# 會埋一段 JSON-LD 結構化資料（<script type="application/ld+json">），
# 裡面的 price 欄位是網站自己寫給搜尋引擎看的正確數字，不需要 AI 猜測。
# 這比「搜尋片段 → 丟給 Gemini 解讀」可信得多，因為數字是直接從網頁原始
# 資料撈出來的，而且附有網址可以直接回頭核對。
#
# ⚠️ 已知限制：
#   - 蝦皮反爬蟲防護強，直接發送 HTTP 請求常會被擋下或拿到空頁面
#     （沒有執行 JavaScript），這種情況會抓不到，屬於技術上的硬限制
#   - momo / PChome / 博客來對一般請求通常較寬容，成功率較高
#   - 完全獨創、市場上沒有對應商品的募資項目，本來就不會有結果，
#     這是正確、預期中的行為，不代表程式有問題
# ══════════════════════════════════════════════════════════════════════

_ECOMMERCE_DOMAINS = {
    # ⚠️ shopee.tw（蝦皮購物）：實測整站為純前端JS渲染（訪問任一頁面在不執行
    # JS的情況下只會拿到「Please enable JavaScript」的殼），requests.get
    # 永遠抓不到商品資料。保留在白名單中純粹是為了「識別/標記」用途
    # （例如 _relevance_score 之外的地方需要判斷這是蝦皮連結），但在
    # _verify_real_prices 實際發送HTTP請求前，會先用 _JS_ONLY_DOMAINS
    # 直接跳過，不浪費逾時等待時間。
    "shopee.tw":              "蝦皮購物",
    "momoshop.com.tw":        "momo購物網",
    "pchome.com.tw":          "PChome 24h購物",
    "books.com.tw":           "博客來",
    "shopping.friday.tw":     "friDay購物",
    "rakuten.com.tw":         "樂天市場",
    "buy.yahoo.com":          "Yahoo奇摩購物中心",
    "shopping.pchome.com.tw": "PChome線上購物",
    # ── v12 新增：原本完全遺漏、但RAG搜尋結果中常出現且可正常爬取的平台 ──
    "ruten.com.tw":           "露天市集",       # 伺服器端渲染，商品資訊直接在HTML中
    "tw.bid.yahoo.com":       "Yahoo拍賣",       # ⚠️ 注意：與 buy.yahoo.com（購物中心）是不同網域
}

# 已知純前端JS渲染、requests.get 無法取得商品資料的網域。
# Tier0 真實比價遇到這些網域會直接跳過 HTTP 請求（fail-fast），
# 節省逾時等待時間，並讓 log 更清楚標示「不是抓取失敗，是這個平台本來就抓不到」。
_JS_ONLY_DOMAINS = {"shopee.tw"}


_LISTING_PAGE_PATTERNS = re.compile(
    r'/(search|category|categories|list|find)(/|\?|$)'
    r'|[?&](keyword|q|query|k|cateid)=',
    re.IGNORECASE
)


def _looks_like_listing_page(url: str) -> bool:
    """粗略判斷網址是否為分類總覽頁/搜尋結果列表頁（而非單一商品詳情頁）。
    這類頁面即使成功抓到HTML，也幾乎不會包含單一商品的JSON-LD結構化資料
    （那是商品詳情頁專屬的），提前過濾可以省下無謂的HTTP請求，也降低
    因為短時間內對同一平台發太多請求而觸發429限流的機率。
    這是啟發式規則，並非100%準確——寧可少數真正的商品頁被誤判跳過，
    也不要把大量請求浪費在注定拿不到資料的列表頁上。"""
    return bool(_LISTING_PAGE_PATTERNS.search(url))


def _match_ecommerce_platform(url: str) -> Optional[str]:
    """判斷網址是否屬於已知的台灣電商網域，回傳正規化後的平台名稱。"""
    try:
        from urllib.parse import urlparse
        netloc = urlparse(url).netloc.lower()
        netloc = re.sub(r'^www\.', '', netloc)
    except Exception:
        return None
    for domain, name in _ECOMMERCE_DOMAINS.items():
        if domain in netloc:
            return name
    return None


def _find_price_in_json(d: Any, depth: int = 0) -> Optional[float]:
    """遞迴尋找 JSON-LD 結構裡的 price 欄位（可能包在 offers/@graph 底下）。"""
    if depth > 4:
        return None
    if isinstance(d, dict):
        if "price" in d:
            try:
                return float(str(d["price"]).replace(",", ""))
            except Exception:
                pass
        for key in ("offers", "@graph"):
            val = d.get(key)
            if val is not None:
                r = _find_price_in_json(val, depth + 1)
                if r is not None:
                    return r
    elif isinstance(d, list):
        for item in d:
            r = _find_price_in_json(item, depth + 1)
            if r is not None:
                return r
    return None


def _find_name_in_json(d: Any, depth: int = 0) -> Optional[str]:
    """遞迴尋找 JSON-LD 結構裡的 name 欄位（商品標題），供相關度比對用。"""
    if depth > 4:
        return None
    if isinstance(d, dict):
        name = d.get("name")
        if isinstance(name, str) and name.strip():
            return name.strip()
        for key in ("offers", "@graph"):
            val = d.get(key)
            if val is not None:
                r = _find_name_in_json(val, depth + 1)
                if r is not None:
                    return r
    elif isinstance(d, list):
        for item in d:
            r = _find_name_in_json(item, depth + 1)
            if r is not None:
                return r
    return None


def _extract_price_from_html(html: str) -> Optional[float]:
    """從網頁 HTML 中抓取結構化 price 資料，優先找 JSON-LD，備援找 Open Graph meta。
    ⚠️ v14 新增：露天市集（ruten.com.tw）實測完全沒有 JSON-LD 也沒有
    og:price:amount，但該商品自己的價格會出現在 meta-description/
    og:description 裡的固定格式文字「直購價: 659 - 699」，範圍精準侷限在
    該商品本身（不像PChome那樣頁面上還混雜了大量「別人也看了」推薦商品的
    價格），抓這個是安全的。若有價格區間（例如多規格），取區間下限，
    對應「最低可購入價格」，跟其他平台的邏輯一致。"""
    for m in re.finditer(
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        html, re.DOTALL | re.IGNORECASE
    ):
        try:
            data = json.loads(m.group(1).strip())
        except Exception:
            continue
        price = _find_price_in_json(data)
        if price is not None:
            return price
    m2 = re.search(r'property=["\']product:price:amount["\']\s+content=["\']([\d.]+)["\']', html)
    if m2:
        try:
            return float(m2.group(1))
        except Exception:
            pass
    # 露天市集專屬格式："直購價: 659 - 699" 或 "直購價: 699"（單一價格時無區間）
    m3 = re.search(r'直購價[:：]\s*([\d,]+)', html)
    if m3:
        try:
            return float(m3.group(1).replace(',', ''))
        except Exception:
            pass
    return None


def _extract_title_from_html(html: str) -> Optional[str]:
    """從網頁 HTML 中抓取商品標題，優先找 JSON-LD 的 name 欄位，
    備援找 Open Graph og:title meta。用於：
      1. 判斷抓到的商品跟關鍵字是否真的相關（_relevance_score）
      2. 寫入 CSV / cache 供人工回頭核對，避免「verified」卻抓錯商品而不自知"""
    for m in re.finditer(
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        html, re.DOTALL | re.IGNORECASE
    ):
        try:
            data = json.loads(m.group(1).strip())
        except Exception:
            continue
        name = _find_name_in_json(data)
        if name:
            return name[:80]
    m2 = re.search(r'property=["\']og:title["\']\s+content=["\']([^"\']+)["\']', html, re.IGNORECASE)
    if m2:
        return m2.group(1).strip()[:80]
    return None


_MIN_TITLE_RELEVANCE = 0.30   # 標題跟關鍵字相關度低於此值，視為不相關商品，直接濾掉
_EXTREME_PRICE_RATIO = (0.2, 5.0)  # 與核心售價的比值超出此區間，標記為 extreme（可能抓錯商品層級）

# ⚠️ v17 新增：Tier0逐筆候選的診斷print（跳過列表頁、HTTP失敗、解析失敗等）
# 在確定問題根因後已經完成階段性任務，平常執行時開著只會洗版、佔用output
# 版面。預設關閉，只保留「每個專案一行」的統計摘要（在_verify_real_prices
# 結尾印出）。要重新診斷Tier0問題時，把這個改成True即可還原詳細log。
TIER0_VERBOSE = False


def _verify_real_prices(keyword: str, core_price_hint: int = 0,
                        max_candidates: int = 8, max_fetch: int = 4,
                        timeout: float = 6.0) -> List[Dict[str, Any]]:
    """搜尋並實際抓取商品頁面，從結構化資料驗證真實價格。
    回傳 [{"price": int, "platform": str, "url": str, "title": str,
           "relevance": float, "price_sanity": "normal"/"extreme"}, ...]。
    找不到（空list）不代表商品不存在，可能是反爬蟲擋掉、逾時，或這個
    商品本身在市場上沒有對應品項（例如完全獨創的募資商品）——這種情況
    是正確、預期中的行為，上層會自動退到下一層較低信心的方法。

    ⚠️ v10 修正（可靠性）：舊版只要抓到「任何一筆」結構化價格就直接視為
    verified，曾經出現「關鍵字混雜多種商品特徵 → 抓到規格完全不同的單一
    商品 → 卻標成最高信心等級」的誤判（例如核心價NT$4,990、卻verified出
    NT$1,530，偏離+226%）。這裡加兩道防線：
      1. 抓到標題後用 _relevance_score 過濾，標題跟關鍵字相關度太低直接濾掉
      2. 若有核心售價可參考，價格跟核心售價比值過於懸殊（<0.2倍或>5倍）
         標記為 price_sanity="extreme"，交由上層決定是否降級信心等級，
         而不是在這裡直接隱藏——保留完整資訊讓人工可以回頭核對。
    """
    verified: List[Dict[str, Any]] = []
    stats = {"candidates": 0, "platform_matched": 0, "listing_page_skipped": 0,
              "http_ok": 0, "price_extracted": 0, "relevance_passed": 0}

    # ⚠️ v13 修正（重大）：舊版只發一個通用查詢「{keyword} 價格」，DDGS對這種
    # 籠統查詢常常回傳「分類總覽頁」「搜尋結果列表頁」「比價文章」，而不是
    # 真正的單一商品詳情頁——JSON-LD結構化資料只存在於商品詳情頁，列表頁
    # 不管網域名單多完整、標頭多像瀏覽器都不會有。實測診斷log證實了這點
    # （例如抓到momoshop.com.tw/search/apple+watch這種搜尋頁，價格解析必然是0）。
    # 改法：對「已知能穩定爬取的平台」發 site: 限定搜尋，大幅提高命中真正商品
    # 詳情頁的機率，而不是靠通用查詢碰運氣。
    _TIER0_PRIORITY_SITES = ["momoshop.com.tw", "pchome.com.tw", "ruten.com.tw"]
    try:
        from ddgs import DDGS
        ddgs = DDGS()
        results: List[Dict[str, Any]] = []
        seen_urls = set()
        for site in _TIER0_PRIORITY_SITES:
            try:
                site_results = ddgs.text(f"{keyword} site:{site}", region="tw-tzh",
                                         max_results=max(3, max_candidates // len(_TIER0_PRIORITY_SITES)))
            except Exception as e:
                if TIER0_VERBOSE:
                    print(f"  ⚠️  [Tier0診斷] site:{site} 搜尋失敗：{e}")
                site_results = []
            for r in (site_results or []):
                u = r.get("href") or r.get("url") or ""
                if u and u not in seen_urls:
                    seen_urls.add(u)
                    results.append(r)
        # 站內搜尋若完全沒回收到任何候選（例如關鍵字太冷門），退回通用查詢兜底
        if not results:
            try:
                results = ddgs.text(f"{keyword} 價格", region="tw-tzh", max_results=max_candidates) or []
            except Exception:
                results = []
    except Exception as e:
        if TIER0_VERBOSE:
            print(f"  ⚠️  [Tier0診斷] DDGS搜尋本身失敗：{e}")
        return verified

    results = results or []
    stats["candidates"] = len(results)
    if not results:
        return verified

    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                             "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"}
    fetched = 0
    skipped_no_platform = 0
    for r in results:
        if fetched >= max_fetch:
            break
        url = r.get("href") or r.get("url") or ""
        platform = _match_ecommerce_platform(url)
        if not platform:
            skipped_no_platform += 1
            continue
        stats["platform_matched"] += 1
        try:
            from urllib.parse import urlparse
            netloc = re.sub(r'^www\.', '', urlparse(url).netloc.lower())
        except Exception:
            netloc = ""
        if any(js_domain in netloc for js_domain in _JS_ONLY_DOMAINS):
            continue
        # ⚠️ v13 新增：URL特徵過濾——分類頁/搜尋結果頁/列表頁不會有單一商品的
        # JSON-LD，直接跳過不發HTTP請求，省下時間也降低觸發平台限流(429)的機率。
        if _looks_like_listing_page(url):
            stats["listing_page_skipped"] += 1
            if TIER0_VERBOSE:
                print(f"  ⏭️  跳過 {platform}（URL特徵像分類/搜尋列表頁）：{url[:80]}")
            continue
        fetched += 1
        if fetched > 1:
            time.sleep(0.6)  # 請求間短暫間隔，降低連續打同一平台觸發429限流的機率
        try:
            resp = requests.get(url, headers=headers, timeout=timeout)
            if resp.status_code != 200:
                if TIER0_VERBOSE:
                    print(f"  ⚠️  [Tier0診斷] HTTP {resp.status_code}：{url[:80]}")
                continue
            stats["http_ok"] += 1
            price = _extract_price_from_html(resp.text)
            if not (price and 10 < price < 1_000_000):
                if TIER0_VERBOSE:
                    print(f"  ⚠️  [Tier0診斷] 無JSON-LD/og:price：{url[:80]}")
                continue
            stats["price_extracted"] += 1
            title = _extract_title_from_html(resp.text) or ""
            relevance = _relevance_score(keyword, title) if title else 0.0
            if title and relevance < _MIN_TITLE_RELEVANCE:
                if TIER0_VERBOSE:
                    print(f"  🚫 已濾掉不相關商品（相關度{relevance:.2f} < {_MIN_TITLE_RELEVANCE}）："
                          f"「{title}」NT${int(price):,}")
                continue
            if not title:
                if TIER0_VERBOSE:
                    print(f"  ⚠️  [Tier0診斷] 抓到價格但抓不到標題，保守起見濾掉：{url[:80]}")
                continue
            stats["relevance_passed"] += 1
            sanity = "normal"
            if core_price_hint > 0:
                ratio = price / core_price_hint
                if ratio < _EXTREME_PRICE_RATIO[0] or ratio > _EXTREME_PRICE_RATIO[1]:
                    sanity = "extreme"
            verified.append({
                "price": int(price), "platform": platform, "url": url,
                "title": title, "relevance": round(relevance, 2),
                "price_sanity": sanity,
            })
        except Exception as e:
            if TIER0_VERBOSE:
                print(f"  ⚠️  [Tier0診斷] 請求/解析失敗（{type(e).__name__}）：{url[:80]}")
            continue  # 反爬蟲擋下/逾時/網路問題，略過這筆繼續下一個候選
    if TIER0_VERBOSE and not verified:
        print(f"  📊 [Tier0診斷統計] 候選{stats['candidates']}筆 → "
              f"平台匹配{stats['platform_matched']}筆 → "
              f"(略過列表頁{stats['listing_page_skipped']}筆) → HTTP成功{stats['http_ok']}筆 → "
              f"解析出價格{stats['price_extracted']}筆 → 通過相關度檢查{stats['relevance_passed']}筆")
    return verified


# ▼ 原本的 RAG 免費檢索小幫手：抓不到足夠真實上架商品時的次要備援
def _free_web_search(keyword: str, max_results: int = 5) -> Tuple[str, bool]:
    """使用最新版 ddgs 查詢台灣電商真實售價字串。
    回傳 (餵給 Gemini 的內容, 是否為真實搜尋結果)——第二個值讓上層可以清楚
    知道這筆市場價到底有沒有真實網路佐證，還是完全靠 Gemini 自己的知識推斷，
    避免「掛著 RAG 真實檢索的名號，實際上什麼都沒查到」這種混淆可信度的情況。
    """
    try:
        from ddgs import DDGS
        query = f"{keyword} 價格 蝦皮 momo"
        results = DDGS().text(query, region="tw-tzh", max_results=max_results)
        if not results:
            return "（無直接搜尋結果，請依你的台灣電商知識估算）", False
        snippets = [f"[{i+1}] {r.get('title', '')} | {r.get('body', '')}" for i, r in enumerate(results)]
        return "\n".join(snippets), True
    except Exception as e:
        return f"（網路檢索暫時無回應：{e}，請依你的台灣電商知識估算）", False

# ══════════════════════════════════════════════════════════════════════
# ⚙️  設定區
# ══════════════════════════════════════════════════════════════════════
warnings.filterwarnings("ignore")

PLANS_FILE   = "TS1_plans.txt"
CONTENT_FILE = "TS1_content.txt"

CACHE_FILE      = "market_price_cache.json"
LLM_MAX_CHARS   = 3000
# 用「latest」別名而非釘死版本號，Google 之後汰換模型世代時會自動指向當時的
# 最新穩定 Flash 模型，不需要每次舊版本停用（例如 gemini-2.5-flash 已不開放
# 新帳號使用）就要手動改程式碼。如果你想固定用某個特定版本（例如評估用途
# 需要結果可重現），可以改成明確版本號，或設定環境變數 GEMINI_MODEL_OVERRIDE。
GEMINI_MODEL    = os.environ.get("GEMINI_MODEL_OVERRIDE", "gemini-3.5-flash-lite")


def _get_api_key() -> str:
    """依序嘗試：環境變數 → Colab Secrets → 互動輸入，避免把金鑰寫死在程式碼裡。"""
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    if key:
        return key

    # Colab Secrets（左側 🔑 面板設定的密鑰）
    try:
        from google.colab import userdata  # 只有在 Colab 環境才存在
        try:
            key = (userdata.get("GEMINI_API_KEY") or "").strip()
            if key:
                os.environ["GEMINI_API_KEY"] = key
                return key
        except Exception:
            pass  # 使用者未設定該 Secret，往下走互動輸入
    except ImportError:
        pass  # 非 Colab 環境

    # 互動輸入（Colab / Jupyter / 終端機皆可用）
    try:
        import getpass
        key = getpass.getpass("請貼上你的 GEMINI_API_KEY（輸入內容不會顯示）：").strip()
        if key:
            os.environ["GEMINI_API_KEY"] = key
    except Exception:
        pass

    return key

# ══════════════════════════════════════════════════════════════════════


def _read_file(path: str) -> str:
    if not os.path.isfile(path):
        print(f"  ⚠️  找不到檔案：{path}")
        return ""
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        return f.read()

def _parse_json(raw: str) -> Optional[dict]:
    # 清除 markdown fence
    cleaned = re.sub(r'```(?:json)?|```', '', raw).strip()
    # 1. 正常 parse
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    # 2. JSON 被截斷時：用 regex 抓出 keywords 陣列中所有已完整出現的 "xxx" 字串
    m = re.search(r'"keywords"\s*:\s*\[', cleaned)
    if m:
        arr_fragment = cleaned[m.end():]
        items = re.findall(r'"([^"]+)"', arr_fragment)
        if items:
            return {"keywords": items}
    # 3. 對其他欄位（keyword, core_price 等）：暴力補全尾巴後再 parse
    for suffix in ('"]}', '"', '"]}', ']"}', '"}}', '}', ']}'):
        try:
            return json.loads(cleaned + suffix)
        except json.JSONDecodeError:
            pass
    return None

class DailyQuotaExceededError(Exception):
    """當偵測到 Gemini API 每日額度（RPD）用完時拋出，讓上層（例如批次處理）
    可以判斷要整批停下來，而不是對每個剩餘專案繼續徒勞地重試。"""
    pass


def _call_gemini(client: genai.Client, prompt: str,
                 system: str = "", max_tokens: int = 256,
                 json_mode: bool = True,
                 use_search: bool = False,
                 disable_thinking: bool = True,
                 _retry_count: int = 0) -> Optional[str]:
    # 遇到「無法判斷是分鐘還是每日限制」的模糊 429 錯誤時，用遞增等待時間重試幾次：
    # RPM/TPM（每分鐘）限制一定會在 1 分鐘內的滾動視窗內恢復，如果累積等待超過
    # 這個時間仍然失敗，就幾乎可以確定是 RPD（每日額度）用完，改成直接停止，
    # 而不是每次都只等 20 秒就再送出下一次請求繼續徒勞撞牆。
    _AMBIGUOUS_RETRY_WAITS = [20, 40, 70]   # 累積 130 秒，遠超過 RPM 滾動視窗的 1 分鐘

    cfg_kwargs: Dict[str, Any] = {"max_output_tokens": max_tokens}
    # ⚠️ Google Search Grounding 不支援 response_mime_type，必須分開處理
    if json_mode and not use_search:
        cfg_kwargs["response_mime_type"] = "application/json"
    # ⚠️ gemini-2.5-flash 預設會啟用「思考」，思考過程也會消耗 max_output_tokens 額度，
    # 若 max_tokens 設定較小，容易導致額度全部被思考用光、實際輸出變成空字串
    # （這種情況不會丟例外，只會安靜地失敗）。純分類/JSON 輸出的呼叫不需要思考，
    # 預設關閉以確保 token 額度留給真正的輸出。
    if disable_thinking:
        try:
            cfg_kwargs["thinking_config"] = types.ThinkingConfig(thinking_budget=0)
        except Exception:
            pass
    tools = [types.Tool(google_search=types.GoogleSearch())] if use_search else None
    try:
        resp = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=system or None,
                tools=tools,
                **cfg_kwargs,
            )
        )
        # Grounding 回應可能在多個 candidates/parts 中，需逐一拼接
        if resp.text:
            return resp.text.strip()
        # 備援：手動拼接所有 text parts
        parts = []
        try:
            for cand in (resp.candidates or []):
                for part in (cand.content.parts or []):
                    if hasattr(part, "text") and part.text:
                        parts.append(part.text)
        except Exception:
            pass
        if parts:
            return "".join(parts).strip()

        # 完全沒有文字內容：印出診斷原因，避免安靜失敗
        finish_reason = None
        try:
            finish_reason = resp.candidates[0].finish_reason
        except Exception:
            pass
        if finish_reason and str(finish_reason) not in ("STOP", "1"):
            print(f"  ⚠️  Gemini 回應為空（finish_reason={finish_reason}）。"
                  f"若為 MAX_TOKENS，請調高 max_tokens；若為 SAFETY，"
                  f"代表內容被安全機制擋下。")
        else:
            print("  ⚠️  Gemini 回應為空（無明確原因，可嘗試調高 max_tokens 重試）。")
        return None
    except Exception as e:
        err = str(e)
        if "API_KEY_INVALID" in err or "API key not valid" in err:
            print("  ❌  API Key 無效，請確認金鑰是否正確、是否為 AI Studio 發行的 "
                  "AIza... 開頭金鑰，或是否已被撤銷。前往 "
                  "https://aistudio.google.com/apikey 重新確認/產生。")
            return None
        elif "PERMISSION_DENIED" in err:
            print(f"  ❌  權限不足（PERMISSION_DENIED），請確認該金鑰對應的專案"
                  f"是否已啟用 Generative Language API：{e}")
            return None
        elif "NOT_FOUND" in err or ("404" in err and "model" in err.lower()):
            print(f"  ❌  模型「{GEMINI_MODEL}」已不開放使用（可能是新帳號限制或"
                  f"已下架）。目前程式已改用 gemini-flash-latest 自動指向最新穩定版，"
                  f"若仍出現此錯誤，代表 Google 可能又更換了模型世代，"
                  f"請至 https://ai.google.dev/gemini-api/docs/models 確認目前"
                  f"可用的模型名稱後更新 GEMINI_MODEL：{e}")
            return None
        elif "429" in err or "quota" in err.lower() or "RESOURCE_EXHAUSTED" in err:
            err_lower = err.lower()
            # 優先解析 Google 回傳的結構化資訊：
            #   quotaId 明確標示 PerMinute / PerDay（比關鍵字比對可靠）
            #   retryDelay 是 Google 自己算好的建議等待秒數（比亂猜的固定秒數精準）
            quota_id_match  = re.search(r"'quotaId':\s*'([^']+)'", err)
            retry_delay_match = re.search(r"'retryDelay':\s*'(\d+(?:\.\d+)?)s'", err)
            quota_id = quota_id_match.group(1) if quota_id_match else ""
            retry_delay = float(retry_delay_match.group(1)) + 2 if retry_delay_match else None  # +2秒緩衝

            is_per_day = ("PerDay" in quota_id or "per day" in err_lower
                          or "perday" in err_lower.replace(" ", ""))
            is_per_minute = ("PerMinute" in quota_id or "per minute" in err_lower
                             or "rpm" in err_lower or "tpm" in err_lower)

            if is_per_day:
                print("  🛑 已達【每日額度上限】（RPD），短暫等待沒有用，"
                      "要等到太平洋時間午夜 00:00（約台灣時間下午 3~4 點）才會重置。\n"
                      "     可到 https://aistudio.google.com/usage 查看即時用量與重置時間，"
                      "或考慮升級付費層級提高額度。")
                raise DailyQuotaExceededError(str(e))
            elif is_per_minute:
                wait = retry_delay if retry_delay else 20
                print(f"  ⚠️  已達【每分鐘額度上限】（{quota_id or 'RPM/TPM'}），"
                      f"等待 {wait:.0f} 秒後重試"
                      f"{'（採用 Google 建議的 retryDelay）' if retry_delay else ''}...")
                time.sleep(wait)
                if _retry_count < 3:
                    return _call_gemini(client, prompt, system, max_tokens, json_mode,
                                        use_search, disable_thinking, _retry_count + 1)
                print("  🛑 已重試多次仍持續被限流，這已超過 RPM 限制正常恢復的時間，"
                      "判定為每日額度用完，停止本次批次。")
                raise DailyQuotaExceededError(str(e))
            else:
                # 訊息本身沒有明確標示是分鐘還是每日限制，用遞增等待時間重試，
                # 累積等待時間遠超過 RPM 的 1 分鐘滾動視窗；若重試完仍失敗，
                # 判定為每日額度用完，直接停止而不是繼續無意義地重試。
                if _retry_count < len(_AMBIGUOUS_RETRY_WAITS):
                    wait = retry_delay if retry_delay else _AMBIGUOUS_RETRY_WAITS[_retry_count]
                    print(f"  ⚠️  Rate Limit（無法判斷是分鐘還是每日限制），"
                          f"第 {_retry_count + 1}/{len(_AMBIGUOUS_RETRY_WAITS)} 次重試，"
                          f"等待 {wait:.0f} 秒...\n"
                          f"     可到 https://ai.dev/rate-limit 查看即時用量")
                    time.sleep(wait)
                    return _call_gemini(client, prompt, system, max_tokens, json_mode,
                                        use_search, disable_thinking, _retry_count + 1)
                print(f"  🛑 已重試 {len(_AMBIGUOUS_RETRY_WAITS)} 次、累積等待超過 1 分鐘"
                      f"仍持續被限流——RPM/TPM 限制正常應該早就恢復了，判定為每日額度"
                      f"（RPD）用完，停止本次批次。\n"
                      f"     詳細訊息：{e}\n"
                      f"     可到 https://ai.dev/rate-limit 或 https://aistudio.google.com/usage"
                      f" 確認實際用量。")
                raise DailyQuotaExceededError(str(e))

        elif "503" in err or "UNAVAILABLE" in err or "high demand" in err.lower():
            wait = 6 if _retry_count == 0 else 15
            print(f"  ⏳ Google 伺服器目前尖峰繁忙 (503 High Demand)，等待 {wait} 秒後自動重試...")
            time.sleep(wait)
            if _retry_count < 3:
                return _call_gemini(client, prompt, system, max_tokens, json_mode,
                                    use_search, disable_thinking, _retry_count + 1)
            print("  ⚠️ 伺服器持續超載，本次請求略過。")
            return None

        elif "INVALID_ARGUMENT" in err or "mime" in err.lower():
            # 💡【專為 3.5 Flash 等新世代模型設計：衝突參數自動剔除】
            # 當 latest 指向的新模型不接受 thinking_config 時，自動拔掉它並秒速重試！
            if "thinking_config" in cfg_kwargs:
                print("  💡 偵測到當前模型（如 3.5 Flash）不適用 thinking_config，自動剔除該參數後重試...")
                cfg_kwargs.pop("thinking_config")
                return _call_gemini(client, prompt, system, max_tokens, json_mode,
                                    use_search, disable_thinking=False, _retry_count=_retry_count + 1)

            print(f"  ⚠️  API 參數錯誤（可能 mime_type 衝突）：{e}")
            return None
        else:
            print(f"  ⚠️  Gemini 錯誤：{e}")
            return None


# ── 平台名稱正規化：Gemini 有時寫全名、有時寫簡稱（例如「PChome」vs
#    「PChome 24h購物」），若不正規化直接去重，會讓同一個平台被算成兩筆，
#    虛灌 data_quality（≥2平台交叉比對）這個信任度指標。────────────────
_PLATFORM_ALIASES = {
    "蝦皮": "蝦皮購物", "shopee": "蝦皮購物", "蝦皮購物": "蝦皮購物",
    "momo": "momo購物網", "momo購物網": "momo購物網", "momo購物": "momo購物網",
    "pchome": "PChome 24h購物", "pchome24h": "PChome 24h購物",
    "pchome24h購物": "PChome 24h購物", "pchome 24h購物": "PChome 24h購物",
    "yahoo": "Yahoo奇摩購物中心", "yahoo奇摩": "Yahoo奇摩購物中心",
    "yahoo奇摩購物": "Yahoo奇摩購物中心", "yahoo奇摩購物中心": "Yahoo奇摩購物中心",
    "yahoo購物中心": "Yahoo奇摩購物中心",
    "樂天": "樂天市場", "樂天市場": "樂天市場", "rakuten": "樂天市場",
    "森森": "森森購物", "森森購物": "森森購物",
    "生活市集": "生活市集",
    "friday": "friDay購物", "friday購物": "friDay購物",
    "博客來": "博客來",
    "東森": "東森購物", "東森購物": "東森購物",
}


def _normalize_platform(name: str) -> str:
    key = re.sub(r'\s+', '', name.strip().lower())
    return _PLATFORM_ALIASES.get(key, name.strip())


# ── 本地免費品類猜測：當 Call 1 完全判斷失敗（真的回傳「未分類商品」）時，
#    與其直接放棄改用「核心售價±30%」這種完全脫離商品本質的猜測，
#    不如先比對文案裡有沒有出現常見品類關鍵字，猜出「這大概是哪一類商品」，
#    再拿這個廣泛品類去搜尋類似/替代品的市場行情——即使不夠精準，也遠比
#    純粹用價格倒推更貼近商品本質。這一步完全在本地比對，不需要額外的
#    API 呼叫，不會增加任何額度消耗。──────────────────────────────────
_CATEGORY_KEYWORDS: Dict[str, List[str]] = {
    "穿戴式3C裝置":   ["智慧眼鏡", "智慧手錶", "手環", "穿戴", "AI眼鏡", "藍牙耳機", "耳機",
                     "智慧戒指", "運動手環", "體感裝置"],
    "行車記錄器/安全帽": ["行車記錄器", "行車紀錄器", "安全帽", "機車", "行車影像", "後照鏡型記錄器"],
    "電動車/充電設備": ["電動車", "充電樁", "充電器", "充電站", "電動機車", "電池", "行動電源",
                     "太陽能板", "逆變器", "電動滑板車", "移動電源"],
    "錄音/翻譯裝置":  ["錄音筆", "翻譯機", "語音翻譯", "轉文字", "錄音卡", "口譯機", "會議記錄器"],
    "家電廚房用品":   ["冰機", "雪花冰", "冷氣", "電風扇", "吸塵器", "除濕機",
                     "空氣清淨機", "電鍋", "微波爐", "烤箱", "調理機", "氣炸鍋",
                     "洗碗機", "洗衣機", "烘衣機", "熱水器", "咖啡機", "製冰機",
                     "電暖器", "循環扇", "淨水器", "濾水器"],
    "戶外露營用品":   ["登山", "露營", "帳篷", "背包", "睡袋", "戶外", "野營", "登山杖",
                     "露營燈", "野炊", "折疊桌椅", "爐具", "營燈", "睡墊"],
    "保溫瓶水壺類":   ["保溫瓶", "保溫杯", "水壺", "隨行杯", "保溫罐", "悶燒罐"],
    "服飾配件":     ["衣服", "外套", "上衣", "褲", "鞋", "包包", "帽子", "手錶",
                     "圍巾", "襪子", "手套", "皮帶", "背心", "機能衣"],
    "書籍出版品":    ["書籍", "書本", "小說", "繪本", "書籤", "出版", "漫畫", "雜誌"],
    "文具用品":     ["文具", "筆記本", "原子筆", "鋼筆", "貼紙", "資料夾", "書桌", "文件夾"],
    "美妝保養品":    ["面膜", "精華液", "乳液", "保養品", "化妝品", "護膚", "洗髮精",
                     "沐浴乳", "防曬", "香水"],
    "食品飲品":     ["茶葉", "咖啡豆", "餅乾", "零食", "飲品", "沖泡", "巧克力",
                     "麵包", "調味料", "醬料", "保健食品", "營養補充品"],
    "桌遊卡牌遊戲":   ["桌遊", "卡牌", "牌卡", "骰子", "遊戲卡", "撲克牌"],
    "居家生活用品":   ["收納", "廚房用品", "寢具", "家具", "床墊", "枕頭", "地墊",
                     "窗簾", "毛巾", "拖鞋", "衣架", "垃圾桶"],
    "3C周邊配件":    ["行動電源", "手機殼", "滑鼠", "鍵盤", "喇叭", "音響", "螢幕保護貼",
                     "充電線", "傳輸線", "藍牙喇叭", "隨身碟", "讀卡機", "手機支架"],
    "監控/攝影器材":  ["監視器", "監控攝影機", "密錄器", "運動攝影機", "空拍機", "無人機",
                     "行動監視器", "針孔攝影機"],
    "健身運動用品":   ["瑜珈墊", "健身器材", "啞鈴", "彈力帶", "跳繩", "運動水壺",
                     "重訓", "拉力器", "護膝", "護具"],
    "寵物用品":     ["寵物", "貓砂", "狗糧", "貓糧", "寵物碗", "牽繩", "寵物床"],
    "嬰幼兒用品":    ["嬰兒車", "尿布", "奶瓶", "安撫", "兒童座椅", "學步"],
    "手作/工藝品":   ["手工", "手作", "編織", "陶藝", "木作", "皮革工藝", "拼布"],
    "美術/繪畫用品":  ["畫筆", "顏料", "畫布", "素描", "美術用品", "水彩"],
    "3C智慧家庭":    ["智慧插座", "智慧燈泡", "智慧門鎖", "智慧音箱", "居家安控", "智慧插頭"],
    "樂器音樂器材":   ["吉他", "烏克麗麗", "麥克風", "混音器", "耳罩式耳機", "樂器"],
    # ── v16 新增：擴充涵蓋更多募資平台常見商品類型，降低最終判斷失敗機率 ──
    "自行車/代步工具": ["自行車", "腳踏車", "滑板", "平衡車", "電動輪椅", "代步車", "折疊車"],
    "投影/顯示設備":  ["投影機", "投影儀", "顯示器", "螢幕", "電子紙", "數位相框"],
    "健康監測裝置":   ["血氧", "血壓計", "體溫計", "健康監測", "心率", "體脂計", "睡眠監測"],
    "五金工具用品":   ["工具箱", "電動起子", "螺絲", "扳手", "手電筒", "五金工具", "電鑽"],
    "香氛清潔用品":   ["香氛", "蠟燭", "擴香", "精油", "清潔劑", "除臭", "芳香劑"],
    "交通載具周邊":   ["車用", "車充", "行車配件", "汽車用品", "車架", "手機架"],
    "VR/AR/投影裝置": ["VR", "AR", "虛擬實境", "擴增實境", "頭戴顯示器"],
    "文創設計商品":   ["桌曆", "月曆", "明信片", "海報", "文創商品", "設計商品", "紀念品"],
}


def _guess_category_keyword(content_text: str) -> str:
    """比對文案內容與本地品類字典，猜出最可能的商品大類（免費，不呼叫API）。
    找不到匹配時回傳空字串，讓上層改用最後手段（核心售價±30%估算）。"""
    scores: Dict[str, int] = {}
    for category, kws in _CATEGORY_KEYWORDS.items():
        hits = sum(content_text.count(kw) for kw in kws)
        if hits > 0:
            scores[category] = hits
    if not scores:
        return ""
    return max(scores, key=scores.get)


# ══════════════════════════════════════════════════════════════════════
# 創新型商品判斷：市場上是否存在真正對應的同類商品
# ══════════════════════════════════════════════════════════════════════
# 募資平台的本質是很多商品屬於全新概念、市場沒有直接可比物。這種情況下
# 硬湊一個「行情區間」再算 price_deviation_ratio，數字容易失真甚至誤導
# （例如硬拿相近品類代替，得出「偏離+200%」，看起來像亂訂價，實際上
# 可能只是真的沒有可比物）。這裡綜合既有訊號給出一個透明度欄位，讓使用
# 這份 CSV 的人知道哪些筆的偏離度數字「不宜直接當成訂價異常來解讀」。
def _judge_novelty(keyword_is_category_fallback: bool,
                   is_verified: bool,
                   market_has_real_search: bool,
                   avg_match_relevance: float,
                   low_sample_warning: bool,
                   data_quality: str,
                   is_multi_function: bool = False,
                   is_totally_unclassified: bool = False) -> Tuple[int, str]:
    """綜合幾個既有訊號，判斷這個商品是否屬於「市場無直接對應物」的創新型商品。
    回傳 (is_innovative, reason)。reason 為空字串代表判定為「市場有對應商品」。
    這是啟發式判斷，非絕對定論，建議搭配 matched_product_titles 人工複核。"""
    if is_totally_unclassified:
        # ⚠️ v15 新增：連「本地品類字典」跟「寬鬆版AI二次判斷」都救不回來的
        # 案例，是所有失敗模式裡最嚴重的一種——這代表市場行情根本沒有經過
        # 任何搜尋，純粹是核心售價±30%的數字保底，跟商品本質完全無關。
        # 獨立標記出來，理由文字要跟「有搜尋但結果不可靠」的情況明確區分開。
        return 1, "AI與本地字典皆無法判斷商品類型，市場行情僅為核心售價±30%數字保底，不具商品本質參考價值"
    if is_multi_function:
        return 1, "商品整合多種原本分屬不同類別的功能（多功能整合商品），市場上通常無直接對應物"
    if keyword_is_category_fallback:
        return 1, "AI精確關鍵字判斷失敗，退回廣泛品類猜測（本地字典或AI寬鬆二次判斷），代表文案內容找不到明確對應規格"
    if not market_has_real_search:
        # ⚠️ v11 修正：不再額外要求 data_quality=="low" 才觸發。原本這裡
        # 誤以為「純AI推斷」一定會被標成 data_quality=low，但AI知識推斷
        # 分支的 data_quality 其實是模型「自報」的信心值（見
        # _fetch_market_range 內 r_ai.get("confidence")），Gemini 完全可能
        # 自稱 high confidence，卻根本沒有任何真實網頁佐證——這種情況才
        # 最需要被標記成創新/低信心，不能因為自報信心高就放過。
        return 1, "無真實網頁佐證，純AI推斷（即使AI自稱信心高，也沒有真實市場數據支撐），市場可能無直接對應品項"
    if is_verified and avg_match_relevance and avg_match_relevance < 0.4:
        return 1, f"雖查到商品但標題相關度偏低（{avg_match_relevance}），可能是替代品而非同類商品"
    if low_sample_warning:
        return 1, "真實比價樣本數不足或價格與核心售價差距懸殊，市場可能無足夠對應品項"
    return 0, ""


# ══════════════════════════════════════════════════════════════════════
# 方案定價解析器（純 Regex）
# ══════════════════════════════════════════════════════════════════════

class PlansParser:
    _MULTI_KEYWORDS  = re.compile(r'雙入|三入|四入|五入|六入|多入|團購|加購|組合|兩入|2入|3入|4入|5入')
    _PLAN_SEP        = re.compile(r'▼\s*【方案\s*\d+】\s*▼')
    _PRICE_LINE      = re.compile(r'NT\$?\s*([0-9,]+)')
    _EARLY_BIRD      = re.compile(r'早鳥|限時|預購特惠|超早鳥')
    _ADDON           = re.compile(r'加購|加碼|贈品|配件')
    # 組合包：標題中出現「＋」或「+」代表把多個不同品項綁在一起賣
    # （例如「實體書＋書籤＋電子版」），售價自然比單一品項高，
    # 不應該被當成核心／正常定價的比較對象。
    _BUNDLE          = re.compile(r'＋|\+')
    # 明確標示「單入」的方案（單本/單入/單件/1入/一份…），這是判斷核心售價的
    # 最優先依據——比起「排除早鳥/多入/組合後剩下的」這種間接推論更可靠，
    # 因為它是直接比對文字上明確寫的「這是單一件商品」。
    _SINGLE          = re.compile(r'單入|單本|單件|單一件|單份|1入|一入|一份', re.IGNORECASE)
    # 從標題推算數量（雙入=2，三入=3…）
    _QTY_MAP         = {'雙入': 2, '兩入': 2, '2入': 2, '三入': 3, '3入': 3,
                        '四入': 4, '4入': 4, '五入': 5, '5入': 5, '六入': 6, '6入': 6}

    def _detect_qty(self, title: str) -> int:
        for kw, qty in self._QTY_MAP.items():
            if kw in title:
                return qty
        return 1

    def parse(self, plans_text: str) -> Dict[str, Any]:
        if not plans_text.strip():
            return {"plans_count": 0, "plans_core_price": 0, "plans_min_price": 0,
                    "plans_max_price": 0, "plans_has_early_bird": 0, "parsed_plans": []}

        blocks = [b.strip() for b in self._PLAN_SEP.split(plans_text) if b.strip()]
        parsed = []
        for block in blocks:
            lines    = [l.strip() for l in block.splitlines() if l.strip()]
            title    = lines[0] if lines else ""
            is_multi  = bool(self._MULTI_KEYWORDS.search(title))
            is_early  = bool(self._EARLY_BIRD.search(title))
            is_addon  = bool(self._ADDON.search(title))
            is_bundle = bool(self._BUNDLE.search(title))
            is_single = bool(self._SINGLE.search(title))
            qty      = self._detect_qty(title)
            prices   = self._PRICE_LINE.findall(block)
            sale_p   = int(prices[0].replace(',', '')) if len(prices) >= 1 else 0
            orig_p   = int(prices[1].replace(',', '')) if len(prices) >= 2 else sale_p
            unit_p   = round(sale_p / qty) if qty > 1 and sale_p > 0 else sale_p
            if sale_p > 0:
                parsed.append({
                    "title":          title,
                    "is_multi":       is_multi,
                    "is_early_bird":  is_early,
                    "is_addon":       is_addon,
                    "is_bundle":      is_bundle,
                    "is_single":      is_single,
                    "qty":            qty,
                    "sale_price":     sale_p,
                    "unit_price":     unit_p,
                    "original_price": orig_p,
                })

        if not parsed:
            return {"plans_count": 0, "plans_core_price": 0, "plans_min_price": 0,
                    "plans_max_price": 0, "plans_has_early_bird": 0, "parsed_plans": []}

        # ── 核心售價選取邏輯 ────────────────────────────────────────
        # 優先順序（tier 0~3 篩出候選集合後，皆用「同標題分組→取組內最高價
        # →跨組取中位數」的方式選出核心價，而不是直接取全體最高價，
        # 避免選到離群的高價方案，改為選出「最合理可比價」的那個）：
        # 0. 標題明確標示「單入/單本/單件」的方案（排除早鳥/加購/組合包）
        #    → 這是最可靠的判斷依據，因為是直接比對文字上明確寫的
        #      「這是單一件商品」，而非用排除法間接推論。
        # 1. 若沒有明確標示單入的方案 → 退回排除法：非早鳥、非多入、非加購、
        #    非組合包 的方案
        # 2. 若全部都是多入 → 拆算單價後的方案（排除早鳥/加購/組合包）
        # 3. 若全部都是早鳥 → 早鳥單入方案（排除加購/組合包）
        # 4. 兜底：所有方案 unit_price 中位數（此時才會納入組合包，避免完全沒有結果）

        def _group_median(plans: List[dict]) -> Optional[int]:
            """
            同標題方案視為「同一商品的不同時期定價」，組內取最高價
            （早鳥視為異常低價，排除其影響）；不同標題（不同商品/規格）
            之間再取中位數，代表最合理、最適合拿去跟市場比價的那個值，
            而不是直接取全體最高價（可能選到離群的高價變體）。
            """
            groups: Dict[str, List[int]] = {}
            for p in plans:
                groups.setdefault(p["title"], []).append(p["unit_price"])
            if not groups:
                return None
            group_max = sorted(max(v) for v in groups.values())
            n = len(group_max)
            # 中位數：奇數取正中間；偶數取中間偏低者（避免偏向高估）
            return group_max[(n - 1) // 2]

        def _pick_core(plans: List[dict]) -> int:
            # tier-0：明確標示「單入」的方案（排除早鳥/加購/組合包）
            tier0 = [p for p in plans if p["is_single"] and not p["is_early_bird"]
                     and not p["is_addon"] and not p["is_bundle"]]
            v = _group_median(tier0)
            if v is not None:
                return v
            # tier-1: 標準單入（排除早鳥/多入/加購/組合包，用排除法推論）
            tier1 = [p for p in plans if not p["is_multi"] and not p["is_early_bird"]
                     and not p["is_addon"] and not p["is_bundle"]]
            v = _group_median(tier1)
            if v is not None:
                return v
            # tier-2: 標準多入（拆算單價，排除加購/組合包）
            tier2 = [p for p in plans if not p["is_early_bird"] and not p["is_addon"]
                     and not p["is_bundle"]]
            v = _group_median(tier2)
            if v is not None:
                return v
            # tier-3: 早鳥單入（排除加購/組合包）
            tier3 = [p for p in plans if not p["is_multi"] and not p["is_addon"]
                     and not p["is_bundle"]]
            v = _group_median(tier3)
            if v is not None:
                return v
            # tier-4: 兜底，此時才納入組合包，取全體中位數
            all_units = sorted(p["unit_price"] for p in plans)
            return all_units[len(all_units) // 2]

        core_price = _pick_core(parsed)
        all_p      = [p["sale_price"] for p in parsed]
        single_p   = [p["sale_price"] for p in parsed if not p["is_multi"]]

        return {
            "plans_count":         len(parsed),
            "plans_core_price":    core_price,           # ← 主要比較用，最合理可比價
            "plans_min_price":     min(single_p) if single_p else min(all_p),
            "plans_max_price":     max(all_p),
            "plans_has_early_bird": int(any(p["is_early_bird"] for p in parsed)),
            "parsed_plans":        parsed,
        }


# ══════════════════════════════════════════════════════════════════════
# 市場價格 Agent
# ══════════════════════════════════════════════════════════════════════

class MarketPriceAgent:
    """
    負責「市場行情」查詢，每個商品正常情況下最多 2 次 Gemini 呼叫：
      - Call 1：_analyze_keyword_and_price → 判斷含規格特徵的關鍵字＋核心售價
      - Call 2：_fetch_market_range        → 單次 Grounding 搜尋，內建
                精準搜尋→放寬品類→AI知識推斷 三層策略，由 Gemini 在
                同一次生成內自行遞進嘗試，不需分開呼叫三次 API

    規格比對原則：類似即可，不要求完全相同（材質/容量/尺寸/版本可以有差異），
    只排除完全不同類別的商品。

    保證一定有市場價：Grounding 找不到 → 補打一次 AI 知識推斷 → 若兩次都
    完全無回應（例如網路/API 異常），才會用核心售價 ±30% 做本地保底估算，
    絕不會回傳「無法取得」。
    """

    _ANALYZE_SYSTEM = """你是專業電商商品分析師，專門分析台灣群眾募資文案。
任務：從募資文案（與可能提供的方案售價資訊）中，直接判斷出：
1. keyword：一個消費者在蝦皮/PChome/momo搜尋時會用、且帶有「規格特徵」的關鍵字組合
   （例如材質、尺寸、容量、片數、版本等），目的是讓之後查詢到的市場價格，
   對應的是「同規格同類型」的商品，而不是泛用同類詞。
   - 不含品牌名、創作者名、行銷詞
   - 8~16字中文詞組（詞＋規格特徵），例如「304不鏽鋼 480ml 保溫瓶」而非只寫「保溫瓶」
   - ⚠️ 重要：即使文案內容模糊、無法判斷精確規格，也【絕對不要】回傳「未分類商品」
     或空白。這種情況下，退而求其次給出這個商品所屬的「廣泛品類＋用途」
     （例如「穿戴式AI裝置」「行車記錄器」「戶外保溫水壺」「桌遊卡牌遊戲」），
     這樣至少能查到類似/替代品的市場行情，比完全放棄好非常多。
     只有在文案完全空白、或連商品是什麼類型都無法辨識時，才回傳「未分類商品」。
   - ⚠️【重要】若商品同時整合多種原本分屬不同類別的功能（例如「穿戴裝置＋相機＋
     行動電源」三合一），不要把這些不同類別的功能詞全部硬串成一個關鍵字
     （這樣在電商平台上根本搜不到對應物，反而容易誤配到完全不相關的單一配件）。
     請只聚焦在「最能代表整體商品定位、消費者最先會想到的那個主要功能／品類」
     來下關鍵字，其餘功能可以忽略。
2. core_price：若文案中提供標準單入方案售價則直接採用；若沒有，從文案自行判斷合理的
   單入/標準版新台幣整數售價，找不到則填0
3. is_multi_function：若這個商品整合了2種以上原本分屬不同類別的主要功能
   （例如穿戴裝置+相機+行動電源、水壺+藍牙喇叭），回傳 true；單一功能商品回傳 false。
   這個欄位用來提醒後續比價流程：多功能整合商品市場上通常沒有直接對應物，
   比價結果可信度要打折扣看待。

規則：關鍵字與售價都必須直接對應文案中的商品，不可憑空創造。
回傳純 JSON（不含 markdown fence 或任何說明文字）：
{"keyword": "（含規格特徵的關鍵字，或至少是廣泛品類）", "core_price": 數字, "is_multi_function": true/false}"""

    _PRICE_SEARCH_SYSTEM = """你是台灣電商價格分析師，任務是找出「指定規格商品」在台灣市場的真實售價區間，
且必須盡可能跨多個電商平台比對，確保這是市場的普遍行情，而非單一商家的個別報價。

🏬【請盡量涵蓋以下台灣主要電商/通路，不要只查一家就結束】
蝦皮購物、PChome 24h購物、momo購物網、Yahoo奇摩購物中心、樂天市場、
森森購物、生活市集、friDay購物、博客來（書籍類）、東森購物、名店街等。

🚨【搜尋策略 — 請在同一次回覆內依序自行嘗試，不需使用者再次提問】🚨
Google Search Grounding 不支援 site: 指令，請直接用自然語言搜尋：
1. 第一步：用完整關鍵字（含規格特徵）分別嘗試「蝦皮 價格」「momo 價格」
   「PChome 價格」等不同平台的自然語言搜尋，盡量找到至少 2 個不同平台的售價，
   目標是找到「類型類似、用途相同」的商品售價（例如同類型的保溫瓶、同類型的
   筆記本），不需要規格完全一模一樣（材質/容量/尺寸/版本可以有些微差異），
   只要是消費者會拿來比較的同類商品即可，這樣才找得到足夠的市場數據。
2. 若第一步找到的同平台/同類商品不夠多，放寬成上層品類關鍵字＋「購買」再搜尋，
   一樣盡量嘗試多個平台，目標是湊到至少 3 筆有效售價。
3. 若做完以上兩步仍然完全找不到任何售價，才憑你對台灣電商市場的知識，
   針對這個商品類型給出合理估算區間，並在 sources_note 標明「AI知識推斷」。

⚠️【最重要的規則：無論如何都必須給出價格區間，絕對不可以回傳「找不到」、
0、或空值。就算完全沒有搜尋結果，也一定要根據商品類型給出合理估算。】

排除：嘖嘖/flyingV 等募資平台售價、二手商品、海外代購、蝦皮個人賣家的非量產二手品、
以及完全不同類別的商品（例如關鍵字是保溫瓶卻查到保溫袋，或是書籍卻查到文具），
但同類型商品的規格差異（容量、尺寸、材質、版本）不需要完全相同，類似即可。
必須給出具體數字，不可回傳0。

data_quality 判斷標準：
- "high"：有 2 個以上不同平台、且商品類型相符的售價可交叉比對
- "medium"：只找到 1 個平台的相符售價，或跨平台但筆數很少
- "low"：僅為放寬品類後的估算，或是 AI 知識推斷

回傳純 JSON（不含 markdown fence 或多餘說明文字）：
{
  "searched_keyword": "實際用來得出結果的關鍵字",
  "search_tier": "exact"/"broadened"/"ai_estimate",
  "platforms": ["實際查到售價的平台名稱列表，例如 蝦皮購物, momo購物網"],
  "prices_found": [所有有效售價整數，單位新台幣，此欄位不可為空陣列],
  "price_min": Q25或最低合理價,
  "price_max": Q75或最高合理價,
  "data_quality": "high"/"medium"/"low",
  "sources_note": "資料來源、平台數量與搜尋策略說明"
}"""

    _AI_ESTIMATE_SYSTEM = """你是台灣電商市場價格專家，熟悉蝦皮、PChome、momo、博客來等平台的商品行情。
根據商品關鍵字（含規格特徵），憑你的訓練知識給出台灣市場的合理售價區間。

規則：
- 絕對必須給出具體數字，不可回傳 0、不可留空、不可說找不到
- 以台灣消費市場正常零售價為準（非特賣、非批發）
- 針對關鍵字所屬的商品類型估算即可，不需要規格完全對應，類似類型的市售
  商品價格即可作為估算基礎
- 偏離幅度允許 ±40%，寧可範圍寬一點也要給數字；就算商品很小眾冷門，
  也要用最相近的同類商品類型推估一個合理區間

回傳純 JSON（禁止 markdown fence 或任何說明文字）：
{"price_min": 整數, "price_max": 整數, "note": "估算依據一句話說明", "confidence": "high"/"medium"/"low"}"""

    def __init__(self, client: genai.Client, content_text: str):
        self.client = client
        self._cache: Dict[str, Any] = self._load_cache()

    # ── Call 1：一次判斷「含規格特徵的關鍵字」＋核心售價 ──────────────
    def _analyze_keyword_and_price(self, content_text: str,
                                   known_core_price: int = 0) -> Tuple[str, int, bool]:
        """回傳 (keyword, price, is_multi_function)。
        is_multi_function：商品是否整合多種原本分屬不同類別的主要功能
        （例如穿戴裝置+相機+行動電源）——這類商品市場上通常沒有直接對應物，
        用來餵給下游的創新商品判斷（_judge_novelty）當作額外訊號。"""
        # ── 內容雜湊快取：同一份文案（＋同樣的已知核心售價）重複執行時，
        #    不再重打 Gemini，適合 Colab 反覆測試/除錯的情境 ──────────
        cache_key = "kw:" + hashlib.md5(
            (content_text[:LLM_MAX_CHARS] + f"|{known_core_price}").encode("utf-8")
        ).hexdigest()
        if cache_key in self._cache:
            c = self._cache[cache_key]
            print(f"  [快取] 關鍵字判斷沿用先前結果：{c['keyword']}（NT${c['price']:,}）")
            return c["keyword"], c["price"], c.get("is_multi_function", False)

        price_hint = (f"\n【已知標準單入方案售價】：NT${known_core_price:,}"
                      f"（keyword 需能代表這個價位對應的規格商品）"
                      if known_core_price > 0 else "")
        prompt = (
            f"【募資文案】：\n{content_text[:LLM_MAX_CHARS]}{price_hint}"
        )
        raw = _call_gemini(self.client, prompt,
                           system=self._ANALYZE_SYSTEM,
                           max_tokens=400, json_mode=True,
                           disable_thinking=True)
        keyword, price, is_multi_function = "未分類商品", known_core_price, False
        if raw:
            r = _parse_json(raw)
            if r:
                keyword = str(r.get("keyword") or keyword).strip() or keyword
                is_multi_function = bool(r.get("is_multi_function", False))
                if known_core_price <= 0:
                    try:
                        price = int(float(str(r.get("core_price", 0)).replace(',', '')))
                    except (ValueError, TypeError):
                        price = 0
        if keyword == "未分類商品":
            m = re.search(r'(?:單入|標準版|早鳥).*?NT\$?\s*([0-9,]+)', content_text)
            if m and known_core_price <= 0:
                price = int(m.group(1).replace(',', ''))

        if keyword != "未分類商品":
            self._cache[cache_key] = {"keyword": keyword, "price": price,
                                       "is_multi_function": is_multi_function}
            self._save_cache()
        else:
            print("  ⚠️  關鍵字判斷失敗（未分類商品），本次結果不寫入快取，下次會重新嘗試。")
        return keyword, price, is_multi_function

    # ⚠️ 最後搶救層，只有在「第一次判斷回傳未分類商品」且「本地品類字典
    # 也完全比對不到」的雙重失敗情況下才會被呼叫，所以額外的API用量很有限。
    # prompt刻意寫得比第一次寬鬆很多：不要求規格特徵、不要求精確品類，
    # 只求「舉出一個類似的現成商品名稱」，即使文案寫得再模糊行銷化，
    # 也盡量榨出一個能拿去電商平台搜尋的詞，而不是直接放棄。
    _RELAXED_RETRY_SYSTEM = """你是電商商品分析師。前一次嘗試從這份募資文案判斷「精確規格關鍵字」
已經失敗（文案可能用詞抽象、行銷化，或缺乏具體規格描述）。

這次請放寬標準，只要做到：從文案的敘述、用途、使用情境、外型描述、目標受眾等任何
蛛絲馬跡，聯想出「市面上最接近的一種現成商品類型」，即使不夠精確也沒關係。
例如：文案講「隨身攜帶、按一下就能記錄靈感」→即使沒寫規格，也可以聯想成「錄音筆」；
文案講「戴著它去運動，流汗也不怕」→可以聯想成「運動手環」。

只有在文案內容完全空白、或連要幹嘛都看不出來時，才回傳空字串。

回傳純 JSON（不含 markdown fence 或任何說明文字）：
{"guessed_product_type": "（4~10字的商品類型詞，或空字串）"}"""

    def _relaxed_keyword_retry(self, content_text: str) -> str:
        """本地字典也比對不到時的最後搶救：換一個寬鬆很多的prompt再問一次AI。
        回傳空字串代表真的連AI放寬標準都判斷不出來（極少數情況）。"""
        raw = _call_gemini(self.client, f"【募資文案】：\n{content_text[:LLM_MAX_CHARS]}",
                           system=self._RELAXED_RETRY_SYSTEM,
                           max_tokens=200, json_mode=True,
                           disable_thinking=True)
        if not raw:
            return ""
        r = _parse_json(raw)
        if not r:
            return ""
        guess = str(r.get("guessed_product_type") or "").strip()
        return guess

    def _get_keyword(self, text: str, candidates: List[str]) -> str:
        # 保留舊接口相容性（目前流程已不需要，由 _analyze_keyword_and_price 取代）
        return candidates[0] if candidates else "未分類商品"

    def _get_keyword_and_price(self, text: str,
                               candidates: List[str]) -> Tuple[str, int, bool]:
        return self._analyze_keyword_and_price(text)

    def _filter_candidates(self, content_text: str, top_k: int = 3) -> List[str]:
        # 已移除 Embedding 篩選步驟以減少 API 呼叫次數，保留空清單相容舊呼叫點
        return []

    # ── 從原始文字中解析價格數字（純本地運算，不耗用 API 額度）───────
    @staticmethod
    def _parse_prices_from_raw(raw: str) -> Tuple[int, int, str, List[int]]:
        prices: List[int] = []
        json_match = re.search(r'\{[\s\S]*?\}', raw)
        if json_match:
            r = _parse_json(json_match.group(0)) or {}
            val = r.get("prices_found", [])
            if isinstance(val, list):
                for v in val:
                    try:
                        n = int(str(v).replace(',', ''))
                        if 50 < n < 500_000:
                            prices.append(n)
                    except Exception:
                        pass
            for field in ("price_min", "price_max"):
                try:
                    n = int(str(r.get(field, 0) or 0).replace(',', ''))
                    if 50 < n < 500_000:
                        prices.append(n)
                except Exception:
                    pass

        for m in re.finditer(
            r'(?:NT\$?|TWD|新台幣|售價[：: ]?|定價[：: ]?|原價[：: ]?|特價[：: ]?|約[：: ]?)'
            r'\s*([0-9][0-9,]{1,6})',
            raw
        ):
            try:
                n = int(m.group(1).replace(',', ''))
                if 50 < n < 500_000:
                    prices.append(n)
            except Exception:
                pass

        if len(prices) < 2:
            candidates = []
            for m in re.finditer(r'\b([1-9][0-9]{2,5})\b', raw):
                n = int(m.group(1))
                if 50 < n < 500_000:
                    candidates.append(n)
            if candidates:
                buckets: Dict[int, List[int]] = {}
                for n in candidates:
                    mag = 10 ** (len(str(n)) - 1)
                    buckets.setdefault(mag, []).append(n)
                best_mag = max(buckets, key=lambda k: len(buckets[k]))
                prices.extend(buckets[best_mag])

        prices = sorted(set(prices))
        if len(prices) >= 2:
            p_min = int(np.percentile(prices, 25))
            p_max = int(np.percentile(prices, 75))
            if p_min == p_max:
                p_min = int(p_min * 0.8)
                p_max = int(p_max * 1.2)
            quality = "high" if len(prices) >= 3 else "medium"
            return p_min, p_max, quality, prices
        elif len(prices) == 1:
            v = prices[0]
            return int(v * 0.8), int(v * 1.2), "medium", prices
        return 0, 0, "low", []

    # ── Call 2：單次 Grounding 呼叫，三層 fallback 策略寫入同一個 prompt ──
    # ── Call 2：改用 Python 免費聯網 (RAG) 呼叫，繞過 Grounding limit: 0 ──
    def _fetch_market_range(self, keyword: str,
                            fallback_keywords: Optional[List[str]] = None,
                            core_price_hint: int = 0
                            ) -> Tuple[int, int, str, str, List[str], bool, bool, List[str], float, bool]:
        """
        回傳 (market_min, market_max, range_str, data_quality, platforms,
              has_real_search, is_verified, matched_titles, avg_match_relevance,
              low_sample_warning)

        matched_titles      ：Tier 0 真實比價實際抓到的商品標題（最多3筆），供人工回頭核對
        avg_match_relevance ：Tier 0 比對到商品的平均標題相關度（0~1），僅在有真實比價結果時有值
        low_sample_warning  ：True 代表本次結果雖標記較高信心，但樣本數過少
                               （<2筆）或出現價格與核心售價懸殊（price_sanity=extreme），
                               建議人工複核，不宜直接當作高信心行情使用
        """

        cache_key = f"v11_verified:{keyword}:{core_price_hint}"
        if cache_key in self._cache:
            c = self._cache[cache_key]
            plats = c.get("platforms", [])
            plat_str = f"（來源：{'、'.join(plats)}）" if plats else ""
            print(f"  [快取] {c.get('searched_keyword', keyword)} → {c['range_str']} [{c['quality']}]{plat_str}")
            return (c["min"], c["max"], c["range_str"], c["quality"], plats,
                    c.get("has_real_search", False), c.get("is_verified", False),
                    c.get("matched_titles", []), c.get("avg_relevance", 0.0),
                    c.get("low_sample_warning", False))

        market_min = market_max = 0
        data_quality = "low"
        searched_kw = keyword
        source_label = ""
        platforms: List[str] = []
        has_real_search = False
        is_verified = False
        matched_titles: List[str] = []
        avg_relevance = 0.0
        low_sample_warning = False

        # ── 修正1：關鍵字判斷本身就失敗時（"未分類商品"），搜尋這四個字
        #    完全沒有意義，只會查到不相關的垃圾結果甚至讓模型亂編一個離譜的
        #    價格區間。這種情況直接跳過網路搜尋／AI推斷，改用下面的
        #    「保底估算」機制（以核心售價為準），比讓模型瞎猜可靠得多。
        if keyword == "未分類商品":
            print("  ⚠️  關鍵字判斷失敗（未分類商品），搜尋這個詞沒有意義，"
                  "略過網路檢索，直接用核心售價做保底估算。")
        else:
            # ▼▼▼ Tier 0：真實比價——直接抓商品頁的結構化資料，不透過AI詮釋 ▼▼▼
            verified_items = _verify_real_prices(keyword, core_price_hint=core_price_hint)
            if verified_items:
                prices = [it["price"] for it in verified_items]
                platforms = sorted({_normalize_platform(it["platform"]) for it in verified_items})
                rel_scores = [it.get("relevance", 0.0) for it in verified_items]
                avg_rel_tier0 = round(sum(rel_scores) / len(rel_scores), 2) if rel_scores else 0.0
                has_extreme = any(it.get("price_sanity") == "extreme" for it in verified_items)
                titles_tier0 = [it.get("title", "") for it in verified_items[:3] if it.get("title")]

                # ⚠️ v17 修正（重大）：v10版曾經把「樣本數<2或有極端值」的結果
                # 降級為medium並繼續採用它的price當作market_min/max——但這樣
                # 「降級標籤」形同虛設，因為_fetch_market_range後面是用
                # market_max==0來判斷要不要退回Tier1，一旦Tier0塞了任何非0
                # 數字進去，不管信心多低都不會再退回Tier1了。TS1實測就是這樣
                # 出包：核心價NT$4,990，Tier0抓到1筆完全不對應的行動電源配件
                # NT$450（比值0.09，遠低於0.2的extreme門檻），卻因為market_max
                # 已經非0，永遠卡在這個離譜數字上，沒有機會讓Tier1去找到更
                # 合理的Wristcam類產品。
                # 修法：has_extreme(價格離譜到疑似抓錯商品)時，直接整批丟棄、
                # 不採用，讓market_max維持0以便自然退回Tier1；只有「單純樣本
                # 數少但價格看起來正常」才保留為medium。
                if has_extreme:
                    print(f"  ⚠️  真實比價抓到資料但價格與核心售價比值離譜"
                          f"（疑似抓到不對應商品，NT${min(prices):,}~NT${max(prices):,} "
                          f"vs 核心NT${core_price_hint:,}），判定不可信、直接丟棄，"
                          f"退回「網頁片段 + Gemini 解讀」這一層：{titles_tier0}")
                else:
                    market_min, market_max = min(prices), max(prices)
                    avg_relevance = avg_rel_tier0
                    matched_titles = titles_tier0
                    if len(verified_items) < 2:
                        data_quality = "medium"
                        low_sample_warning = True
                        print(f"  ⚠️  真實比價僅取得單一樣本（樣本數<2，建議人工複核），"
                              f"標記low_sample_warning：{matched_titles} NT${market_min:,}")
                    else:
                        data_quality = "verified" if len(platforms) >= 2 else "high"
                    is_verified = (data_quality in ("verified", "high"))
                    has_real_search = True
                    source_label = "真實比價（直接驗證商品頁面）"
                    print(f"  ✅ 真實比價取得資料：{prices}（{'、'.join(platforms)}，"
                          f"平均相關度{avg_relevance}，{data_quality}）")

            # ▼▼▼ Tier 1：真實比價失敗/被丟棄時，退回「網頁片段 + Gemini 解讀」（原有流程）▼▼▼
            if market_max == 0:
                web_snippets, has_real_search = _free_web_search(keyword)
                if has_real_search:
                    print(f"  ✅ 真實網路檢索成功，取得 {web_snippets.count(chr(10)) + 1} 筆網頁片段，"
                          f"將作為 Gemini 分析的實際依據")
                else:
                    print("  ⚠️  真實網路檢索沒有取得結果，這次行情將完全基於 Gemini 自身知識推斷"
                          "（不是查到的真實網頁資料，可信度較低，data_quality 會標示為 low）")

                grounding_prompt = (
                    f"商品關鍵字（含規格特徵）：{keyword}\n\n"
                    f"以下為剛剛在台灣電商平台（蝦皮、momo、PChome等）真實檢索到的商品標題與內容片段：\n"
                    f"────────────────────────────────────────\n"
                    f"{web_snippets}\n"
                    f"────────────────────────────────────────\n\n"
                    f"請依據上述【真實網路檢索結果】以及你的電商知識，找出類型類似（不需規格完全相同，"
                    f"容量/材質/版本可以有差異，只要是同類商品即可）的真實售價，"
                    f"列出至少3筆售價、標明各筆售價來自哪個平台，並計算最低/最高合理售價。\n"
                    f"無論如何都必須給出價格，不可回傳找不到。"
                )

                # ▼ 修正2：這裡已經是 use_search=False（一般對話呼叫），不再受
                #    Grounding 的 response_mime_type 限制，重新打開 json_mode
                #    強制模型輸出純 JSON，避免像先前那樣有時候回傳 Markdown
                #    條列格式導致解析失敗、白白多打一次備援呼叫。
                raw_g = _call_gemini(
                    self.client, grounding_prompt,
                    system=self._PRICE_SEARCH_SYSTEM,
                    max_tokens=1536, json_mode=True,
                    use_search=False,
                    disable_thinking=False
                )

                search_tier = "unknown"
                if raw_g:
                    print(f"  📥 RAG檢索比對回傳（前300字）：{raw_g[:300]!r}")
                    json_match = re.search(r'\{[\s\S]*\}', raw_g)
                    r = _parse_json(json_match.group(0)) if json_match else _parse_json(raw_g)
                    if r:
                        searched_kw = str(r.get("searched_keyword", keyword))
                        search_tier = str(r.get("search_tier", "unknown"))
                        plats = r.get("platforms", [])
                        if isinstance(plats, list):
                            # ▼ 修正3：正規化平台名稱後再去重，避免「PChome」跟
                            #    「PChome 24h購物」被算成兩個不同平台，虛灌
                            #    data_quality 的可信度判斷
                            platforms = sorted({_normalize_platform(str(x)) for x in plats if str(x).strip()})
                    market_min, market_max, data_quality, prices_found = self._parse_prices_from_raw(raw_g)
                    if len(platforms) >= 2 and market_max > 0:
                        data_quality = "high"
                    if market_max > 0:
                        tier_label = {"exact": "精準搜尋", "broadened": "放寬品類搜尋",
                                      "ai_estimate": "AI知識推斷"}.get(search_tier, "RAG真實網路檢索")
                        source_label = tier_label
                        plat_str = f"，來源平台：{'、'.join(platforms)}" if platforms else "，⚠️ 未標示來源平台"
                        real_tag = "（有真實網頁佐證）" if has_real_search else "（無真實網頁佐證，屬AI推斷）"
                        print(f"  ✅ 取得行情：NT${market_min:,}~NT${market_max:,}"
                              f"（{len(prices_found)}筆，策略：{tier_label}{plat_str}{real_tag}）")

                # ── 若 RAG 檢索沒給出價格，補打一次純知識推斷 ──
                if market_max == 0:
                    print("  🤖 [備援呼叫] RAG 檢索沒有取得有效價格，改用 Gemini 純知識推斷...")
                    ai_prompt = (
                        f"商品關鍵字（含規格特徵）：{keyword}\n\n"
                        f"請根據你對台灣電商市場（蝦皮/PChome/momo）的知識，"
                        f"針對這個商品類型（類似規格即可，不需要完全對應）估算合理售價區間"
                        f"（新台幣）。\n絕對必須給出具體數字，不可為 0、不可說不確定。"
                    )
                    raw_ai = _call_gemini(
                        self.client, ai_prompt,
                        system=self._AI_ESTIMATE_SYSTEM,
                        max_tokens=400, json_mode=True, use_search=False,
                        disable_thinking=True
                    )
                    if raw_ai:
                        print(f"  📥 AI推斷回傳：{raw_ai[:200]!r}")
                        r_ai = _parse_json(raw_ai) or {}
                        try:
                            p_min = int(str(r_ai.get("price_min", 0) or 0).replace(',', ''))
                            p_max = int(str(r_ai.get("price_max", 0) or 0).replace(',', ''))
                        except Exception:
                            p_min = p_max = 0
                        if p_max == 0:
                            p_min, p_max, _, _ = self._parse_prices_from_raw(raw_ai)
                        if p_max > 0 and p_min >= 0:
                            if p_min == 0:
                                p_min = int(p_max * 0.6)
                            market_min, market_max = p_min, p_max
                            # ⚠️ v11 修正：純AI知識推斷（無真實網頁佐證）不應該直接
                            # 採用模型「自報」的信心值當作 data_quality。舊版曾出現
                            # AI自稱confidence=high，但data_quality就顯示成「高（≥2個
                            # 平台交叉比對）」，跟真正有交叉比對的結果混為一談，誤導
                            # 判讀。這裡把自報信心值封頂在 medium，且把原始自報值
                            # 保留在 sources_note 裡供參考，而不是直接拿來當權威分級。
                            self_reported_confidence = str(r_ai.get("confidence", "low"))
                            data_quality = "medium" if self_reported_confidence == "high" else "low"
                            source_label = f"AI知識推斷（{r_ai.get('note', '估算')}）"
                            platforms = []
                            has_real_search = False
                            print(f"  🤖 AI推斷行情：NT${market_min:,}~NT${market_max:,}（{data_quality}）")

        # ── 保底估算機制：關鍵字失敗、或兩次 Gemini 呼叫都沒能給出價格時 ──
        if market_max == 0:
            if core_price_hint > 0:
                market_min = int(core_price_hint * 0.7)
                market_max = int(core_price_hint * 1.3)
                data_quality = "low"
                source_label = "本地保底估算（無有效網路/AI結果，以核心售價±30%推算）"
                print(f"  🛟 [保底估算] 改用核心售價推算：NT${market_min:,}~NT${market_max:,}")
            else:
                market_min, market_max = 300, 3000
                data_quality = "low"
                source_label = "本地保底估算（無任何可用資訊，為通用區間，僅供參考）"
                print("  🛟 [保底估算] 無核心售價可參考，使用通用保守區間。")
            has_real_search = False

        range_str = f"NT${market_min:,} ~ NT${market_max:,}"
        tag = f"【{source_label}】" if source_label else ""
        print(f"  📈 市場行情 {range_str} {tag}")
        self._cache[cache_key] = {
            "min": market_min, "max": market_max,
            "range_str": range_str, "quality": data_quality,
            "searched_keyword": searched_kw,
            "platforms": platforms,
            "has_real_search": has_real_search,
            "is_verified": is_verified,
            "matched_titles": matched_titles,
            "avg_relevance": avg_relevance,
            "low_sample_warning": low_sample_warning,
        }
        self._save_cache()

        return (market_min, market_max, range_str, data_quality, platforms,
                has_real_search, is_verified, matched_titles, avg_relevance, low_sample_warning)

    def analyze(self, content_text: str,
                plans_info: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        known_core_price = 0
        price_source = "llm"
        if plans_info and plans_info.get("plans_core_price", 0) > 0:
            known_core_price = plans_info["plans_core_price"]
            price_source = "plans"

        # Call 1：一次判斷「含規格特徵的關鍵字」＋（必要時）核心售價＋是否多功能整合商品
        keyword, core_price, is_multi_function = self._analyze_keyword_and_price(
            content_text, known_core_price)
        if known_core_price > 0:
            core_price = known_core_price
        else:
            price_source = "llm" if core_price > 0 else "regex"

        # ── 關鍵字判斷真的失敗時：三層搶救，能救回多少算多少 ──────────
        # 第1層（免費，本地字典比對）：先試著用本地免費的品類猜測找出
        #   「這大概是哪一類商品」，拿類似/替代品的市場行情當參考，而不是
        #   直接放棄改用純粹的核心售價±30%（那樣完全跟商品本質脫節）。
        # 第2層（多一次API呼叫，只在第1層也失敗時才觸發）：換一個更寬鬆、
        #   門檻更低的prompt再問一次Gemini——原本的判斷prompt要求「規格特徵
        #   關鍵字」，門檻較高；這裡改成只要求「這東西大概是什麼、能不能
        #   舉出1個類似的現成商品」，即使文案寫得很模糊、用詞很行銷化，
        #   也盡量榨出一個可用的搜尋詞，而不是兩層都放棄。
        used_category_fallback = False
        used_relaxed_retry = False
        if keyword == "未分類商品":
            guessed_category = _guess_category_keyword(content_text)
            if guessed_category:
                print(f"  🔍 關鍵字判斷失敗，本地比對到可能品類：「{guessed_category}」，"
                      f"改用此類似品類搜尋市場行情（免費，不呼叫額外API）。")
                keyword = guessed_category
                used_category_fallback = True
            else:
                print("  🔍 本地品類字典也比對不到，改用寬鬆版prompt再問一次AI（最後搶救）...")
                relaxed_keyword = self._relaxed_keyword_retry(content_text)
                if relaxed_keyword:
                    print(f"  🔍 寬鬆版判斷救回關鍵字：「{relaxed_keyword}」")
                    keyword = relaxed_keyword
                    used_category_fallback = True
                    used_relaxed_retry = True
                else:
                    print("  ⚠️  連寬鬆版AI判斷都失敗，這筆真的完全無法分類，"
                          "將使用核心售價±30%純數字保底估算（不具商品本質參考價值）。")

        # Call 2：真實比價（結構化資料驗證）→ 網頁片段+Gemini解讀 → AI知識推斷 → 本地保底
        (market_min, market_max, range_str, quality, platforms, has_real_search,
         is_verified, matched_titles, avg_relevance, low_sample_warning) = self._fetch_market_range(
            keyword, core_price_hint=core_price
        )

        is_competitive = 0
        deviation = None
        if market_max > 0:
            is_competitive = 1 if market_min <= core_price <= market_max else 0
            median = (market_min + market_max) / 2
            deviation = round((core_price - median) / median, 4) if median else 0.0

        is_totally_unclassified = (keyword == "未分類商品")
        is_innovative, novelty_reason = _judge_novelty(
            keyword_is_category_fallback=used_category_fallback,
            is_verified=is_verified,
            market_has_real_search=has_real_search,
            avg_match_relevance=avg_relevance,
            low_sample_warning=low_sample_warning,
            data_quality=quality,
            is_multi_function=is_multi_function,
            is_totally_unclassified=is_totally_unclassified,
        )
        if is_innovative:
            print(f"  💡 [創新商品判定] {novelty_reason}")

        if is_totally_unclassified:
            keyword_fallback_method = "total_failure"
        elif used_relaxed_retry:
            keyword_fallback_method = "relaxed_ai_retry"
        elif used_category_fallback:
            keyword_fallback_method = "local_dict"
        else:
            keyword_fallback_method = "none"

        # ⚠️ v16 新增：組長要求「在創新商品專案上標註創新」——原本
        # is_innovative_product(0/1) + novelty_reason 需要跨兩欄比對才看得懂，
        # 這裡加一個單一欄位、中文標籤，方便在Excel/表格裡一眼掃過去就能
        # 篩選出創新商品，不用另外查對照表。
        if is_innovative:
            innovation_label = "⚠️ 創新商品（市場無直接對應物，偏離度數字僅供參考）"
        else:
            innovation_label = "✅ 一般商品（市場有可比對象）"

        _KEYWORD_METHOD_LABELS = {
            "none": "AI精準判斷（含規格特徵）",
            "local_dict": "本地品類字典比對",
            "relaxed_ai_retry": "AI寬鬆版二次判斷",
            "total_failure": "完全無法分類（核心售價±30%保底）",
        }
        keyword_fallback_method_label = _KEYWORD_METHOD_LABELS.get(
            keyword_fallback_method, keyword_fallback_method)

        # ══════════════════════════════════════════════════════════════
        # 人工複核標記：核心價與市場價差距過大、或市場價本身不夠可靠時，
        # 明確標示出來讓人工檢查，而不是讓這種案例默默混在整份 CSV 裡。
        # 判斷邏輯（符合任一項就標記需要複核）：
        #   1. 完全沒取得市場資料（status 會另外反映，這裡針對「有資料但
        #      看起來不合理」的情況）
        #   2. 核心價與市場行情中位數的偏離幅度超過門檻（預設 ±50%）
        #   3. 樣本數過少（<2筆）或出現過極端價格比值
        #   4. 創新商品：deviation數字本身不具參考意義，但仍標記出來，
        #      理由跟「一般商品但差距過大」明確區分，避免被誤判成定價異常
        # ══════════════════════════════════════════════════════════════
        DEVIATION_REVIEW_THRESHOLD = 0.5  # 偏離market中位數超過50%就標記複核

        review_flags: List[str] = []
        if is_innovative:
            review_flags.append(f"創新商品（{novelty_reason}），偏離度數字僅供參考，"
                                f"複核重點應放在關鍵字/matched_product_titles是否合理，"
                                f"而非deviation數字本身")
        elif market_max == 0:
            review_flags.append("完全沒有取得市場行情資料")
        else:
            if deviation is not None and abs(deviation) >= DEVIATION_REVIEW_THRESHOLD:
                direction = "高於" if deviation > 0 else "低於"
                review_flags.append(f"核心價比市場行情中位數{direction}"
                                    f"{abs(deviation):.0%}，超過{DEVIATION_REVIEW_THRESHOLD:.0%}門檻")
            if low_sample_warning:
                review_flags.append("真實比價樣本數過少(<2筆)或出現極端價格比值")

        needs_manual_review = int(bool(review_flags))
        review_reason = "；".join(review_flags) if review_flags else ""

        return {
            "product_keyword":       keyword,
            "project_core_price":    core_price,
            "price_source":          price_source,
            "market_price_min":      market_min,
            "market_price_max":      market_max,
            "market_range_str":      range_str,
            "market_data_quality":   quality,
            "market_platforms":      "、".join(platforms) if platforms else "",
            "market_platform_count": len(platforms),
            "market_has_real_search": int(has_real_search),
            "is_verified_market_price": int(is_verified),
            "keyword_is_category_fallback": int(used_category_fallback),
            "keyword_fallback_method": keyword_fallback_method,
            "keyword_fallback_method_label": keyword_fallback_method_label,
            "price_deviation_ratio": deviation,
            "is_price_competitive":  is_competitive,
            "low_sample_warning":    int(low_sample_warning),
            "avg_match_relevance":   avg_relevance,
            "matched_product_titles": "; ".join(matched_titles) if matched_titles else "",
            "is_innovative_product": is_innovative,
            "novelty_reason":        novelty_reason,
            "innovation_label":      innovation_label,
            "needs_manual_review":   needs_manual_review,
            "review_reason":         review_reason,
        }

    def _load_cache(self) -> dict:
        if not os.path.exists(CACHE_FILE):
            return {}
        try:
            with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                raw_cache = json.load(f)
        except Exception:
            return {}

        # 自動清除舊版本可能殘留的「失敗結果」快取（例如金鑰失效那次寫入的紀錄），
        # 避免程式一直讀到過期的失敗結果而不重試。
        cleaned = {}
        removed = 0
        for k, v in raw_cache.items():
            is_bad = (
                (isinstance(v, dict) and v.get("keyword") == "未分類商品") or
                (isinstance(v, dict) and str(v.get("range_str", "")).startswith("無法取得"))
            )
            if is_bad:
                removed += 1
                continue
            cleaned[k] = v
        if removed:
            print(f"  🧹 已自動清除 {removed} 筆過期的失敗快取紀錄，將重新嘗試。")
            with open(CACHE_FILE, 'w', encoding='utf-8') as f:
                json.dump(cleaned, f, ensure_ascii=False)
        return cleaned

    def _save_cache(self):
        with open(CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(self._cache, f, ensure_ascii=False)




# ══════════════════════════════════════════════════════════════════════
# 報告列印
# ══════════════════════════════════════════════════════════════════════

def _print_plans_table(parsed_plans: List[dict], core_price: int = 0):
    print("\n  ┌──────────────────────────────────────────────────────────────┐")
    print("  │                      方案定價明細                             │")
    print("  ├──────────────────────────┬───────┬───────┬───────┬──────────┤")
    print("  │ 方案名稱                 │  售價 │  單價 │  折扣 │ 標籤     │")
    print("  ├──────────────────────────┼───────┼───────┼───────┼──────────┤")
    for p in parsed_plans:
        title    = p["title"][:22].ljust(22)
        sale     = f"NT${p['sale_price']:,}".rjust(7)
        unit     = f"NT${p['unit_price']:,}".rjust(7) if p.get("qty", 1) > 1 else "      -"
        discount = (f"{round(p['sale_price']/p['original_price']*10,1)}折"
                    if p.get("original_price", 0) > p["sale_price"] else "  - ")
        tags = []
        if p.get("is_single"):     tags.append("單入")
        if p.get("is_early_bird"): tags.append("🐦早鳥")
        if p.get("is_multi"):      tags.append(f"×{p.get('qty',2)}")
        if p.get("is_addon"):      tags.append("加購")
        if p.get("is_bundle"):     tags.append("🎁組合")
        is_core = (core_price > 0 and p["unit_price"] == core_price
                   and not p.get("is_early_bird") and not p.get("is_addon")
                   and not p.get("is_bundle"))
        if is_core:                tags.append("★核心")
        tag_str = " ".join(tags).ljust(8)
        print(f"  │ {title} │ {sale} │ {unit} │ {discount} │ {tag_str} │")
    print("  └──────────────────────────┴───────┴───────┴───────┴──────────┘")


def _print_market_report(price_result: Dict[str, Any]):
    kw    = price_result["product_keyword"]
    cp    = price_result["project_core_price"]
    src   = price_result["price_source"]
    mmin  = price_result["market_price_min"]
    mmax  = price_result["market_price_max"]
    rstr  = price_result["market_range_str"]
    qual  = price_result["market_data_quality"]
    dev   = price_result["price_deviation_ratio"]
    comp  = price_result["is_price_competitive"]
    plats = price_result.get("market_platforms", "")
    has_real = price_result.get("market_has_real_search", 0)

    verdict = "✅ 價格具競爭力" if comp else "⚠️  價格偏離市場行情"
    dev_str = f"{dev:+.1%}" if dev is not None else "N/A"

    bar_len = 32
    if mmax > mmin:
        pos        = max(0.0, min(1.0, (cp - mmin) / (mmax - mmin)))
        marker_pos = int(pos * bar_len)
        bar        = "─" * marker_pos + "▲" + "─" * (bar_len - marker_pos)
        bar_line   = f"  ║  NT${mmin:<7,}[{bar}]NT${mmax:<7,}║"
    else:
        bar_line   = f"  ║  市場行情：{rstr:<46}║"

    quality_label = {
        "verified": "✅ 已驗證（直接抓取商品頁面）",
        "high":     "高（≥2個平台交叉比對）",
        "medium":   "中（單一平台/筆數較少，或AI推斷但信心不低）",
        "low":      "低（估算值）",
    }.get(qual, qual)
    is_verified = price_result.get("is_verified_market_price", 0)
    if is_verified:
        real_label = "✅✅ 真實比價（結構化資料驗證，非AI詮釋）"
    elif has_real:
        real_label = "✅ 有真實網頁佐證（AI協助解讀）"
    else:
        real_label = "⚠️  無真實網頁佐證（AI推斷/保底估算）"
    plats_line = f"  ║  來源平台     {plats:<38}║" if plats else \
                 "  ║  來源平台     （未標示，可能為單一來源或估算值）      ║"

    print(f"""
  ╔══════════════════════════════════════════════════════╗
  ║              市場價格競爭力診斷報告                  ║
  ╠══════════════════════════════════════════════════════╣
  ║  產品關鍵字   {kw:<38}║
  ║  核心售價     NT${cp:<6,}  （來源：{src:<8}）           ║
  ║  市場行情     {rstr:<40}║
  ║  資料品質     {quality_label:<38}║
  ║  資料可信度   {real_label:<38}║
{plats_line}
  ║                                                      ║
{bar_line}
  ║                                                      ║
  ║  偏離幅度     {dev_str:<8}  {verdict:<27}║
  ╚══════════════════════════════════════════════════════╝""")

    if price_result.get("low_sample_warning"):
        print("  ⚠️  【樣本數警示】真實比價樣本數不足或價格與核心售價差距懸殊，"
              "上方數字建議人工複核，不宜直接視為高信心行情。")
    if price_result.get("matched_product_titles"):
        print(f"  🔗 比對到的商品標題：{price_result['matched_product_titles']}")
    if price_result.get("is_innovative_product"):
        print(f"  💡 【創新商品判定】{price_result.get('novelty_reason', '')}\n"
              f"     → 此筆的偏離幅度／競爭力判定建議謹慎解讀，"
              f"市場可能無法提供真正對應的比價基準。")
    if price_result.get("needs_manual_review"):
        print(f"  🔍 【需人工複核】{price_result.get('review_reason', '')}")


# ══════════════════════════════════════════════════════════════════════
# 主測試流程
# ══════════════════════════════════════════════════════════════════════

def run_test(plans_file: str = PLANS_FILE, content_file: str = CONTENT_FILE):
    print("\n" + "=" * 62)
    print(" 🧪 市場價格比對測試 v5.1（Gemini 呼叫最小化 + Colab 相容版）")
    print(f"    model   : {GEMINI_MODEL}")
    print(f"    plans   : {plans_file}")
    print(f"    content : {content_file}")
    print(f"    搜尋方式 : Google Search Grounding（無需 SerpAPI）")
    print("=" * 62)

    plans_text   = _read_file(plans_file)
    content_text = _read_file(content_file)
    if not content_text.strip():
        print("❌ content 檔案無法讀取，終止。")
        print("   （在 Colab 中可用左側檔案面板上傳，或執行："
              "from google.colab import files; files.upload()）")
        return

    api_key = _get_api_key()
    if not api_key:
        print("❌ 找不到 GEMINI_API_KEY。請用以下任一方式提供：\n"
              "   1) 本機：os.environ['GEMINI_API_KEY'] = 'AIza...'\n"
              "   2) Colab：左側 🔑 Secrets 面板新增 GEMINI_API_KEY 並開啟筆記本存取權\n"
              "   3) 直接依提示互動輸入金鑰")
        return
    client = genai.Client(api_key=api_key)

    # ── 步驟 1：解析 plans.txt ─────────────────────────────────────
    print("\n【步驟 1】解析 plans.txt 方案定價...")
    parser     = PlansParser()
    plans_info = parser.parse(plans_text)
    if plans_info["plans_count"] > 0:
        print(f"  ✅ 找到 {plans_info['plans_count']} 個方案")
        print(f"     核心售價（標準單入）  ：NT${plans_info['plans_core_price']:,}  ← 市場比對用")
        print(f"     最低活動價（含早鳥）  ：NT${plans_info['plans_min_price']:,}")
        print(f"     最高方案售價          ：NT${plans_info['plans_max_price']:,}")
        print(f"     含早鳥方案：{'是' if plans_info['plans_has_early_bird'] else '否'}")
        _print_plans_table(plans_info["parsed_plans"], plans_info["plans_core_price"])
    else:
        print("  ⚠️  未找到 plans.txt 或格式不符，將由 LLM 推斷價格。")

    # ── 步驟 2：規格化關鍵字判斷（Call 1）+ 單次市場行情搜尋（Call 2）──
    print("\n【步驟 2】Gemini 判斷含規格特徵的關鍵字 → 單次 Google Search 搜尋行情...")
    market_agent = MarketPriceAgent(client, content_text)
    price_result = market_agent.analyze(content_text, plans_info=plans_info)
    _print_market_report(price_result)

    # ── 步驟 3：摘要 ───────────────────────────────────────────────
    dev = price_result["price_deviation_ratio"]
    print("\n【診斷摘要】")
    print(f"  最終關鍵字  ：{price_result['product_keyword']}")
    print(f"  核心售價    ：NT${price_result['project_core_price']:,}  (來源：{price_result['price_source']})")
    print(f"  市場行情    ：{price_result['market_range_str']}")
    print(f"  資料品質    ：{price_result['market_data_quality']}")
    print(f"  來源平台    ：{price_result.get('market_platforms') or '（未標示）'}")
    print(f"  偏離幅度    ：{f'{dev:+.2%}' if dev is not None else 'N/A'}")
    print(f"  競爭力判定  ：{'✅ 具競爭力' if price_result['is_price_competitive'] else '⚠️  偏離市場'}\n")



# ══════════════════════════════════════════════════════════════════════
# 批次處理：走訪整個資料集資料夾，逐一分析每個專案並輸出成 CSV
# （原本獨立的 batch_process_zeczec.py，現在合併進同一支檔案）
# ══════════════════════════════════════════════════════════════════════

import csv
import glob



def _find_projects(root_dir: str) -> List[Dict[str, str]]:
    """
    走訪 root_dir 底下所有資料夾，只要該資料夾內有 *_content.txt，
    就視為一個「專案」，並自動配對同前綴的 _plans.txt。

    回傳每個專案的資訊 dict：
      project_id   : 專案資料夾名稱（例如 ES32_hohoka-01）
      prefix       : 檔名前綴（例如 ES32）
      content_path : content.txt 完整路徑
      plans_path   : plans.txt 完整路徑（找不到則為 None）
      category_path: 相對於 root_dir 的分類路徑（例如 預購式專案/教育/成功）
    """
    projects = []
    for dirpath, _dirnames, filenames in os.walk(root_dir):
        content_files = [f for f in filenames if f.endswith("_content.txt")]
        if not content_files:
            continue
        for content_file in content_files:
            prefix = content_file[: -len("_content.txt")]
            plans_file = f"{prefix}_plans.txt"
            plans_path = os.path.join(dirpath, plans_file)
            if not os.path.exists(plans_path):
                # 找不到同前綴的 plans.txt，嘗試該目錄下唯一的 *_plans.txt 當備援
                candidates = glob.glob(os.path.join(dirpath, "*_plans.txt"))
                plans_path = candidates[0] if len(candidates) == 1 else None

            project_folder = os.path.basename(dirpath.rstrip(os.sep))
            category_path = os.path.relpath(dirpath, root_dir)

            projects.append({
                "project_id":    project_folder,
                "prefix":        prefix,
                "content_path":  os.path.join(dirpath, content_file),
                "plans_path":    plans_path,
                "category_path": category_path,
            })
    return projects


def _load_done_ids(output_csv: str) -> set:
    """讀取已存在的 CSV，取得已經處理過的 project_id 集合，用於續跑。"""
    done = set()
    if os.path.exists(output_csv):
        try:
            with open(output_csv, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row.get("project_id"):
                        done.add(row["project_id"])
        except Exception as e:
            print(f"⚠️  讀取既有 CSV 失敗（將視為從頭開始）：{e}")
    return done


_CSV_FIELDS = [
    # ── 專案識別 ──
    "project_id", "category_path", "status", "error_message",
    # ── 人工複核標記：放最前面方便直接排序/篩選 ──
    "needs_manual_review",   # 1=建議人工檢查這一列（差距過大/樣本不足/創新商品）
    "review_reason",         # 具體標記原因（中文說明）
    # ── 核心價格 vs 市場行情：最主要的比較結果 ──
    "product_keyword", "project_core_price",
    "market_price_min", "market_price_max", "market_data_quality",
    "price_deviation_ratio", "is_price_competitive",
    # ── 判讀輔助：解讀上面數字前務必先看這兩欄 ──
    "innovation_label",          # 創新商品時，deviation數字不具參考意義
    "matched_product_titles",    # 人工核對「抓到的商品」是否真的跟募資商品同類
]

# 完整版欄位（保留所有透明度/溯源細節，供需要深入除錯或稽核時使用）：
_CSV_FIELDS_FULL = _CSV_FIELDS + [
    "plans_count", "plans_core_price", "plans_min_price", "plans_max_price",
    "plans_has_early_bird", "price_source",
    "market_range_str", "market_platforms", "market_platform_count",
    "market_has_real_search", "is_verified_market_price",
    "keyword_is_category_fallback", "keyword_fallback_method",
    "keyword_fallback_method_label",
    "low_sample_warning", "avg_match_relevance", "is_innovative_product",
    "novelty_reason",
]


def batch_run(root_dir: str,
              output_csv: str = "market_price_results.csv",
              max_projects: Optional[int] = None,
              sleep_between: float = 5.0,
              full_output: bool = False) -> str:
    """
    走訪 root_dir 底下所有專案，逐一分析後輸出成 CSV。

    root_dir      : 資料集根目錄
    output_csv    : 輸出 CSV 路徑；若檔案已存在，會自動跳過已處理過的 project_id（續跑）
    max_projects  : 限制最多處理幾個專案（測試用，None 代表全部處理）
    sleep_between : 每個專案處理完後的間隔秒數，避免短時間內打太多次 API。
                    免費層級 RPM 額度可能很低（例如 5 RPM，等於平均每 12 秒
                    才能打 1 次），建議設定 5~10 秒以上，實際撞到限流時
                    _call_gemini 內部也會用 Google 建議的 retryDelay 自動等待重試。
    full_output   : False（預設）只輸出精簡版14欄，聚焦在「核心價 vs 市場價」
                    的比較結果與人工複核標記；True 則輸出完整版所有透明度/
                    溯源欄位（plans細節、平台清單、關鍵字備援方法等），適合
                    需要深入除錯或稽核資料來源時使用。
    """
    fieldnames = _CSV_FIELDS_FULL if full_output else _CSV_FIELDS

    projects = _find_projects(root_dir)
    print(f"📂 掃描到 {len(projects)} 個專案（含 *_content.txt 的資料夾）")

    done_ids = _load_done_ids(output_csv)
    if done_ids:
        print(f"↩️  偵測到既有結果 {len(done_ids)} 筆，將自動跳過已處理過的專案")

    todo = [p for p in projects if p["project_id"] not in done_ids]
    if max_projects is not None:
        todo = todo[:max_projects]
    print(f"🚀 本次將處理 {len(todo)} 個專案（輸出欄位：{'完整版' if full_output else '精簡版'}，"
          f"共 {len(fieldnames)} 欄）\n")

    api_key = _get_api_key()
    if not api_key:
        raise RuntimeError("找不到 GEMINI_API_KEY，請先設定環境變數 / Colab Secrets / 互動輸入。")
    client = genai.Client(api_key=api_key)
    agent = MarketPriceAgent(client, content_text="")

    file_exists = os.path.exists(output_csv)
    with open(output_csv, "a", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()

        success_count = 0
        fail_count = 0
        review_count = 0
        t0 = time.time()

        for i, proj in enumerate(todo, 1):
            pid = proj["project_id"]
            print(f"[{i}/{len(todo)}] 處理 {pid} ...")
            row = {k: "" for k in fieldnames}
            row["project_id"] = pid
            row["category_path"] = proj["category_path"]

            try:
                if not proj["plans_path"]:
                    raise FileNotFoundError("找不到對應的 *_plans.txt")

                content_text = _read_file(proj["content_path"])
                plans_text = _read_file(proj["plans_path"])
                if not content_text.strip():
                    raise ValueError("content.txt 內容為空")

                plans_info = PlansParser().parse(plans_text)
                result = agent.analyze(content_text, plans_info=plans_info)
                # 自動比對 plans_info / result 字典裡有的欄位，依目前選用的
                # fieldnames（精簡版或完整版）填入，不需要另外維護一份手動
                # 對應清單、避免欄位改名/新增時漏改造成CSV跟_CSV_FIELDS兜不起來
                for k in fieldnames:
                    if k in plans_info:
                        row[k] = plans_info.get(k, "")
                    if k in result:
                        row[k] = result.get(k, "")

                row["status"] = "success" if result.get("market_price_max", 0) else "no_market_data"
                success_count += 1
                if result.get("needs_manual_review"):
                    review_count += 1
                    print(f"  ⚠️  {result.get('product_keyword')} | "
                          f"核心 NT${result.get('project_core_price', 0):,} | "
                          f"行情 {result.get('market_range_str')} | "
                          f"🔍 需人工複核：{result.get('review_reason')}")
                else:
                    print(f"  ✅ {result.get('product_keyword')} | "
                          f"核心 NT${result.get('project_core_price', 0):,} | "
                          f"行情 {result.get('market_range_str')}")

            except DailyQuotaExceededError as e:
                row["status"] = "error"
                row["error_message"] = f"每日額度用完：{e}"
                writer.writerow(row)
                f.flush()
                print(f"\n{'=' * 50}")
                print("🛑 Gemini API 每日額度已用完，批次處理提前停止。")
                print(f"   已完成 {i-1}/{len(todo)} 筆（{success_count} 成功 / {fail_count} 失敗），"
                      f"結果已存到 {output_csv}。")
                print("   要等到太平洋時間午夜 00:00（約台灣時間下午 3~4 點）額度重置後，"
                      "重新執行同一段程式碼即可（會自動跳過已完成的專案，接續處理）。")
                print(f"{'=' * 50}")
                return output_csv

            except Exception as e:
                row["status"] = "error"
                row["error_message"] = str(e)
                fail_count += 1
                print(f"  ❌ 失敗：{e}")

            writer.writerow(row)
            f.flush()  # 每筆立即寫入，中途中斷也不會遺失前面已完成的結果
            time.sleep(sleep_between)

    elapsed = time.time() - t0
    print(f"\n{'=' * 50}")
    print(f"✅ 批次處理完成：成功 {success_count} / 失敗 {fail_count}"
          f"（共 {len(todo)} 筆，耗時 {elapsed/60:.1f} 分鐘）")
    if review_count:
        print(f"🔍 其中 {review_count} 筆標記為 needs_manual_review=1，建議優先人工複核")
    print(f"📄 結果已輸出到：{output_csv}")
    print(f"{'=' * 50}")
    return output_csv


# ══════════════════════════════════════════════════════════════════════
# 執行入口：可以單一測試一個專案，也可以批次跑整個資料集
# ══════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    # ── 模式 A：單一專案測試 ──────────────────────────────────────
    # run_test(
    #     plans_file   = PLANS_FILE,
    #     content_file = CONTENT_FILE,
    # )

    # ── 模式 B：批次處理整個資料集資料夾，輸出成 CSV ──────────────
    batch_run(
        root_dir      = "/content/drive/MyDrive/ZecZec_Group_Data/設計_New_ZecZec_Dataset",   # 換成你實際的資料集根目錄
        output_csv    = "/content/drive/MyDrive/ZecZec_Group_Data/設計_New_ZecZec_Dataset/market_price_results.csv",
        max_projects  = None,   # 測試時可先設 5，跑通後再改回 None 跑全部
        sleep_between = 5.0,
    )