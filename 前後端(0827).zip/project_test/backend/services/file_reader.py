# 負責「打開檔案、拿出裡面的文字」，不做任何語意分析或特徵計算。
#
# 這支檔案是刻意跟 extractor.py 分開的：extractor.py 負責「特徵工程」
# （文字要怎麼變成 feat_text_risk_ratio 這種數字），這支檔案只負責
# 「內容萃取」（PDF/Word 裡到底寫了什麼字）。分開的理由是這兩件事的
# 生命週期不一樣——內容萃取現在就能做、以後也不太會變；特徵工程要等
# 正式模型的特徵定義確定才能寫，之後改動也只會動 extractor.py，
# 不會動到這支檔案。
#
# 【目前支援】.txt（直接讀）、.pdf（用 pdfplumber）、.docx（用 python-docx）
# 【目前不支援】.doc（舊版 Word 二進位格式，沒有穩定的純 Python 套件可讀，
#   如果組員上傳 .doc，會回傳空字串並在 warnings 裡註明，不會讓整個流程掛掉）
#
# media_file（圖片/影片）目前只回傳基本資訊（檔名、MIME type、大小），
# 真正的影像內容分析（場景辨識、Gemini 影片分析）需要 OpenCV + Gemini API，
# 是後續 LLM 分析階段的工作範圍，不在這支檔案處理。

import io
from fastapi import UploadFile
from typing import List


async def extract_text_from_content_file(upload: UploadFile | None) -> tuple[str, list[str]]:
    """回傳 (純文字內容, 警告訊息清單)。讀不到內容時回傳空字串，
    不會拋例外讓整個 API 掛掉——檔案格式問題應該是「這次分析不完整」，
    不該是「整個請求失敗」。"""
    warnings: list[str] = []
    if upload is None:
        return "", warnings

    raw = await upload.read()
    filename = (upload.filename or "").lower()

    if filename.endswith(".txt"):
        try:
            return raw.decode("utf-8", errors="ignore"), warnings
        except Exception as e:
            warnings.append(f"讀取 .txt 檔案失敗：{e}")
            return "", warnings

    if filename.endswith(".pdf"):
        try:
            import pdfplumber
        except ImportError:
            warnings.append("缺少 pdfplumber 套件，無法解析 PDF，請先 pip install pdfplumber")
            return "", warnings
        try:
            text_parts = []
            with pdfplumber.open(io.BytesIO(raw)) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text_parts.append(page_text)
            return "\n".join(text_parts), warnings
        except Exception as e:
            warnings.append(f"解析 PDF 失敗（可能是掃描檔沒有文字層，或檔案損毀）：{e}")
            return "", warnings

    if filename.endswith(".docx"):
        try:
            import docx
        except ImportError:
            warnings.append("缺少 python-docx 套件，無法解析 Word 檔，請先 pip install python-docx")
            return "", warnings
        try:
            doc = docx.Document(io.BytesIO(raw))
            return "\n".join(p.text for p in doc.paragraphs), warnings
        except Exception as e:
            warnings.append(f"解析 Word 檔失敗：{e}")
            return "", warnings

    if filename.endswith(".doc"):
        warnings.append("不支援舊版 .doc 格式，請另存成 .docx 或 .pdf 後重新上傳")
        return "", warnings

    warnings.append(f"未知的文案檔案格式：{upload.filename}，未進行內容萃取")
    return "", warnings


async def extract_faq_items(upload: UploadFile | None) -> tuple[list[str], list[str]]:
    """把 FAQ 檔案解析成一行一題的清單。目前假設格式是「一行一題」的純文字，
    如果之後 FAQ 檔案有固定的結構化格式（例如 CSV：問題,答案），
    在這裡加對應的解析分支即可，不用動呼叫端的程式碼。"""
    warnings: list[str] = []
    if upload is None:
        return [], warnings

    raw = await upload.read()
    try:
        text = raw.decode("utf-8", errors="ignore")
        items = [line.strip() for line in text.splitlines() if line.strip()]
        return items, warnings
    except Exception as e:
        warnings.append(f"解析 FAQ 檔案失敗：{e}")
        return [], warnings

async def get_media_file_info(uploads: List[UploadFile] | None) -> dict:
    """處理多個圖片/影片上傳，回傳總檔案數與加總大小。
    目前只回傳基本資訊，不做真正的影像/影片內容分析。
    真正的分析（場景辨識、Gemini 影片理解）屬於下一階段 LLM 分析工作，
    這裡先確保檔案至少有被正確接收、讀取，回傳的 size 可以用來確認
    上傳有沒有成功（size=0 代表檔案是空的或上傳有問題）。"""
    if not uploads:
        return {"has_file": False, "count": 0, "total_size_bytes": 0}

    # 過濾掉空的上傳 (有時候前端傳 multiple 但沒選檔案，會送出空檔名)
    valid_uploads = [f for f in uploads if f.filename]
    if not valid_uploads:
        return {"has_file": False, "count": 0, "total_size_bytes": 0}

    total_size = 0
    file_names = []
    
    for upload in valid_uploads:
        raw = await upload.read()
        total_size += len(raw)
        file_names.append(upload.filename)

    return {
        "has_file": True,
        "count": len(valid_uploads),
        "filenames": file_names,
        "total_size_bytes": total_size,
    }