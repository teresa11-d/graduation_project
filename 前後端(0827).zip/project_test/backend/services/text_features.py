# 從組員的 text_feature_llm.py（agent_copywriting_gemini.py）移植過來的
# RuleBasedExtractor，邏輯完全不變，只拿掉跟 Colab/資料夾掃描相關的部分。
# 純正則表達式 + jieba 斷詞，不呼叫任何 API，可以直接同步呼叫，
# 毫秒等級完成，不需要放進背景工作。
#
# 對應模型特徵（27 個裡目前空著的）：
#   feat_text_risk_ratio, feat_text_spec_ratio_rule,
#   feat_has_social_link, feat_punct_intensity
# 這裡也一併算出 feat_text_story_ratio / feat_avg_sentence_len /
# feat_type_token_ratio，目前的正式模型沒用到這三個，但算出來無害
# （extractor.py 最後會用 df[expected_features] 篩選，多算的欄位會被忽略），
# 保留是因為之後模型改版有可能又把它們納入。

import re
from typing import Optional, Dict, Any

try:
    import jieba.posseg as pseg
    _JIEBA_AVAILABLE = True
except ImportError:
    _JIEBA_AVAILABLE = False


class RuleBasedExtractor:
    def __init__(self):
        self.social_pattern = re.compile(
            r'(facebook\.com|fb\.me|fb\.com|instagram\.com|ig\.me|line\.me|lin\.ee|linktr\.ee)',
            re.IGNORECASE,
        )
        self.risk_pattern = re.compile(r'(風險與挑戰|退換貨規則|注意事項)(.*?)(?=(產品規格|常見問題|$))', re.DOTALL)
        self.spec_pattern = re.compile(r'(產品規格|規格說明)(.*?)(?=(風險與挑戰|常見問題|$))', re.DOTALL)
        self.sentence_split_pattern = re.compile(r'[。！？!\?\n]')
        self.sensational_punct_pattern = re.compile(r'[！？!\?]')

    def _clean_text(self, text: str) -> str:
        return re.sub(r'\s', '', text)

    def extract(self, text: str) -> Optional[Dict[str, Any]]:
        if not text or not isinstance(text, str) or len(text.strip()) < 5:
            return None

        clean_text = self._clean_text(text)
        total_chars = len(clean_text)
        sentences = [s for s in self.sentence_split_pattern.split(text) if s.strip()]
        num_sentences = max(1, len(sentences))

        risk_match = self.risk_pattern.search(text)
        spec_match = self.spec_pattern.search(text)
        risk_len = len(self._clean_text(risk_match.group(0))) if risk_match else 0
        spec_len = len(self._clean_text(spec_match.group(0))) if spec_match else 0
        story_len = max(0, total_chars - risk_len - spec_len)

        has_social_link = 1 if self.social_pattern.search(text) else 0

        result = {
            "feat_text_story_ratio": round(story_len / total_chars, 4) if total_chars else 0.0,
            "feat_text_spec_ratio_rule": round(spec_len / total_chars, 4) if total_chars else 0.0,
            "feat_text_risk_ratio": round(risk_len / total_chars, 4) if total_chars else 0.0,
            "feat_has_social_link": has_social_link,
            "feat_punct_intensity": round(len(self.sensational_punct_pattern.findall(text)) / num_sentences, 4),
            "feat_avg_sentence_len": round(total_chars / num_sentences, 2),
        }

        # jieba 斷詞算 type_token_ratio；沒裝 jieba 也不讓整個流程掛掉，
        # 只是這個欄位缺席（extractor.py 那邊會自動留 NaN）。
        if _JIEBA_AVAILABLE:
            words_with_flags = list(pseg.cut(text))
            valid_words = [(w, f) for w, f in words_with_flags if f != 'x']
            total_words = max(1, len(valid_words))
            unique_words = set(w for w, _ in valid_words)
            result["feat_type_token_ratio"] = round(len(unique_words) / total_words, 4)

        return result