# 負責將前端表單與上傳檔案轉換成模型需要的特徵。
#
# 這次拆成兩個函式：
#   build_sync_features()  — 立刻能算完的部分（表單數值 + RuleBasedExtractor），
#                             毫秒等級，直接在 request handler 裡呼叫。
#   run_llm_analysis()     — 需要打 Gemini/比價的部分，丟進 job_manager 背景執行，
#                             完成後把結果併回特徵列，才真正呼叫模型預測。

import os
import numpy as np
import pandas as pd

from services.file_reader import extract_text_from_content_file, extract_faq_items, get_media_file_info
from services.text_features import RuleBasedExtractor
from services.copywriting_agent import CopywritingAgent
from services.market_price_agent import MarketPriceAgent  # 就是複製過去的 market_price.py

_rule_extractor = RuleBasedExtractor()


async def build_sync_features(
    project_type: str, category: str, funding_days: int, target_amount: int,
    price_tiers: int, prices: list,
    content_file, media_files, faq_file, expected_features: list,  # 💡 改為 media_files
) -> tuple[dict, str, dict]:
    """回傳 (feature_dict, content_text, extraction_info)。
    feature_dict 這裡已經填好所有「不需要等 LLM」的欄位；content_text 會
    再傳給背景工作用，不用重新讀一次上傳檔案。"""
    warnings: list[str] = []

    prices_float = []
    for p in prices:
        try:
            prices_float.append(float(p.strip()))
        except (ValueError, AttributeError):
            continue

    feature_dict = {f: np.nan for f in expected_features}
    feature_dict['funding_duration_days'] = funding_days
    feature_dict['target_amount'] = target_amount
    feature_dict['reward_tier_count'] = price_tiers
    feature_dict['reward_price_min'] = min(prices_float) if prices_float else np.nan
    feature_dict['reward_price_max'] = max(prices_float) if prices_float else np.nan
    feature_dict['reward_price_median'] = float(np.median(prices_float)) if prices_float else np.nan

    cat_col = f"category_{category}"
    if cat_col in expected_features:
        feature_dict[cat_col] = 1
    else:
        warnings.append(f"類別「{category}」不在模型已知類別清單中，未納入評分")

    plat_col = f"platform_{project_type}"
    if plat_col in expected_features:
        feature_dict[plat_col] = 1
    else:
        warnings.append(f"募資模式「{project_type}」不在模型已知清單中，未納入評分")

    content_text, content_warnings = await extract_text_from_content_file(content_file)
    faq_items, faq_warnings = await extract_faq_items(faq_file)
    media_info = await get_media_file_info(media_files)
    warnings += content_warnings + faq_warnings

    if content_text:
        rule_result = _rule_extractor.extract(content_text)
        if rule_result:
            for key, value in rule_result.items():
                if key in expected_features:
                    feature_dict[key] = value
    else:
        warnings.append("未提供文案內容或無法解析，規則式文案特徵暫時無法計算")

    extraction_info = {
        "content_text_length": len(content_text),
        "faq_item_count": len(faq_items),
        "media_info": media_info,
        "warnings": warnings,
    }
    return feature_dict, content_text, extraction_info


def run_llm_analysis(feature_dict: dict, content_text: str, expected_features: list) -> dict:
    """這個函式會被 job_manager 丟進背景執行緒跑，不是 async（因為底層
    genai SDK 是同步呼叫），完成後回傳補完 LLM 特徵的完整 feature_dict。"""
    updated = dict(feature_dict)

    if content_text and 'feat_emotional_ratio' in expected_features:
        try:
            agent = CopywritingAgent()
            result = agent.analyze(content_text)
            if result.get("success") and result.get("feat_emotional_ratio") is not None:
                updated['feat_emotional_ratio'] = result['feat_emotional_ratio']
        except Exception as e:
            print(f"[CopywritingAgent 失敗，feat_emotional_ratio 維持缺值] {e}")

    market_feats = ['market_price_max', 'price_deviation_ratio', 'is_price_competitive',
                     'needs_manual_review', 'innovation_label_is_innovative']
    if content_text and any(f in expected_features for f in market_feats):
        try:
            from google import genai
            client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY", ""))
            price_agent = MarketPriceAgent(client=client, content_text=content_text)
            price_result = price_agent.analyze(content_text)
            # 核對過 market_price.py 第 1744~1766 行 analyze() 的實際 return dict，
            # 這裡是真正對得上的欄位名稱：
            mapping = {
                "market_price_max": price_result.get("market_price_max"),
                "price_deviation_ratio": price_result.get("price_deviation_ratio"),
                "is_price_competitive": price_result.get("is_price_competitive"),
                "needs_manual_review": price_result.get("needs_manual_review"),
                # is_innovative_product 是 bool，模型特徵是 innovation_label_is_innovative（0/1）
                "innovation_label_is_innovative": int(bool(price_result.get("is_innovative_product"))),
            }
            for k, v in mapping.items():
                if k in expected_features and v is not None:
                    updated[k] = v
        except Exception as e:
            print(f"[MarketPriceAgent 失敗，價格相關欄位維持缺值] {e}")

    return updated