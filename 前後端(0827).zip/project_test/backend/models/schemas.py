# 定義 Pydantic 資料結構 (Frontend 溝通格式)
from pydantic import BaseModel
from typing import List, Dict, Optional, Any

class FeatureScore(BaseModel):
    feature_name: str
    score: Optional[int] = None

class DimensionDetail(BaseModel):
    dimension_name: str
    score: Optional[int] = None
    weight: str
    features: List[FeatureScore]

class DiagnosisAdvice(BaseModel):
    tag_type: str
    dimension: str
    title: str
    original_setting: str
    suggestion: str

class DiagnosisResponse(BaseModel):
    success_rate: int
    radar_chart_data: Dict[str, Optional[int]]
    dimensions_evaluation: List[DimensionDetail]
    diagnosis_report: List[DiagnosisAdvice]


# ---- 新增：非同步工作用的回應格式 ----
class JobSubmittedResponse(BaseModel):
    job_id: str
    status: str  # "processing"


class JobStatusResponse(BaseModel):
    status: str  # "processing" / "done" / "failed"
    result: Optional[DiagnosisResponse] = None
    error: Optional[str] = None