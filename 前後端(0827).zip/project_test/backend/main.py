from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.router import router
import uvicorn

app = FastAPI(title="群眾募資多模態分析之評分與診斷系統 API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 註冊 API 路由
app.include_router(router)

def get_mock_response():
    """ 
    保留你原本在 [source: 8] 的 mock_response 
    當沒有 joblib 檔案時，系統會自動退回到這個備援方案
    """
    return {
        "success_rate": 82,
        "radar_chart_data": { "專案執行力": 85, "價格競爭力": 70, "文案說服力": 90, "影像吸引力": 80, "產品市場契合度": 85 },
        "dimensions_evaluation": [{
                    "dimension_name": "專案執行力",
                    "score": 85,
                    "weight": "權重15%",
                    "features": [
                        {"feature_name": "募資天數", "score": 85},
                        {"feature_name": "金額目標", "score": 60}
                    ]
                }], # ... 填入你原本的假資料
        "diagnosis_report": [{
                    "tag_type": "negative",
                    "dimension": "專案執行力",
                    "title": "建議立即修改：目標金額",
                    "original_setting": "原設定：新台幣 300 萬元在次分類「獨立出版/個人攝影集」",
                    "suggestion": "修改建議：建議調降初始目標金額！請精算您的「最低開模/印刷成本（MVP）」，將初始目標金額下修至 30 萬至 50 萬元之間。只要專案能順利跨越 100% 門檻，後續再利用「延伸目標（Stretch Goals）」來挑戰 100 萬或 300 萬。"
                },
                {
                    "tag_type": "positive",
                    "dimension": "專案執行力",
                    "title": "請繼續保持：募資天數",
                    "original_setting": "原設定：35 天的「設計/文具」主次分類中",
                    "suggestion": "修改建議：無需修改，35 天是非常完美的「急迫感區間」，既有足夠時間讓行銷發酵，又不會因為時間過長而產生拖延心態。"
                }]       # ... 填入你原本的假資料
    }

if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)