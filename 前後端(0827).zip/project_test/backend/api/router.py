# 檔案位置：backend/api/router.py
from fastapi import APIRouter, File, UploadFile, Form, HTTPException
from typing import List, Optional
import pandas as pd
import traceback

from models.schemas import DiagnosisResponse, JobSubmittedResponse, JobStatusResponse
from services.extractor import build_sync_features, run_llm_analysis
from services.ml_service import MLService
from services.job_manager import submit_job, get_job

router = APIRouter()
ml_service = MLService()  # 啟動時自動載入模型

@router.post("/api/v1/diagnose", response_model=JobSubmittedResponse)
async def run_diagnosis(
    project_type: str = Form(...),
    category: str = Form(...),
    funding_days: int = Form(...),
    target_amount: int = Form(...),
    price_tiers: int = Form(...),
    prices: List[str] = Form(...),
    content_file: Optional[UploadFile] = File(None),
    media_files: Optional[List[UploadFile]] = File(None), # 支援多圖片陣列上傳
    faq_file: Optional[UploadFile] = File(None)
):
    """立刻算完規則式特徵，把耗時的 LLM 分析丟進背景工作，回傳 job_id
    讓前端去 /api/v1/diagnose/{job_id} 輪詢結果，不會卡住這次請求。"""
    try:
        if not ml_service.is_ready:
            from main import get_mock_response
            job_id = submit_job(lambda: get_mock_response())
            return {"job_id": job_id, "status": "processing"}

        feature_dict, content_text, extraction_info = await build_sync_features(
            project_type, category, funding_days, target_amount, price_tiers, prices,
            content_file, media_files, faq_file, ml_service.all_features
        )
        if extraction_info.get("warnings"):
            print(f"[診斷警告] {extraction_info['warnings']}")

        def _full_pipeline():
            try:
                print("🚀 背景工作開始：執行 LLM 分析與價格檢索...", flush=True)
                final_features = run_llm_analysis(feature_dict, content_text, ml_service.all_features)
                df_input = pd.DataFrame([final_features])[ml_service.all_features]
                
                print("🧠 背景工作：執行 XGBoost & SHAP 評分...", flush=True)
                result = ml_service.predict_and_format(df_input)
                print("✅ 背景工作完成，結果已生成！", flush=True)
                
                # 🚨 關鍵防呆：必須把 result 回傳出去，否則 job_manager 會存入 null
                return result
                
            except Exception as e:
                print(f"❌ 背景工作發生錯誤:\n{traceback.format_exc()}", flush=True)
                raise e

        job_id = submit_job(_full_pipeline)
        return {"job_id": job_id, "status": "processing"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"診斷過程發生錯誤: {str(e)}")


@router.get("/api/v1/diagnose/{job_id}", response_model=JobStatusResponse)
async def get_diagnosis_result(job_id: str):
    job = get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="找不到這個工作 ID，可能已過期或伺服器重啟過")
    return job