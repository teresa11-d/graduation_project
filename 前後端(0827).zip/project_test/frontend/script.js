// 全局暫存後端傳回來的報告資料，方便標籤切換時重新渲染
let currentDiagnosisReport = [];
let currentRadarScores = [null, null, null, null, null];

// 1. 導覽切換
function switchView(viewId, navIndex) {
    document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
    document.getElementById('view-' + viewId).classList.add('active');

    document.querySelectorAll('.nav-item').forEach((el, idx) => {
        if (idx === navIndex) el.classList.add('active');
        else el.classList.remove('active');
    });
    
    // 💡 切換分頁時，帶入全域保存的真實分數重繪圖表
    if (viewId === 'scores' || viewId === 'form') {
        renderCharts(currentRadarScores);
    }
}

// 2. 檔名更新
function updateFileText(inputId, statusId) {
    const input = document.getElementById(inputId);
    const status = document.getElementById(statusId);
    if (input.files && input.files.length > 0) {
        if (input.files.length === 1) {
            status.innerText = input.files[0].name;
        } else {
            status.innerText = `已選擇 ${input.files.length} 個檔案`;
        }
    } else {
        status.innerText = "未選擇任何檔案";
    }
}

// 動態產生各層價格輸入框
function generatePriceFields() {
    const tiersInput = document.getElementById('priceTiersInput');
    const container = document.getElementById('priceFieldsContainer');
    if (!tiersInput || !container) return;

    let count = parseInt(tiersInput.value, 10);
    if (isNaN(count) || count < 1) count = 1;
    if (count > 10) {
        count = 10;
        tiersInput.value = 10;
    }

    const chineseNumbers = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十'];
    container.innerHTML = '';

    for (let i = 0; i < count; i++) {
        const inputEl = document.createElement('input');
        inputEl.type = 'number';
        inputEl.className = 'form-input';
        inputEl.name = 'prices';

        const numStr = chineseNumbers[i] || (i + 1);
        inputEl.placeholder = `第${numStr}層如：${(i + 1) * 2000 + 1000}`;
        inputEl.style.flex = '1';
        inputEl.style.minWidth = '130px';

        container.appendChild(inputEl);
    }
}

// 3. 手風琴選單
function toggleAccordion(headerEl) {
    const item = headerEl.parentElement;
    item.classList.toggle('open');
    const icon = headerEl.querySelector('.fa-caret-up, .fa-caret-down');
    icon.className = item.classList.contains('open') ? "fa-solid fa-caret-up" : "fa-solid fa-caret-down";
}

// ── 維度圖示對照表 ──────────────────────────────────────────
// 已知維度名稱先配好圖示跟顏色，維持原本設計的視覺風格；
// 遇到表裡沒列出的新維度名稱（例如模型之後把某個維度重新加回來、
// 或調整了名稱），會自動套用 DEFAULT_ICON，畫面不會壞掉。
const DIMENSION_ICON_MAP = {
    "專案執行力":      { icon: "fa-regular fa-flag",        bg: "#f8c33c" },
    "價格競爭力":      { icon: "fa-solid fa-dollar-sign",   bg: "#ffa73a" },
    "文案說服力":      { icon: "fa-regular fa-file-lines",  bg: "rgb(110, 155, 239)" },
    "影像吸引力":      { icon: "fa-solid fa-video",         bg: "#cc88ee" },
    "市場契合度(PMF)": { icon: "fa-solid fa-magnet",        bg: "#68ccc9" },
    "產品市場契合度":  { icon: "fa-solid fa-magnet",        bg: "#68ccc9" },
    "專案屬性":        { icon: "fa-solid fa-shield-halved", bg: "#8a8ad1" },
};
const DEFAULT_ICON = { icon: "fa-solid fa-circle-info", bg: "#a09e9a" };

function getDimensionIcon(dimensionName) {
    return DIMENSION_ICON_MAP[dimensionName] || DEFAULT_ICON;
}

function formatScoreValue(score) {
    return (score === null || score === undefined)
        ? '<span style="color:#B0A99A;">尚未分析</span>'
        : `${score}分`;
}

// ── 動態產生「細項評分」手風琴（View 2）──────────────────────
// 同樣依 DIMENSION_ORDER 排序，跟診斷報告分頁的順序保持一致，
// 避免使用者在「細項評分」跟「診斷報告」兩個頁面看到不一樣的維度順序。
function renderAccordion(dimensionsEvaluation) {
    const container = document.getElementById('accordionContainer');
    if (!container) return;
    container.innerHTML = '';

    const sorted = [...dimensionsEvaluation].sort((a, b) => {
        const idxA = DIMENSION_ORDER.indexOf(a.dimension_name);
        const idxB = DIMENSION_ORDER.indexOf(b.dimension_name);
        return (idxA === -1 ? 999 : idxA) - (idxB === -1 ? 999 : idxB);
    });

    sorted.forEach((dim, idx) => {
        const iconInfo = getDimensionIcon(dim.dimension_name);
        const isFirst = idx === 0; // 第一項預設展開

        const featuresHtml = dim.features.map(f =>
            `<div class="sub-score-row"><span>${f.feature_name}</span><b>  ${formatScoreValue(f.score)}</b></div>`
        ).join('');

        const itemHtml = `
            <div class="accordion-item ${isFirst ? 'open' : ''}">
                <div class="accordion-header" onclick="toggleAccordion(this)">
                    <div><i class="${iconInfo.icon}" style="background:${iconInfo.bg}; color:white; padding:4px 9px; border-radius:6px; margin-right:8px;"></i><b>${dim.dimension_name}</b></div>
                    <div><b>${formatScoreValue(dim.score)}</b> <small style="color:#988775;">[${dim.weight}]</small> <i class="fa-solid ${isFirst ? 'fa-caret-up' : 'fa-caret-down'}" style="color:#D59B2D; margin-left:8px; font-size:24px;"></i></div>
                </div>
                <div class="accordion-body">
                    <div class="score-box">${featuresHtml}</div>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', itemHtml);
    });
}

// 4. 標籤篩選與報告列表渲染
function filterReport(tabEl, dimensionName) {
    document.querySelectorAll('.tab-pill').forEach(el => el.classList.remove('active'));
    tabEl.classList.add('active');
    renderReportCards(dimensionName);
}

// 分頁固定顯示順序（跟企劃書原本的五維度順序一致）。沒列在這裡的
// 新維度名稱會自動排到最後面，不會噴錯，只是排序不保證跟你預期一致，
// 屆時把新維度名稱加進這個陣列即可。
const DIMENSION_ORDER = ["專案執行力", "價格競爭力", "文案說服力", "影像吸引力", "市場契合度(PMF)", "產品市場契合度", "專案屬性"];

// ── 動態產生「診斷報告」分頁按鈕（View 3）─────────────────────
// 分頁清單直接從 diagnosis_report 實際出現過的 dimension 值取不重複清單，
// 不再假設固定是哪幾個維度，避免卡片被過濾掉找不到分頁可以顯示的情況；
// 取出清單後依 DIMENSION_ORDER 排序，讓分頁順序固定、不受後端回傳陣列順序影響。
function renderFilterTabs(diagnosisReport) {
    const container = document.getElementById('filterTabsContainer');
    if (!container) return;
    container.innerHTML = '';

    let uniqueDimensions = [...new Set(diagnosisReport.map(item => item.dimension))];
    uniqueDimensions.sort((a, b) => {
        const idxA = DIMENSION_ORDER.indexOf(a);
        const idxB = DIMENSION_ORDER.indexOf(b);
        return (idxA === -1 ? 999 : idxA) - (idxB === -1 ? 999 : idxB);
    });

    if (uniqueDimensions.length === 0) {
        renderReportCards(null);
        return;
    }

    uniqueDimensions.forEach((dimName, idx) => {
        const iconInfo = getDimensionIcon(dimName);
        const activeClass = idx === 0 ? 'active' : '';
        const tabHtml = `<div class="tab-pill ${activeClass}" onclick="filterReport(this, '${dimName}')"><i class="${iconInfo.icon}" style="margin-right: 6px;"></i>  ${dimName}</div>`;
        container.insertAdjacentHTML('beforeend', tabHtml);
    });

    renderReportCards(uniqueDimensions[0]);
}

// 將診斷建議畫到網頁上
function renderReportCards(dimensionFilter = null) {
    const container = document.getElementById('reportListContainer');
    if (!container) return;
    container.innerHTML = '';

    const filteredList = dimensionFilter 
        ? currentDiagnosisReport.filter(item => item.dimension === dimensionFilter)
        : currentDiagnosisReport;

    if (filteredList.length === 0) {
        container.innerHTML = `<div style="text-align:center; padding: 30px; color:#8A7865;">在這個維度中，目前沒有需要特別注意的改善建議喔！🎉</div>`;
        return;
    }

    filteredList.forEach(item => {
        let cardClass = 'green', tagClass = 'green', tagText = '請繼續保持';
        if (item.tag_type === 'negative' || item.tag_type === 'red') {
            cardClass = 'red'; tagClass = 'red'; tagText = '建議立即修改';
        } else if (item.tag_type === 'warning' || item.tag_type === 'yellow') {
            cardClass = 'yellow'; tagClass = 'yellow'; tagText = '建議進行優化';
        }

        const cardHtml = `
            <div class="report-box ${cardClass}">
                <div style="margin-bottom:10px;"><span class="tag-pill ${tagClass}">${tagText}</span><b style="font-size:1.05rem;">${item.title}</b></div>
                <div style="font-size:0.9rem; color:#8A7865; margin-bottom:8px;">${item.original_setting}</div>
                <div style="font-size:0.95rem; line-height:1.5;"><b>${item.suggestion}</b></div>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', cardHtml);
    });
}

// 定義雷達圖的 5 大固定軸向
const RADAR_LABELS = ['專案執行力', '價格競爭力', '文案說服力', '影像吸引力', '產品市場契合度'];

// 5. 雷達圖繪製 (Chart.js)
let chartInstance1 = null, chartInstance2 = null;

function renderCharts(radarScores = currentRadarScores) {
    const hasUnanalyzed = radarScores.some(v => v === null || v === undefined);
    const displayScores = radarScores.map(v => (v === null || v === undefined) ? 0 : v);
    const pointStyles = radarScores.map(v => (v === null || v === undefined) ? 'crossRot' : 'circle');

    const chartData = {
        labels: RADAR_LABELS,
        datasets: [{
            data: displayScores,
            backgroundColor: 'rgba(242, 203, 87, 0.5)',
            borderColor: '#f7d200',
            borderWidth: 2,
            pointRadius: 3.5,
            pointStyle: pointStyles,
            pointBackgroundColor: '#ffff'
        }, {
            data: [75, 70, 60, 75, 60],
            backgroundColor: 'rgba(200, 200, 200, 0.2)',
            borderColor: '#a09e9a',
            borderWidth: 1.5,
            pointBackgroundColor: '#a09e9a',
            pointRadius: 1.5
        }]
    };
    const options = { 
        layout: { padding: 10 }, 
        scales: { 
            r: { 
                min: 0, 
                max: 100, 
                ticks: { display: false }, 
                pointLabels: { font: { size: 14 }, color: '#333333', padding: 5 } 
            } 
        }, 
        plugins: { legend: { display: false } } 
    };

    const ctx1 = document.getElementById('previewRadarChart');
    if (ctx1) {
        if (chartInstance1) chartInstance1.destroy();
        chartInstance1 = new Chart(ctx1, { type: 'radar', data: chartData, options: options });
    }

    const ctx2 = document.getElementById('detailRadarChart');
    if (ctx2) {
        if (chartInstance2) chartInstance2.destroy();
        chartInstance2 = new Chart(ctx2, { type: 'radar', data: chartData, options: options });
    }

    const noteEl = document.getElementById('radarUnanalyzedNote');
    if (noteEl) {
        if (hasUnanalyzed) {
            const unanalyzedLabels = RADAR_LABELS.filter((_, i) => radarScores[i] === null || radarScores[i] === undefined);
            noteEl.innerText = `⚠️ 圖上標示 ✕ 的維度（${unanalyzedLabels.join('、')}）目前尚未有足夠資料進行分析，不代表分數低`;
            noteEl.style.display = 'block';
        } else {
            noteEl.style.display = 'none';
        }
    }
}

// 6. 表單送出與 API 串接（非同步輪詢：後端 LLM 分析要跑幾秒到幾十秒，
//    不能一次 fetch 就等到結果，改成先拿 job_id，每隔 2 秒問一次「好了沒」）
// 6. 表單送出與 API 串接
const POLL_INTERVAL_MS = 2000;
const POLL_TIMEOUT_MS = 300000; // 最多等 5 分鐘

let lastTimeoutJobId = null;

async function pollJobResult(jobId, submitBtn) {
    const startTime = Date.now();

    while (Date.now() - startTime < POLL_TIMEOUT_MS) {
        await new Promise(resolve => setTimeout(resolve, POLL_INTERVAL_MS));

        const elapsedSec = Math.round((Date.now() - startTime) / 1000);
        submitBtn.innerText = `AI 診斷運算中...（已等待 ${elapsedSec} 秒）`;

        const statusResponse = await fetch(`http://127.0.0.1:8000/api/v1/diagnose/${jobId}`);
        if (!statusResponse.ok) throw new Error("查詢診斷結果失敗");
        const statusData = await statusResponse.json();

        if (statusData.status === "done") {
            if (!statusData.result) {
                throw new Error("後端回傳診斷已完成，但資料內容為空");
            }
            return statusData.result;
        }
        if (statusData.status === "failed") {
            throw new Error(statusData.error || "診斷過程發生未知錯誤");
        }
    }

    const timeoutError = new Error(`診斷時間較長（超過 ${POLL_TIMEOUT_MS / 1000} 秒），系統仍在背景運算，請稍後重新查詢`);
    timeoutError.jobId = jobId;
    timeoutError.isTimeout = true;
    throw timeoutError;
}

// 讓使用者手動查詢先前逾時、但可能已經跑完的診斷結果
async function checkPreviousJob() {
    if (!lastTimeoutJobId) {
        alert("目前沒有先前逾時的診斷紀錄可以查詢");
        return;
    }
    try {
        const statusResponse = await fetch(`http://127.0.0.1:8000/api/v1/diagnose/${lastTimeoutJobId}`);
        if (!statusResponse.ok) throw new Error("向伺服器查詢失敗");
        const statusData = await statusResponse.json();

        if (statusData.status === "done") {
            if (!statusData.result) {
                alert("該次診斷已結束，但未產出有效結果，請重新送出診斷。");
                lastTimeoutJobId = null;
                return;
            }
            updateUIWithData(statusData.result);
            lastTimeoutJobId = null;
        } else if (statusData.status === "failed") {
            alert(`該次診斷最終失敗：\n${statusData.error || "未知錯誤"}`);
            lastTimeoutJobId = null;
        } else {
            alert("背景仍在運算中（AI 檢索/文案評估中），請稍後再按一次查詢！");
        }
    } catch (error) {
        alert(`查詢失敗：${error.message}`);
    }
}

async function handleFormSubmit(event) {
    event.preventDefault();
    const formEl = document.getElementById('diagnoseForm');
    const formData = new FormData(formEl);
    const submitBtn = formEl.querySelector('button[type="submit"]');

    submitBtn.innerText = "送出診斷請求...";
    submitBtn.disabled = true;

    try {
        const response = await fetch('http://127.0.0.1:8000/api/v1/diagnose', {
            method: 'POST',
            body: formData
        });
        if (!response.ok) throw new Error("API 連線異常");
        const submitData = await response.json();

        if (!submitData.job_id) throw new Error("後端未回傳 job_id");

        submitBtn.innerText = "AI 診斷運算中...";
        const result = await pollJobResult(submitData.job_id, submitBtn);
        updateUIWithData(result);

    } catch (error) {
        console.warn("診斷逾時或失敗:", error);

        if (error.isTimeout && error.jobId) {
            // 逾時：背景可能還在跑，不要用假資料蓋掉畫面，保留現況，
            // 讓使用者知道之後可以透過 checkPreviousJob() 手動查詢真實結果
            lastTimeoutJobId = error.jobId;
            alert(`${error.message}\n\n您可以稍後點擊「查詢先前結果」按鈕查看，不需要重新填表單送出。`);
        } else {
            // 非逾時的其他錯誤（例如 API 連線異常、後端真的回報失敗）才顯示假資料，
            // 讓畫面至少能示範介面長相，同時清楚告知這是展示用範例資料
            alert(`診斷過程發生問題：${error.message}\n（將顯示展示用範例資料）`);
            updateUIWithData({
                success_rate: 80,
                radar_chart_data: { "專案執行力": 85, "價格競爭力": 85, "文案說服力": 85, "影像吸引力": 85, "產品市場契合度": 85 },
                dimensions_evaluation: [],
                diagnosis_report: []
            });
        }
    } finally {
        submitBtn.innerText = "開始診斷 ➔";
        submitBtn.disabled = false;
    }
}

// 7. 更新 UI 與暫存分數
function updateUIWithData(data) {
    // 💡 關鍵防呆：若傳入 null 或非物件，立即中斷，避免崩潰
    if (!data || typeof data !== 'object') {
        console.error("updateUIWithData 收到無效的資料:", data);
        return;
    }

    const previewCard = document.getElementById('resultPreviewCard');
    previewCard.style.display = 'block';

    // 更新總分
    document.getElementById('previewScoreText').innerText = (data.success_rate !== undefined ? data.success_rate : 80) + '%';

    // 依照 5 大維度名稱精確對齊後端欄位，並暫存至全域變數
    if (data.radar_chart_data) {
        currentRadarScores = RADAR_LABELS.map(label => {
            if (data.radar_chart_data[label] !== undefined) return data.radar_chart_data[label];
            if (label === '產品市場契合度' && data.radar_chart_data['市場契合度(PMF)'] !== undefined) {
                return data.radar_chart_data['市場契合度(PMF)'];
            }
            return null;
        });
    } else {
        currentRadarScores = [85, 85, 85, 85, 85];
    }

    // 繪製兩個分頁的雷達圖
    renderCharts(currentRadarScores);

    // 更新手風琴細項評分
    if (data.dimensions_evaluation && data.dimensions_evaluation.length > 0) {
        renderAccordion(data.dimensions_evaluation);
    }

    // 更新診斷報告卡片
    if (data.diagnosis_report) {
        currentDiagnosisReport = data.diagnosis_report;
        let redCount = 0, yellowCount = 0, greenCount = 0;
        
        currentDiagnosisReport.forEach(item => {
            if (item.tag_type === 'negative' || item.tag_type === 'red') redCount++;
            else if (item.tag_type === 'warning' || item.tag_type === 'yellow') yellowCount++;
            else if (item.tag_type === 'positive' || item.tag_type === 'green') greenCount++;
        });

        const sumCards = document.querySelectorAll('.summary-cards-grid .sum-card');
        if (sumCards.length >= 3) {
            sumCards[0].querySelector('.sum-content-row div:nth-child(2)').innerHTML = `${redCount} <small style="font-size:1rem; color:#7A6855;">處</small>`;
            sumCards[1].querySelector('.sum-content-row div:nth-child(2)').innerHTML = `${yellowCount} <small style="font-size:1rem; color:#7A6855;">處</small>`;
            sumCards[2].querySelector('.sum-content-row div:nth-child(2)').innerHTML = `${greenCount} <small style="font-size:1rem; color:#7A6855;">處</small>`;
        }

        renderFilterTabs(currentDiagnosisReport);
    }

    previewCard.scrollIntoView({ behavior: 'smooth' });
}

window.onload = () => { renderCharts([null, null, null, null, null]); };

// PDF 下載功能
function downloadFullPagePDF() {
    switchView('report', 3);

    // 讓瀏覽器有機會完成排版（display:none → block 需要一個 render tick），
    // 不加這個延遲，html2canvas 有機率還是抓到切換前的狀態
    setTimeout(() => {
        const element = document.getElementById('view-report');
        const opt = { 
            margin: 10, 
            filename: `募資診斷報告_${new Date().toISOString().split("T")[0]}.pdf`,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true, scrollY: 0 },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait', compress: true },
            pagebreak: { mode: ["avoid-all", "css", "legacy"] }
        };
        html2pdf().set(opt).from(element).save();
    }, 150);
}