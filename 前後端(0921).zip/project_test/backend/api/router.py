# 檔案位置：backend/api/router.py
import tempfile
import shutil
import os
import pandas as pd
import traceback
from fastapi import APIRouter, File, UploadFile, Form, HTTPException
from typing import List, Optional

from models.schemas import DiagnosisResponse, JobSubmittedResponse, JobStatusResponse
from services.extractor import build_sync_features, run_llm_analysis
from services.ml_service import MLService
from services.job_manager import submit_job, get_job

router = APIRouter()
ml_service = MLService()  # 啟動時自動載入模型

@router.post("/api/v1/diagnose", response_model=JobSubmittedResponse)
async def run_diagnosis(
    project_type: str = Form(...),
    category: str = Form(...),
    funding_days: int = Form(...),
    target_amount: int = Form(...),
    price_tiers: int = Form(...),
    prices: List[str] = Form(...),
    content_file: Optional[UploadFile] = File(None),
    media_files: Optional[List[UploadFile]] = File(None),
    faq_file: Optional[UploadFile] = File(None)
):
    try:
        if not ml_service.is_ready:
            from main import get_mock_response
            job_id = submit_job(lambda: get_mock_response())
            return {"job_id": job_id, "status": "processing"}

        # 1. 取得同步特徵
        feature_dict, content_text, extraction_info = await build_sync_features(
            project_type, category, funding_days, target_amount, price_tiers, prices,
            content_file, media_files, faq_file, ml_service.all_features
        )
        if extraction_info.get("warnings"):
            print(f"[診斷警告] {extraction_info['warnings']}")

        # 2. 🚨 安全儲存影片檔至本機暫存區 (避免 Request 結束後 FastAPI 將檔案關閉)
        temp_dir = tempfile.mkdtemp()
        video_paths = []
        if media_files:
            for f in media_files:
                if f.filename and f.filename.lower().endswith(('.mp4', '.mov', '.avi', '.webm')):
                    temp_path = os.path.join(temp_dir, f.filename)
                    await f.seek(0)  # 重要！因前面讀過一次，必須歸零指標
                    with open(temp_path, "wb") as buffer:
                        shutil.copyfileobj(f.file, buffer)
                    video_paths.append(temp_path)

        def _full_pipeline():
            try:
                print("🚀 背景工作開始：執行 LLM 分析與價格檢索...", flush=True)
                # 直接傳入暫存磁碟中的 video_paths
                final_features = run_llm_analysis(
                    feature_dict, content_text, video_paths, category, ml_service.all_features
                )
                
                df_input = pd.DataFrame([final_features])[ml_service.all_features]
                
                print("🧠 背景工作：執行 XGBoost & SHAP 評分...", flush=True)
                result = ml_service.predict_and_format(df_input)
                print("✅ 背景工作完成，結果已生成！", flush=True)
                
                # 執行完畢後自動清理影片暫存檔
                shutil.rmtree(temp_dir, ignore_errors=True)
                return result
                
            except Exception as e:
                shutil.rmtree(temp_dir, ignore_errors=True)
                print(f"❌ 背景工作發生錯誤:\n{traceback.format_exc()}", flush=True)
                raise e

        job_id = submit_job(_full_pipeline)
        return {"job_id": job_id, "status": "processing"}

    except Exception as e:
        # 🚨 印出同步錯誤的追蹤訊息，不再只給冷冰冰的 500
        print(f"❌ 接收請求時發生同步錯誤:\n{traceback.format_exc()}", flush=True)
        raise HTTPException(status_code=500, detail=f"診斷過程發生錯誤: {str(e)}")

@router.get("/api/v1/diagnose/{job_id}", response_model=JobStatusResponse)
async def get_diagnosis_result(job_id: str):
    job = get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="找不到這個工作 ID，可能已過期或伺服器重啟過")
    return job