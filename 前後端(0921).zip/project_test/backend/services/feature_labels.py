# 檔案位置：backend/services/feature_labels.py
# 英文特徵名稱 -> 中文顯示名稱、以及「哪個特徵屬於哪個維度」的查找工具。

FEATURE_LABELS: dict[str, str] = {
    # 1. 專案執行力
    "funding_duration_days": "募資天數",
    "target_amount": "目標金額",

    # 2. 價格競爭力
    "market_price_min": "市場同類商品最低價",
    "market_price_max": "市場同類商品最高價",
    "price_deviation_ratio": "定價偏離市場比例",
    "is_price_competitive": "定價是否具競爭力",
    "needs_manual_review": "定價需人工複核",
    "market_data_quality_high": "市場資料品質(高)",
    "innovation_label_is_innovative": "是否具創新標籤",
    "reward_tier_count": "回饋方案層數",
    "reward_price_min": "回饋方案最低金額",
    "reward_price_max": "回饋方案最高金額",
    "reward_price_mean": "回饋方案平均金額",
    "reward_price_median": "回饋方案金額中位數",

    # 3. 文案說服力
    "feat_text_story_ratio": "文案故事比例",
    "feat_text_spec_ratio_rule": "文案規格字詞比例(規則)",
    "feat_text_risk_ratio": "文案風險提示字詞比例",
    "feat_has_social_link": "文案是否附社群連結",
    "feat_punct_intensity": "文案標點符號強度",
    "feat_avg_sentence_len": "文案平均句長",
    "feat_type_token_ratio": "詞彙豐富度",
    "feat_trust_score": "文案信任感評分",
    "feat_emotional_ratio": "文案情感字詞比例",
    "feat_spec_ratio": "文案規格詞比例",
    "feat_emotional_word_count": "情感字詞數量",
    "feat_spec_word_count": "規格字詞數量",
    "faq_total_count": "FAQ總題數",
    "faq_update_frequency": "FAQ更新頻率",
    "img_word_count": "圖文總字數",

    # 4. 影像吸引力
    "videos_included": "納入分析影片數",
    "videos_excluded_low_coverage": "低覆蓋率排除影片數",
    "total_video_duration": "總影片時長",
    "primary_usage_scene_soft_ratio": "首支影片情境比例",
    "primary_gemini_avg_score": "首支影片AI評分",
    "mean_usage_scene_soft_ratio": "平均影片情境比例",
    "max_usage_scene_soft_ratio": "最大影片情境比例",
    "mean_gemini_avg_score": "平均影片AI評分",
    "duration_weighted_usage_scene_ratio": "時長加權情境比例",
    "img_image_count": "專案圖片數量",
    "img_video_count": "專案影片數量",
    "media_per_100_words": "每百字媒體數",

    # 5. 市場契合度 (PMF)
    "pmf_a_recent_category_success_rate": "近期同類達標率",
    "pmf_b_trend_level": "Google 趨勢斜率",
    "pmf_c_hit_similarity": "命中相似度",
    "pmf_d_market_saturation_count": "市場飽和度計數",

    # 6. 專案屬性（類別 one-hot）
    "category_出版": "類別：出版",
    "category_教育": "類別：教育",
    "category_時尚": "類別：時尚",
    "category_社會": "類別：社會",
    "category_科技": "類別：科技",
    "category_設計": "類別：設計",
    "category_遊戲": "類別：遊戲",
    "category_飲食": "類別：飲食",

    # 6. 專案屬性（平台 one-hot）
    "platform_群眾募資": "募資模式：群眾募資",
    "platform_預購式專案": "募資模式：預購式專案",
}

def get_feature_label(feature_name: str) -> str:
    """查不到對照表就直接回傳原始英文名稱"""
    return FEATURE_LABELS.get(feature_name, feature_name)

def get_dimension_for_feature(feature_name: str, dimension_map: dict) -> str:
    """反查特徵屬於哪個維度"""
    for dim, feats in dimension_map.items():
        if feature_name in feats:
            return dim.split(". ", 1)[-1]
    return "自動診斷"