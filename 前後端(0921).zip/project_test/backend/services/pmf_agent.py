# backend/services/pmf_agent.py
import sqlite3
import os
from pytrends.request import TrendReq

class PMFAgent:
    """負責處理 5. 市場契合度 PMF"""
    
    def __init__(self, db_path: str = "zeczec_history.db"):
        self.db_path = db_path
        self.pytrends = TrendReq(hl='zh-TW', tz=-480)

    def analyze(self, category: str, product_keyword: str) -> dict:
        results = {
            "pmf_a_recent_category_success_rate": 0.0,
            "pmf_d_market_saturation_count": 0,
            "pmf_b_trend_level": 0.0,
            "pmf_c_hit_similarity": 0.5 # 預設中位數
        }
        
        # 1. 查詢 SQLite 歷史資料庫
        if os.path.exists(self.db_path):
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT 募資狀態 FROM projects_summary WHERE 次分類=?", (category,))
            rows = cursor.fetchall()
            conn.close()
            
            if rows:
                success_count = sum(1 for r in rows if r[0] == '成功')
                results["pmf_a_recent_category_success_rate"] = round(success_count / len(rows), 4)
                results["pmf_d_market_saturation_count"] = len(rows)

        # 2. 查詢 Google Trends 斜率
        if product_keyword and product_keyword != "未分類商品":
            try:
                self.pytrends.build_payload([product_keyword], cat=0, timeframe='today 3-m', geo='TW')
                df = self.pytrends.interest_over_time()
                if not df.empty:
                    y = df[product_keyword].values
                    x = list(range(len(y)))
                    slope, _ = np.polyfit(x, y, 1)
                    results["pmf_b_trend_level"] = round(slope, 4)
            except:
                pass # 忽略 Pytrends 阻擋錯誤

        return results