# 從組員的 text_feature_llm.py 移植過來的 CopywritingAgent，只保留
# analyze() 這個單筆分析方法，拿掉批次掃資料夾/寫 CSV 的部分（那些是
# 當初產生訓練資料用的，即時服務不需要）。
#
# 對應模型特徵：feat_emotional_ratio
#
# ⚠️ 這支要打 Gemini API，單次呼叫通常需要幾秒鐘，不適合放進同步的
# HTTP request/response 週期裡——放進 job_manager.py 的背景工作執行。

import os
import json
from typing import Optional, Dict, Any


class CopywritingAgent:
    """募資風險診斷系統 - 文案語意分析 Agent"""

    SYSTEM_PROMPT = """你現在是募資風險診斷系統中的核心 AI 顧問：「文案語意分析 Agent」。
你的任務是精準剖析這篇募資文案的說服力、情感渲染力與信任建立機制。

請分析給定文本，並嚴格回傳包含以下 6 個欄位的 JSON：

1. "feat_emotional_ratio": 浮點數 (0.0~1.0)，評估「情感性、品牌初衷、渲染性」詞語佔整體的比例。
2. "feat_spec_ratio": 浮點數 (0.0~1.0)，評估「規格性、技術性、客觀描述」詞語的比例。
3. "feat_trust_score": 整數 (0~100)，評估這篇文案建立贊助者信任感的能力（是否誠懇、有無揭露風險、是否有具體保證）。
4. "emotional_words": 字串陣列，列出你提煉的代表性「感情/渲染字詞」(最多 5 個)。
5. "spec_words": 字串陣列，列出你提煉的代表性「規格/技術字詞」(最多 5 個)。
6. "agent_advice": 字串，以資深行銷顧問的語氣，給予提案團隊一句話的文案修改建議（字數限 50 字以內）。

請確保輸出格式為純 JSON。"""

    def __init__(self, api_key: Optional[str] = None):
        import google.generativeai as genai

        key = api_key or os.environ.get("GEMINI_API_KEY", "")
        if not key:
            raise ValueError("找不到 Gemini API 金鑰，請設定環境變數 GEMINI_API_KEY")
        genai.configure(api_key=key)

        self._genai = genai
        self.model = genai.GenerativeModel(
            model_name=os.environ.get("GEMINI_MODEL_OVERRIDE", "gemini-flash-latest"),
            system_instruction=self.SYSTEM_PROMPT,
            generation_config={"response_mime_type": "application/json"},
        )

    def analyze(self, text: str, max_chars: int = 6000) -> Dict[str, Any]:
        """單筆同步呼叫，回傳 dict。呼叫端請用 job_manager 放進背景工作，
        不要直接在 FastAPI route handler 裡同步呼叫（會卡住整個 request）。"""
        truncated = text[:max_chars] if len(text) > max_chars else text
        try:
            response = self.model.generate_content(f"請診斷以下募資文案：\n\n{truncated}")
            result = json.loads(response.text.strip())
            
            emo_words = result.get("emotional_words", [])
            spec_words = result.get("spec_words", [])
            
            return {
                "feat_emotional_ratio": round(float(result.get("feat_emotional_ratio", -1.0)), 4),
                "feat_spec_ratio": round(float(result.get("feat_spec_ratio", -1.0)), 4),
                "feat_trust_score": int(result.get("feat_trust_score", 0)),
                "extracted_emotional_words": ", ".join(emo_words) if emo_words else "無",
                "extracted_spec_words": ", ".join(spec_words) if spec_words else "無",
                "agent_advice": result.get("agent_advice", ""),
                "success": True,
            }
        except Exception as e:
            # 發生錯誤時回傳 -1 哨兵值
            return {"feat_emotional_ratio": -1.0, "feat_spec_ratio": -1.0, "success": False, "error": str(e)}