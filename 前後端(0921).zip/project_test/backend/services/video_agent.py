# backend/services/video_agent.py
import cv2
import numpy as np
import json
import os
import google.generativeai as genai

class VideoAgent:
    """負責處理 4. 影像吸引力 (基於 Source 37 的兩階段架構)"""
    
    GEMINI_BATCH_PROMPT = """你是產品短影音的畫面審核員。以下依序提供 {n} 張影片截圖。
請針對「每一張」各自評估其呈現「產品實際使用情境」的程度(0-100)。
請只回答一個 JSON 陣列，例如：[80, 0, 45]，不可有其他文字。"""

    def __init__(self, api_key: str):
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-1.5-flash')

    def analyze_videos(self, video_paths: list) -> dict:
        if not video_paths:
            return self._empty_result()
            
        results = []
        for path in video_paths:
            frames, duration = self._sample_frames(path, interval_sec=2.0)
            candidates = self._cv_rule_filter(frames)
            scores = self._gemini_batch_score(candidates)
            
            if scores:
                ratio = sum(1 for s in scores if s >= 50) / len(frames) if frames else 0
                soft_ratio = (sum(scores)/100.0) / len(frames) if frames else 0
                avg_score = sum(scores) / len(scores)
                results.append((duration, ratio, soft_ratio, avg_score))

        if not results:
            return self._empty_result()

        durations = [r[0] for r in results]
        ratios = [r[1] for r in results]
        soft_ratios = [r[2] for r in results]
        avg_scores = [r[3] for r in results]
        
        total_dur = sum(durations)
        weighted_ratio = sum(r * d for r, d in zip(ratios, durations)) / total_dur if total_dur else 0

        # 對應 PDF 要求的欄位
        return {
            "videos_included": len(results),
            "videos_excluded_low_coverage": len(video_paths) - len(results),
            "total_video_duration": round(total_dur, 2),
            "primary_usage_scene_soft_ratio": round(soft_ratios[0], 4),
            "primary_gemini_avg_score": round(avg_scores[0], 2),
            "mean_usage_scene_soft_ratio": round(sum(soft_ratios)/len(soft_ratios), 4),
            "max_usage_scene_soft_ratio": round(max(soft_ratios), 4),
            "mean_gemini_avg_score": round(sum(avg_scores)/len(avg_scores), 2),
            "duration_weighted_usage_scene_ratio": round(weighted_ratio, 4)
        }

    def _sample_frames(self, path: str, interval_sec: float):
        cap = cv2.VideoCapture(path)
        fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        step = max(1, int(fps * interval_sec))
        frames, idx = [], 0
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret: break
            if idx % step == 0: frames.append(frame)
            idx += 1
        cap.release()
        return frames, total_frames / fps if fps else 0

    def _cv_rule_filter(self, frames: list):
        candidates = []
        last_gray = None
        for frame in frames:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            mean_b = gray.mean()
            if not (10 < mean_b < 245): continue
            
            edges = cv2.Canny(gray, 50, 150)
            if np.count_nonzero(edges) / edges.size < 0.03: continue
            
            if last_gray is not None and cv2.absdiff(gray, last_gray).mean() < 8.0: continue
            
            last_gray = gray
            candidates.append(frame)
        return candidates

    def _gemini_batch_score(self, candidates: list):
        if not candidates: return []
        try:
            from PIL import Image
            contents = [self.GEMINI_BATCH_PROMPT.format(n=len(candidates))]
            for f in candidates:
                contents.append(Image.fromarray(cv2.cvtColor(f, cv2.COLOR_BGR2RGB)))
            resp = self.model.generate_content(contents)
            import re
            m = re.search(r'\[.*?\]', resp.text, flags=re.DOTALL)
            return json.loads(m.group()) if m else []
        except:
            return []

    def _empty_result(self):
        return {
            "videos_included": 0, "videos_excluded_low_coverage": 0, "total_video_duration": 0,
            "primary_usage_scene_soft_ratio": 0, "primary_gemini_avg_score": 0,
            "mean_usage_scene_soft_ratio": 0, "max_usage_scene_soft_ratio": 0,
            "mean_gemini_avg_score": 0, "duration_weighted_usage_scene_ratio": 0
        }