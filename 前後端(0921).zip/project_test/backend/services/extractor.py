# 負責將前端表單與上傳檔案轉換成模型需要的特徵。
#
# 這次拆成兩個函式：
#   build_sync_features()  — 立刻能算完的部分（表單數值 + RuleBasedExtractor），
#                             毫秒等級，直接在 request handler 裡呼叫。
#   run_llm_analysis()     — 需要打 Gemini/比價的部分，丟進 job_manager 背景執行，
#                             完成後把結果併回特徵列，才真正呼叫模型預測。

import os
import numpy as np
import pandas as pd

from services.file_reader import extract_text_from_content_file, extract_faq_items, get_media_file_info
from services.text_features import RuleBasedExtractor

_rule_extractor = RuleBasedExtractor()

async def build_sync_features(
    project_type: str, category: str, funding_days: int, target_amount: int,
    price_tiers: int, prices: list,
    content_file, media_files, faq_file, expected_features: list,
) -> tuple[dict, str, dict]:
    warnings: list[str] = []

    prices_float = []
    for p in prices:
        try:
            prices_float.append(float(p.strip()))
        except (ValueError, AttributeError):
            continue

    feature_dict = {f: np.nan for f in expected_features}
    feature_dict['funding_duration_days'] = funding_days
    feature_dict['target_amount'] = target_amount
    feature_dict['reward_tier_count'] = price_tiers
    feature_dict['reward_price_min'] = min(prices_float) if prices_float else np.nan
    feature_dict['reward_price_max'] = max(prices_float) if prices_float else np.nan
    feature_dict['reward_price_median'] = float(np.median(prices_float)) if prices_float else np.nan

    cat_col = f"category_{category}"
    if cat_col in expected_features:
        feature_dict[cat_col] = 1
    else:
        warnings.append(f"類別「{category}」不在模型已知類別清單中，未納入評分")

    plat_col = f"platform_{project_type}"
    if plat_col in expected_features:
        feature_dict[plat_col] = 1
    else:
        warnings.append(f"募資模式「{project_type}」不在模型已知清單中，未納入評分")

    content_text, content_warnings = await extract_text_from_content_file(content_file)
    faq_items, faq_warnings = await extract_faq_items(faq_file)
    media_info = await get_media_file_info(media_files)
    warnings += content_warnings + faq_warnings

    if content_text:
        rule_result = _rule_extractor.extract(content_text)
        if rule_result:
            for key, value in rule_result.items():
                if key in expected_features:
                    feature_dict[key] = value
    else:
        warnings.append("未提供文案內容或無法解析，規則式文案特徵暫時無法計算")

    # PDF 基礎統計特徵
    if "faq_total_count" in expected_features:
        feature_dict["faq_total_count"] = len(faq_items)
        
    if "faq_update_frequency" in expected_features:
        feature_dict["faq_update_frequency"] = 0.0

    img_count = media_info.get("image_count", 0)
    vid_count = media_info.get("video_count", 0)
    word_count = len(content_text) if content_text else 0
    
    if "img_word_count" in expected_features:
        feature_dict["img_word_count"] = word_count
    if "img_image_count" in expected_features:
        feature_dict["img_image_count"] = img_count
    if "img_video_count" in expected_features:
        feature_dict["img_video_count"] = vid_count
        
    if "media_per_100_words" in expected_features:
        if word_count > 0:
            feature_dict["media_per_100_words"] = round(((img_count + vid_count) / word_count) * 100, 4)
        else:
            feature_dict["media_per_100_words"] = np.nan

    extraction_info = {
        "content_text_length": word_count,
        "faq_item_count": len(faq_items),
        "media_info": media_info,
        "warnings": warnings,
    }
    return feature_dict, content_text, extraction_info

# 🚨 注意這裡的傳入參數已更新：加入了 video_paths 與 category
def run_llm_analysis(feature_dict: dict, content_text: str, video_paths: list, category: str, expected_features: list) -> dict:
    updated = dict(feature_dict)
    api_key = os.environ.get("GEMINI_API_KEY", "")

    # 1. 呼叫文案 Agent
    if content_text:
        try:
            from services.copywriting_agent import CopywritingAgent
            agent = CopywritingAgent()
            result = agent.analyze(content_text)
            
            if result.get("success"):
                emo_ratio = result.get('feat_emotional_ratio', -1.0)
                updated['feat_emotional_ratio'] = np.nan if emo_ratio == -1.0 else emo_ratio
                
                spec_ratio = result.get('feat_spec_ratio', -1.0)
                updated['feat_spec_ratio'] = np.nan if spec_ratio == -1.0 else spec_ratio
                
                if 'feat_trust_score' in expected_features:
                    updated['feat_trust_score'] = result.get('feat_trust_score')
                
                emo_words = result.get("extracted_emotional_words", "")
                updated['feat_emotional_word_count'] = 0 if emo_words in ["無", "錯誤", ""] else len(emo_words.split(","))
                
                spec_words = result.get("extracted_spec_words", "")
                updated['feat_spec_word_count'] = 0 if spec_words in ["無", "錯誤", ""] else len(spec_words.split(","))
        except Exception as e:
            print(f"[CopywritingAgent 失敗] {e}")

    # 2. 呼叫市場價 Agent
    keyword = "未分類商品"
    if content_text:
        try:
            from google import genai
            client = genai.Client(api_key=api_key)
            from services.market_price_agent import MarketPriceAgent
            price_agent = MarketPriceAgent(client=client, content_text=content_text)
            price_result = price_agent.analyze(content_text)
            keyword = price_result.get("product_keyword", "未分類商品")
            
            mapping = {
                "market_price_min": price_result.get("market_price_min"),
                "market_price_max": price_result.get("market_price_max"),
                "price_deviation_ratio": price_result.get("price_deviation_ratio"),
                "is_price_competitive": price_result.get("is_price_competitive"),
                "needs_manual_review": price_result.get("needs_manual_review"),
                "market_data_quality_high": 1 if price_result.get("market_data_quality") == "high" else 0,
                "innovation_label_is_innovative": int(bool(price_result.get("is_innovative_product"))),
            }
            for k, v in mapping.items():
                if k in expected_features and v is not None:
                    updated[k] = v
        except Exception as e:
            print(f"[MarketPriceAgent 失敗] {e}")

    # 3. 呼叫 PMF Agent
    try:
        from services.pmf_agent import PMFAgent
        pmf = PMFAgent()
        pmf_results = pmf.analyze(category, keyword)
        for k, v in pmf_results.items():
            if k in expected_features:
                updated[k] = v
    except Exception as e:
        print(f"[PMFAgent 失敗] {e}")

    # 4. 呼叫 Video Agent
    if video_paths:
        try:
            from services.video_agent import VideoAgent
            v_agent = VideoAgent(api_key=api_key)
            v_results = v_agent.analyze_videos(video_paths)
            
            for k, v in v_results.items():
                if k in expected_features:
                    updated[k] = v
        except Exception as e:
            print(f"[VideoAgent 失敗] {e}")
    else:
        # 如果使用者沒有上傳任何影片，手動把影片相關特徵設為 0
        video_feats = [
            "videos_included", "videos_excluded_low_coverage", "total_video_duration",
            "primary_usage_scene_soft_ratio", "primary_gemini_avg_score",
            "mean_usage_scene_soft_ratio", "max_usage_scene_soft_ratio",
            "mean_gemini_avg_score", "duration_weighted_usage_scene_ratio"
        ]
        for f in video_feats:
            if f in expected_features:
                updated[f] = 0.0

    return updated