// 全局暫存後端傳回來的報告資料，方便標籤切換時重新渲染
let currentDiagnosisReport = [];
let currentRadarScores = [null, null, null, null, null];
let currentSuccessRate = null;
let currentDimensions = [];
let currentProjectInfo = null;

// 1. 導覽切換
function switchView(viewId, navIndex) {
    document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
    document.getElementById('view-' + viewId).classList.add('active');

    document.querySelectorAll('.nav-item').forEach((el, idx) => {
        if (idx === navIndex) el.classList.add('active');
        else el.classList.remove('active');
    });
    
    // 💡 切換分頁時，帶入全域保存的真實分數重繪圖表
    if (viewId === 'scores' || viewId === 'form') {
        renderCharts(currentRadarScores);
    }
}

// 2. 檔名更新
// ── 已選檔案清單（跨多次選擇累積）──────────────────────────────
let selectedFiles = [];

function _fileKey(f) { return `${f.name}|${f.size}|${f.lastModified}`; }

function handleFilesSelection(input) {
    const existing = new Set(selectedFiles.map(_fileKey));
    Array.from(input.files || []).forEach(f => {
        const k = _fileKey(f);
        if (existing.has(k)) return;      // 重複的檔案略過
        existing.add(k);
        selectedFiles.push(f);
    });
    input.value = '';                      // 清空 input，同一個檔案之後仍可再選
    renderFilePreview();
}

function removeSelectedFile(index) {
    selectedFiles.splice(index, 1);
    renderFilePreview();
}

function clearAllFiles() {
    if (selectedFiles.length === 0) return;
    if (!confirm(`確定要刪除全部 ${selectedFiles.length} 個已選檔案嗎？`)) return;
    selectedFiles = [];
    renderFilePreview();
}

function renderFilePreview() {
    const container = document.getElementById('filePreviewContainer');
    const clearBtn = document.getElementById('clearAllFilesBtn');
    const countText = document.getElementById('fileCountText');
    container.innerHTML = '';

    if (selectedFiles.length === 0) {
        container.innerHTML = '<span style="color:#B0A99A; font-size:13px; margin:auto;">尚未選擇檔案</span>';
        if (clearBtn) clearBtn.style.display = 'none';
        if (countText) countText.innerText = '';
        return;
    }

    if (clearBtn) clearBtn.style.display = 'inline-flex';
    if (countText) countText.innerText = `已選 ${selectedFiles.length} 個檔案`;

    selectedFiles.forEach((file, index) => {
        const ext = file.name.split('.').pop().toLowerCase();
        let iconClass = "fa-file";
        let color = "#8A7865";
        if (['pdf'].includes(ext)) { iconClass = "fa-file-pdf"; color = "#EE6A62"; }
        else if (['doc', 'docx'].includes(ext)) { iconClass = "fa-file-word"; color = "#4A90E2"; }
        else if (['txt'].includes(ext)) { iconClass = "fa-file-lines"; color = "#F1B53D"; }
        else if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) { iconClass = "fa-file-image"; color = "#53BF82"; }
        else if (['mp4', 'mov', 'avi', 'webm'].includes(ext)) { iconClass = "fa-file-video"; color = "#cc88ee"; }

        const thumb = document.createElement('div');
        thumb.style.cssText = "display:flex; align-items:center; gap:6px; padding:6px 10px 6px 12px; background:white; border-radius:8px; font-size:12px; font-weight:bold; box-shadow:0 1px 3px rgba(0,0,0,0.1); border:1px solid #EADDBF;";
        thumb.innerHTML = `
            <i class="fa-solid ${iconClass}" style="color:${color}; font-size:16px;"></i>
            <span style="max-width:90px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${_escapeHtml(file.name)}">${_escapeHtml(file.name)}</span>
            <button type="button" class="file-remove-btn" onclick="removeSelectedFile(${index})" title="移除這個檔案">
                <i class="fa-solid fa-xmark"></i>
            </button>`;
        container.appendChild(thumb);
    });
}

// ── 套用上次填寫資料 ─────────────────────────────────────────
// 存在瀏覽器的 localStorage（只存在這台電腦、這個瀏覽器裡，換瀏覽器
// 或清快取就會不見）。目前只存「表單欄位」，檔案（文案/FAQ/圖片影片）
// 基於瀏覽器安全限制，沒辦法用程式重新塞回 <input type="file">，
// 使用者套用後仍需自己重新選一次檔案。
const LAST_FORM_STORAGE_KEY = 'zeczec_last_form_input';

function saveFormInputToStorage(formEl) {
    
    currentProjectInfo = {
    project_type: formEl.project_type.value,
    category: formEl.category.value,
    funding_days: formEl.funding_days.value,
    target_amount: formEl.target_amount.value,
    prices: Array.from(document.querySelectorAll('input[name="prices"]')).map(el => el.value),
    };

    try {
        const prices = Array.from(document.querySelectorAll('input[name="prices"]')).map(el => el.value);
        const data = {
            project_type: formEl.project_type.value,
            category: formEl.category.value,
            funding_days: formEl.funding_days.value,
            target_amount: formEl.target_amount.value,
            price_tiers: formEl.price_tiers.value,
            prices: prices,
        };
        localStorage.setItem(LAST_FORM_STORAGE_KEY, JSON.stringify(data));

        const fillBtn = document.getElementById('fillLastInputBtn');
        if (fillBtn) fillBtn.style.display = 'inline-flex';
    } catch (e) {
        // localStorage 在部分環境（例如無痕模式容量用盡）可能會丟例外，
        // 存失敗不該擋住正常的診斷流程，印個警告就好
        console.warn('儲存上次輸入資料失敗：', e);
    }
}

function fillLastFormInput() {
    let data;
    try {
        const raw = localStorage.getItem(LAST_FORM_STORAGE_KEY);
        if (!raw) {
            alert('目前沒有先前填寫過的資料可以套用');
            return;
        }
        data = JSON.parse(raw);
    } catch (e) {
        alert('讀取先前資料失敗，資料可能已經損毀');
        return;
    }

    const formEl = document.getElementById('diagnoseForm');
    if (!formEl) return;

    if (data.project_type) formEl.project_type.value = data.project_type;
    if (data.category) formEl.category.value = data.category;
    if (data.funding_days) formEl.funding_days.value = data.funding_days;
    if (data.target_amount) formEl.target_amount.value = data.target_amount;

    if (data.price_tiers) {
        formEl.price_tiers.value = data.price_tiers;
        generatePriceFields(); // 先依照上次的層數重新產生對應數量的價格輸入框，再回填數值
    }

    if (Array.isArray(data.prices)) {
        const priceInputs = document.querySelectorAll('input[name="prices"]');
        data.prices.forEach((val, i) => {
            if (priceInputs[i]) priceInputs[i].value = val;
        });
    }

    alert('已套用上次填寫的基本資料！檔案（文案/FAQ/圖片影片）基於瀏覽器安全限制無法自動帶入，請重新選擇檔案。');
    validatePriceFields();
}

// 動態產生各層價格輸入框
function generatePriceFields() {
    const tiersInput = document.getElementById('priceTiersInput');
    const container = document.getElementById('priceFieldsContainer');
    if (!tiersInput || !container) return;

    let count = parseInt(tiersInput.value, 10);
    if (isNaN(count) || count < 1) count = 1;
    // 💡 修改點：限制最多 6 層
    if (count > 6) {
        count = 6;
        tiersInput.value = 6;
    }

    const chineseNumbers = ['一', '二', '三', '四', '五', '六'];
    container.innerHTML = '';

    for (let i = 0; i < count; i++) {
        const inputEl = document.createElement('input');
        inputEl.type = 'number';
        inputEl.className = 'form-input';
        inputEl.name = 'prices';
        
        // 💡 賦予防呆屬性
        inputEl.required = true; 
        inputEl.min = "1";
        inputEl.oninput = function() {
            if (this.value !== '' && this.value < 1) this.value = '';
        };

        const numStr = chineseNumbers[i] || (i + 1);
        inputEl.placeholder = `第${numStr}層如：${(i + 1) * 2000 + 1000}`;
        inputEl.style.flex = '1';
        inputEl.style.minWidth = '130px';

        container.appendChild(inputEl);
    }

    validatePriceFields(); 
}

// 3. 手風琴選單
function toggleAccordion(headerEl) {
    const item = headerEl.parentElement;
    item.classList.toggle('open');
    const icon = headerEl.querySelector('.fa-caret-up, .fa-caret-down');
    icon.className = item.classList.contains('open') ? "fa-solid fa-caret-up" : "fa-solid fa-caret-down";
}

// ── 維度圖示對照表 ──────────────────────────────────────────
// 已知維度名稱先配好圖示跟顏色，維持原本設計的視覺風格；
// 遇到表裡沒列出的新維度名稱（例如模型之後把某個維度重新加回來、
// 或調整了名稱），會自動套用 DEFAULT_ICON，畫面不會壞掉。
const DIMENSION_ICON_MAP = {
    "專案執行力":      { icon: "fa-regular fa-flag",        bg: "#f8c33c" },
    "價格競爭力":      { icon: "fa-solid fa-dollar-sign",   bg: "#ffa73a" },
    "文案說服力":      { icon: "fa-regular fa-file-lines",  bg: "rgb(110, 155, 239)" },
    "影像吸引力":      { icon: "fa-solid fa-video",         bg: "#cc88ee" },
    "市場契合度(PMF)": { icon: "fa-solid fa-magnet",        bg: "#68ccc9" },
    "產品市場契合度":  { icon: "fa-solid fa-magnet",        bg: "#68ccc9" },
    "專案屬性":        { icon: "fa-solid fa-shield-halved", bg: "#8a8ad1" },
};
const DEFAULT_ICON = { icon: "fa-solid fa-circle-info", bg: "#a09e9a" };

function getDimensionIcon(dimensionName) {
    return DIMENSION_ICON_MAP[dimensionName] || DEFAULT_ICON;
}

// ── 細項分數說明文字 ──────────────────────────────────────────
// key 必須跟後端 feature_labels.py 裡 FEATURE_LABELS 的「中文顯示名稱」
// 一模一樣（dimensions_evaluation 裡的 feature_name 已經是翻譯過的中文），
// 滑鼠移到細項旁邊的「?」就會顯示這裡的說明。
// 找不到對照的新欄位不會噴錯，只是不會顯示「?」圖示而已，
// 之後模型新增特徵時，在這裡補一筆說明即可，不用動 renderAccordion()。
const FEATURE_DESCRIPTIONS = {
    // 1. 專案執行力
    "募資天數": "您設定的募資天數，是跟同類型、且曾經成功達標的歷史專案相比較後才給出這個分數。天數太短，行銷聲量可能還沒發酵就結束；天數太長，則容易讓支持者失去急迫感、觀望不下單，兩種情況都可能拉低這項分數。",
    "目標金額": "您設定的目標金額，是跟同類型、且曾經成功達標的歷史專案相比較後才給出這個分數。目標訂太高，會讓專案一開始就顯得遙不可及、不容易衝出早期動能；訂太低，又可能讓人懷疑你的成本有沒有算清楚，兩者都會影響這項分數。",

    // 2. 價格競爭力
    "市場同類商品最低價": "AI 幫你在蝦皮、momo、PChome 等平台搜尋同類商品後，找到的市場最低參考售價，用來當作判斷你定價是否合理的下界依據。",
    "市場同類商品最高價": "AI 幫你在蝦皮、momo、PChome 等平台搜尋同類商品後，找到的市場最高參考售價，用來當作判斷你定價是否合理的上界依據。",
    "定價偏離市場比例": "您的核心售價跟 AI 查到的市場行情中位數相比，偏離了多少百分比。不管偏高或偏低，偏離幅度越大，越可能讓贊助者對你的定價產生疑慮，這項分數也會因此被拉低。",
    "定價是否具競爭力": "判斷您的核心售價是否落在 AI 查到的「市場最低價～最高價」區間內。落在區間內代表價格跟市面上同類商品算是同一個水準，比較不容易讓人覺得買貴或懷疑品質。",
    "定價需人工複核": "當核心售價跟市場行情差距過大、AI 比對到的真實商品樣本數太少，或您的商品被判定為市場上找不到直接對應物的「創新商品」時，系統會把這項標記起來，提醒你這次的定價評估結果可信度可能比較低，建議自己再確認一次。",
    "市場資料品質(高)": "AI 查市場行情時，是否成功比對到至少兩個不同電商平台的真實售價。平台數越多，代表上面那個市場行情區間的參考價值越高、越不是單一商家的個別報價。",
    "是否具創新標籤": "AI 判斷您的商品在市場上找不找得到直接對應的同類商品。如果被標成「創新」，代表這可能是市場上少見、甚至獨創的商品，上面「定價偏離市場比例」那個數字建議謹慎參考，偏離不代表定價有問題。",
    "回饋方案層數": "您設定的回饋方案（價格）層數，是跟同類型成功案例相比較後給出的分數。層數太少，贊助者選擇有限；層數太多，又可能讓人猶豫不決、反而不下單。",
    "回饋方案最低金額": "您所有回饋方案裡，金額最低的那一筆，是跟同類型成功案例的最低門檻相比較後給出的分數，反映你的入門門檻是否友善。",
    "回饋方案最高金額": "您所有回饋方案裡，金額最高的那一筆，是跟同類型成功案例的最高方案相比較後給出的分數，反映你有沒有設計出足夠吸引重度支持者的高單價方案。",
    "回饋方案金額中位數": "您所有回饋方案金額的中位數，是跟同類型成功案例相比較後給出的分數，反映整體定價策略是偏高、偏低還是落在一般水準。",

    // 3. 文案說服力
    "文案規格字詞比例(規則)": "用規則式文字分析，計算您文案裡屬於「產品規格說明」區塊（規格、尺寸、材質等客觀描述）的字數，佔全文的比例。",
    "文案風險提示字詞比例": "用規則式文字分析，計算您文案裡屬於「風險與挑戰、退換貨規則、注意事項」這類區塊的字數，佔全文的比例。適度揭露風險能建立信任，但比例過高可能讓贊助者看了卻步。",
    "文案是否附社群連結": "偵測您的文案裡有沒有附上 Facebook、Instagram、LINE 等社群連結，讓贊助者可以進一步認識你的團隊、追蹤後續的專案動態。",
    "文案標點符號強度": "計算您文案裡平均每句話使用「！」「？」這類強調型標點符號的密集程度。適度使用能增加情緒感染力，但用太多容易顯得浮誇、降低專業感。",
    "文案平均句長": "您文案裡平均每句話的字數。句子太長，讀起來吃力；太短，又可能解釋得不夠完整，這項分數是跟同類型成功案例的句長習慣比較出來的。",
    "詞彙豐富度": "用斷詞分析計算您文案裡「不重複出現的詞彙數」佔「全部詞彙數」的比例。比例越低，代表用字可能比較重複、單調。",
    "文案信任感評分": "AI 從誠懇度、風險揭露、是否有具體保證等角度，評估您的文案能為贊助者建立多少信任感的綜合分數。",
    "文案情感字詞比例": "AI 評估您文案裡「情感渲染、品牌初衷」類字詞所佔的比例。適度的情感鋪陳有助於打動人心，但比例過高可能讓文案顯得不夠客觀、說服力反而下降。",
    "文案規格詞比例": "AI 評估您文案裡「規格、技術、客觀描述」類字詞所佔的比例，反映文案在理性說服這一塊的份量夠不夠。",
    "情感字詞數量": "AI 從您的文案中挑出來的代表性情感／渲染字詞數量（最多列 5 個），數量不代表好壞，單純是 AI 擷取到的樣本數。",
    "規格字詞數量": "AI 從您的文案中挑出來的代表性規格／技術字詞數量（最多列 5 個），數量不代表好壞，單純是 AI 擷取到的樣本數。",
    "FAQ總題數": "您上傳的 FAQ 檔案裡，總共包含的問答題數。題數越充足，通常代表你對贊助者可能會有的疑慮準備得越完整。",
    "FAQ更新頻率": "FAQ 總題數除以募資天數算出來的比例，反映相對於整個募資週期的長度，您準備的 FAQ 內容密集程度夠不夠。",
    "圖文總字數": "您上傳的文案內容總字數，用來搭配圖片／影片數量一起計算「每百字媒體數」這類圖文比例指標。",

    // 4. 影像吸引力
    "納入分析影片數": "您上傳的影片裡，成功通過畫面篩選、確實被 AI 拿去分析評分的影片數量。",
    "低覆蓋率排除影片數": "您上傳的影片裡，因為缺乏足夠的「產品實際使用情境」畫面而被排除、沒有被納入評分的影片數量。",
    "總影片時長": "所有被納入分析的影片加總起來的時長（秒）。",
    "首支影片情境比例": "AI 針對您上傳的第一支影片，評估畫面中呈現「產品實際使用情境」的比例，比例越高代表這支影片越能讓人具體想像使用情境。",
    "首支影片AI評分": "AI 針對您上傳的第一支影片裡篩選出的代表性畫面，逐張評分後取得的平均分數（0~100），分數越高代表這支影片越能呈現真實的使用情境。",
    "平均影片情境比例": "您所有上傳影片中，呈現使用情境比例的平均值。",
    "最大影片情境比例": "您所有上傳影片中，呈現使用情境比例最高的那一支影片的比例值，代表你最強的那支影片表現如何。",
    "平均影片AI評分": "您所有上傳影片的 AI 評分平均值。",
    "時長加權情境比例": "把每支影片的使用情境比例依照該影片的時長加權平均，時長越長的影片在這個分數裡的影響力越大。",
    "專案圖片數量": "您上傳的圖片總數量。",
    "專案影片數量": "您上傳的影片總數量。",
    "每百字媒體數": "平均每 100 字文案，搭配了幾張圖片／幾支影片，反映您的文案有沒有足夠的視覺素材輔助說明，避免純文字看起來太單調。",

    // 5. 市場契合度 (PMF)
    "近期同類達標率": "跟您同一個次分類（例如「設計」）的歷史專案裡，有多少比例最終成功達標。比例越高，代表這個類別目前整體比較容易獲得贊助者青睞。",
    "Google 趨勢斜率": "AI 從您的文案萃取出的市場關鍵字，拿去查詢 Google 搜尋趨勢後得到的市場熱度分數（0~100）。分數越高，代表這類產品最近在網路上被搜尋、討論的熱度越高，市場需求可能比較旺盛。",
    "命中相似度": "您的專案描述，跟歷史上「達標率特別高（爆款）」的專案相比，在語意上的相似程度。相似度越高，代表您的產品定位或賣點，跟過去曾經大爆發的專案越接近。",
    "市場飽和度計數": "跟您同一個次分類（例如「設計」）的歷史專案總數。數字越高，代表這個類別裡已經有越多專案在競爭贊助者的注意力與預算。",
};

function getFeatureDescription(featureName) {
    return FEATURE_DESCRIPTIONS[featureName] || "";
}

// ── Tooltip「傳送門」：不要讓 tooltip 的 DOM 卡在手風琴/卡片裡面 ──────
// .accordion-item 這些容器有 overflow:hidden（用來讓收合動畫、圓角正常
// 裁切），tooltip 如果用 position:absolute 定位在裡面，只要內容超出容器
// 範圍就會被物理裁掉，z-index 再高也沒用（z-index 解決的是「誰蓋過誰」，
// 不是「有沒有被裁切」）。這裡改成只建立「一個」共用的 tooltip 元素，
// 直接掛在 <body> 最外層（position: fixed），完全脫離所有容器的裁切範圍，
// hover/focus 到哪個「?」就即時搬過去、換內容。
let _tooltipEl = null;

function _ensureTooltipEl() {
    if (!_tooltipEl) {
        _tooltipEl = document.createElement('div');
        _tooltipEl.className = 'global-tooltip';
        document.body.appendChild(_tooltipEl);
    }
    return _tooltipEl;
}

function showGlobalTooltip(targetEl) {
    const text = targetEl.getAttribute('data-tooltip');
    if (!text) return;

    const tip = _ensureTooltipEl();
    tip.textContent = text;
    // 先量尺寸（這時還看不到，visibility:hidden），量完才決定要放上面還下面
    tip.style.visibility = 'hidden';
    tip.style.display = 'block';

    const rect = targetEl.getBoundingClientRect();
    const tipRect = tip.getBoundingClientRect();
    const margin = 8;

    let left = rect.left + rect.width / 2 - tipRect.width / 2;
    left = Math.max(margin, Math.min(left, window.innerWidth - tipRect.width - margin));

    let top = rect.top - tipRect.height - 10; // 預設顯示在「?」上方
    let placeBelow = false;
    if (top < margin) {
        // 「?」太靠近視窗頂端、上方放不下，改放下面
        top = rect.bottom + 10;
        placeBelow = true;
    }

    tip.classList.toggle('tooltip-below', placeBelow);
    tip.style.left = `${left}px`;
    tip.style.top = `${top}px`;
    // 箭頭要對準「?」的中心，而不是 tooltip 本身的中心（文字靠邊時會跑掉）
    tip.style.setProperty('--arrow-left', `${rect.left + rect.width / 2 - left}px`);

    tip.style.visibility = 'visible';
    tip.style.opacity = '1';
}

function hideGlobalTooltip() {
    if (_tooltipEl) {
        _tooltipEl.style.opacity = '0';
        _tooltipEl.style.visibility = 'hidden';
    }
}

// 用事件代理（delegation）掛在 document 上，而不是每次 renderAccordion()
// 重畫手風琴時都重新綁一次——這樣不會累積重複的監聽器，動態插入的
// 「?」也不用額外處理，天生就吃得到。
document.addEventListener('mouseover', (e) => {
    const target = e.target.closest('.info-tooltip');
    if (target) showGlobalTooltip(target);
});
document.addEventListener('mouseout', (e) => {
    const target = e.target.closest('.info-tooltip');
    if (target) hideGlobalTooltip();
});
document.addEventListener('focusin', (e) => {
    const target = e.target.closest('.info-tooltip');
    if (target) showGlobalTooltip(target);
});
document.addEventListener('focusout', (e) => {
    const target = e.target.closest('.info-tooltip');
    if (target) hideGlobalTooltip();
});
// 捲動時位置會對不準「?」，直接收起來，避免 tooltip 飄在錯誤的地方
window.addEventListener('scroll', hideGlobalTooltip, true);

function _escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function formatScoreValue(score) {
    return (score === null || score === undefined)
        ? '<span style="color:#B0A99A;">尚未分析</span>'
        : `${score}分`;
}

// ── 動態產生「細項評分」手風琴（View 2）──────────────────────
// 同樣依 DIMENSION_ORDER 排序，跟診斷報告分頁的順序保持一致，
// 避免使用者在「細項評分」跟「診斷報告」兩個頁面看到不一樣的維度順序。
function renderAccordion(dimensionsEvaluation) {
    const container = document.getElementById('accordionContainer');
    if (!container) return;
    container.innerHTML = '';

    const sorted = [...dimensionsEvaluation].sort((a, b) => {
        const idxA = DIMENSION_ORDER.indexOf(a.dimension_name);
        const idxB = DIMENSION_ORDER.indexOf(b.dimension_name);
        return (idxA === -1 ? 999 : idxA) - (idxB === -1 ? 999 : idxB);
    });

    sorted.forEach((dim, idx) => {
        const iconInfo = getDimensionIcon(dim.dimension_name);
        const isFirst = idx === 0; // 第一項預設展開

        const featuresHtml = dim.features.map(f => {
            const desc = getFeatureDescription(f.feature_name);
            // 找不到說明文字的欄位就不渲染「?」圖示，避免顯示一個空的 tooltip
            const tooltipHtml = desc
                ? `<span class="info-tooltip" tabindex="0" data-tooltip="${_escapeHtml(desc)}">?</span>`
                : '';
            return `<div class="sub-score-row"><span>${f.feature_name}${tooltipHtml}</span><b>  ${formatScoreValue(f.score)}</b></div>`;
        }).join('');

        const itemHtml = `
            <div class="accordion-item ${isFirst ? 'open' : ''}">
                <div class="accordion-header" onclick="toggleAccordion(this)">
                    <div><i class="${iconInfo.icon}" style="background:${iconInfo.bg}; color:white; padding:4px 9px; border-radius:6px; margin-right:8px;"></i><b>${dim.dimension_name}</b></div>
                    <div><b>${formatScoreValue(dim.score)}</b> <small style="color:#988775;">${dim.weight}</small> <i class="fa-solid ${isFirst ? 'fa-caret-up' : 'fa-caret-down'}" style="color:#D59B2D; margin-left:8px; font-size:24px;"></i></div>
                </div>
                <div class="accordion-body">
                    <div class="score-box">${featuresHtml}</div>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', itemHtml);
    });
}

// 4. 標籤篩選與報告列表渲染
function filterReport(tabEl, dimensionName) {
    document.querySelectorAll('.tab-pill').forEach(el => el.classList.remove('active'));
    tabEl.classList.add('active');
    renderReportCards(dimensionName);
}

// 分頁固定顯示順序（跟企劃書原本的五維度順序一致）。沒列在這裡的
// 新維度名稱會自動排到最後面，不會噴錯，只是排序不保證跟你預期一致，
// 屆時把新維度名稱加進這個陣列即可。
const DIMENSION_ORDER = ["專案執行力", "價格競爭力", "文案說服力", "影像吸引力", "市場契合度(PMF)", "產品市場契合度", "專案屬性"];

// ── 動態產生「診斷報告」分頁按鈕（View 3）─────────────────────
// 分頁清單直接從 diagnosis_report 實際出現過的 dimension 值取不重複清單，
// 不再假設固定是哪幾個維度，避免卡片被過濾掉找不到分頁可以顯示的情況；
// 取出清單後依 DIMENSION_ORDER 排序，讓分頁順序固定、不受後端回傳陣列順序影響。
function renderFilterTabs(diagnosisReport) {
    const container = document.getElementById('filterTabsContainer');
    if (!container) return;
    container.innerHTML = '';

    let uniqueDimensions = [...new Set(diagnosisReport.map(item => item.dimension))];
    uniqueDimensions.sort((a, b) => {
        const idxA = DIMENSION_ORDER.indexOf(a);
        const idxB = DIMENSION_ORDER.indexOf(b);
        return (idxA === -1 ? 999 : idxA) - (idxB === -1 ? 999 : idxB);
    });

    if (uniqueDimensions.length === 0) {
        renderReportCards(null);
        return;
    }

    uniqueDimensions.forEach((dimName, idx) => {
        const iconInfo = getDimensionIcon(dimName);
        const activeClass = idx === 0 ? 'active' : '';
        const tabHtml = `<div class="tab-pill ${activeClass}" onclick="filterReport(this, '${dimName}')"><i class="${iconInfo.icon}" style="margin-right: 6px;"></i>  ${dimName}</div>`;
        container.insertAdjacentHTML('beforeend', tabHtml);
    });

    renderReportCards(uniqueDimensions[0]);
}

// 單張診斷卡片的 HTML 樣板，抽出來讓「畫面上依分頁篩選顯示」跟
// 「PDF 匯出時的全維度版本」共用同一份樣式，不用維護兩份一樣的東西
function buildReportCardHtml(item) {
    let cardClass = 'green', tagClass = 'green', tagText = '請繼續保持';
    if (item.tag_type === 'negative' || item.tag_type === 'red') {
        cardClass = 'red'; tagClass = 'red'; tagText = '建議立即修改';
    } else if (item.tag_type === 'warning' || item.tag_type === 'yellow') {
        cardClass = 'yellow'; tagClass = 'yellow'; tagText = '建議進行優化';
    }

    return `
        <div class="report-box ${cardClass}">
            <div style="margin-bottom:10px;"><span class="tag-pill ${tagClass}">${tagText}</span><b style="font-size:1.05rem;">${item.title}</b></div>
            <div style="font-size:0.9rem; color:#8A7865; margin-bottom:8px;">${item.original_setting}</div>
            <div style="font-size:0.95rem; line-height:1.5;"><b>${item.suggestion}</b></div>
        </div>
    `;
}

// 將診斷建議畫到網頁上
function renderReportCards(dimensionFilter = null) {
    const container = document.getElementById('reportListContainer');
    if (!container) return;
    container.innerHTML = '';

    const filteredList = dimensionFilter 
        ? currentDiagnosisReport.filter(item => item.dimension === dimensionFilter)
        : currentDiagnosisReport;

    if (filteredList.length === 0) {
        container.innerHTML = `<div style="text-align:center; padding: 30px; color:#8A7865;">在這個維度中，目前沒有需要特別注意的改善建議喔！🎉</div>`;
        return;
    }

    filteredList.forEach(item => {
        container.insertAdjacentHTML('beforeend', buildReportCardHtml(item));
    });
}



// 定義雷達圖的 5 大固定軸向
const RADAR_LABELS = ['專案執行力', '價格競爭力', '文案說服力', '影像吸引力', '產品市場契合度'];

// 5. 雷達圖繪製 (Chart.js)
let chartInstance1 = null, chartInstance2 = null;

function renderCharts(radarScores = currentRadarScores) {
    const hasUnanalyzed = radarScores.some(v => v === null || v === undefined);
    const displayScores = radarScores.map(v => (v === null || v === undefined) ? 0 : v);
    const pointStyles = radarScores.map(v => (v === null || v === undefined) ? 'crossRot' : 'circle');

    const chartData = {
        labels: RADAR_LABELS,
        datasets: [{
            data: displayScores,
            backgroundColor: 'rgba(242, 203, 87, 0.5)',
            borderColor: '#f7d200',
            borderWidth: 2,
            pointRadius: 3.5,
            pointStyle: pointStyles,
            pointBackgroundColor: '#ffff'
        }, {
            data: [75, 70, 60, 75, 60],
            backgroundColor: 'rgba(200, 200, 200, 0.2)',
            borderColor: '#a09e9a',
            borderWidth: 1.5,
            pointBackgroundColor: '#a09e9a',
            pointRadius: 1.5
        }]
    };
    const options = { 
        layout: { padding: 10 }, 
        scales: { 
            r: { 
                min: 0, 
                max: 100, 
                ticks: { display: false }, 
                pointLabels: { font: { size: 14 }, color: '#333333', padding: 5 } 
            } 
        }, 
        plugins: { legend: { display: false } } 
    };

    const ctx1 = document.getElementById('previewRadarChart');
    if (ctx1) {
        if (chartInstance1) chartInstance1.destroy();
        chartInstance1 = new Chart(ctx1, { type: 'radar', data: chartData, options: options });
    }

    const ctx2 = document.getElementById('detailRadarChart');
    if (ctx2) {
        if (chartInstance2) chartInstance2.destroy();
        chartInstance2 = new Chart(ctx2, { type: 'radar', data: chartData, options: options });
    }

    const noteEl = document.getElementById('radarUnanalyzedNote');
    if (noteEl) {
        if (hasUnanalyzed) {
            const unanalyzedLabels = RADAR_LABELS.filter((_, i) => radarScores[i] === null || radarScores[i] === undefined);
            noteEl.innerText = `⚠️ 圖上標示 ✕ 的維度（${unanalyzedLabels.join('、')}）目前尚未有足夠資料進行分析，不代表分數低`;
            noteEl.style.display = 'block';
        } else {
            noteEl.style.display = 'none';
        }
    }
}

// 6. 表單送出與 API 串接（非同步輪詢：後端 LLM 分析要跑幾秒到幾十秒，
//    不能一次 fetch 就等到結果，改成先拿 job_id，每隔 2 秒問一次「好了沒」）
// 6. 表單送出與 API 串接
const POLL_INTERVAL_MS = 2000;
const POLL_TIMEOUT_MS = 300000; // 最多等 5 分鐘

let lastTimeoutJobId = null;

async function pollJobResult(jobId, submitBtn) {
    const startTime = Date.now();

    while (Date.now() - startTime < POLL_TIMEOUT_MS) {
        await new Promise(resolve => setTimeout(resolve, POLL_INTERVAL_MS));

        const elapsedSec = Math.round((Date.now() - startTime) / 1000);
        const statusResponse = await fetch(`http://127.0.0.1:8000/api/v1/diagnose/${jobId}`);
        if (!statusResponse.ok) throw new Error("查詢診斷結果失敗");
        const statusData = await statusResponse.json();

        // ★ 取代原本的 submitBtn.innerText = ...
        const p = statusData.progress;
        submitBtn.innerText = p ? `診斷中（${p.step}/${p.total}）` : 'AI 診斷運算中...';
        renderProgress(p, elapsedSec);

        if (statusData.status === "done") {
            if (!statusData.result) {
                throw new Error("後端回傳診斷已完成，但資料內容為空");
            }
            return statusData.result;
        }
        if (statusData.status === "failed") {
            throw new Error(statusData.error || "診斷過程發生未知錯誤");
        }
    }

    const timeoutError = new Error(`診斷時間較長（超過 ${POLL_TIMEOUT_MS / 1000} 秒），系統仍在背景運算，請稍後重新查詢`);
    timeoutError.jobId = jobId;
    timeoutError.isTimeout = true;
    throw timeoutError;
}

// 讓使用者手動查詢先前逾時、但可能已經跑完的診斷結果
async function checkPreviousJob() {
    if (!lastTimeoutJobId) {
        alert("目前沒有先前逾時的診斷紀錄可以查詢");
        return;
    }
    try {
        const statusResponse = await fetch(`http://127.0.0.1:8000/api/v1/diagnose/${lastTimeoutJobId}`);
        if (!statusResponse.ok) throw new Error("向伺服器查詢失敗");
        const statusData = await statusResponse.json();

        if (statusData.status === "done") {
            if (!statusData.result) {
                alert("該次診斷已結束，但未產出有效結果，請重新送出診斷。");
                lastTimeoutJobId = null;
                return;
            }
            updateUIWithData(statusData.result);
            lastTimeoutJobId = null;
        } else if (statusData.status === "failed") {
            alert(`該次診斷最終失敗：\n${statusData.error || "未知錯誤"}`);
            lastTimeoutJobId = null;
        } else {
            alert("背景仍在運算中（AI 檢索/文案評估中），請稍後再按一次查詢！");
        }
    } catch (error) {
        alert(`查詢失敗：${error.message}`);
    }
}

async function handleFormSubmit(event) {
    if (!validatePriceFields()) {   // ★
        document.getElementById('priceErrorBox').scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
    }
    event.preventDefault();
    const formEl = document.getElementById('diagnoseForm');
    
    // 💡 防呆機制：檢查所有必填欄位 (required) 是否都填寫了
    if (!formEl.checkValidity()) {
        formEl.reportValidity(); // 觸發瀏覽器原生的紅色警告提示框
        return;
    }

    if (selectedFiles.length === 0) {
        alert("防呆提醒：請至少上傳一個專案檔案（文案 PDF 或圖片/影片）！");
        return;
    }

    // 驗證都通過、確定會送出這次診斷了，先把表單欄位存起來，
    // 不管後面 API 呼叫成不成功，下次都可以點「套用上次填寫資料」帶回來
    saveFormInputToStorage(formEl);

    const submitBtn = formEl.querySelector('button[type="submit"]');
    submitBtn.innerText = "送出診斷請求...";
    submitBtn.disabled = true;
    showProgressCard();

    try {
        // 💡 系統自動分類檔案邏輯
        const formData = new FormData();
        formData.append('project_type', formEl.project_type.value);
        formData.append('category', formEl.category.value);
        formData.append('funding_days', formEl.funding_days.value);
        formData.append('target_amount', formEl.target_amount.value);
        formData.append('price_tiers', formEl.price_tiers.value);
        
        document.querySelectorAll('input[name="prices"]').forEach(input => {
            formData.append('prices', input.value);
        });

        let contentAppended = false, faqAppended = false;
        selectedFiles.forEach(file => {
            const ext = file.name.split('.').pop().toLowerCase();
            const filename = file.name.toLowerCase();

            // 1. 如果是圖片或影片
            if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'mp4', 'mov', 'avi', 'webm'].includes(ext)) {
                formData.append('media_files', file);
            } 
            // 2. 如果是文件檔 (TXT, PDF, DOC, DOCX)
            else if (['txt', 'pdf', 'doc', 'docx'].includes(ext)) {
                // 🛡️ 關鍵修復：只要檔名包含 faq 或 問答，不管是 PDF 還是 Word，都歸類給 FAQ
                if ((filename.includes('faq') || filename.includes('問答')) && !faqAppended) {
                    formData.append('faq_file', file);
                    faqAppended = true;
                } else if (!contentAppended) {
                    formData.append('content_file', file);
                    contentAppended = true;
                } else if (!faqAppended) {
                    // 若文案已經佔位了，剩下的文件就當作 FAQ
                    formData.append('faq_file', file);
                    faqAppended = true;
                }
            }
        });

        const response = await fetch('http://127.0.0.1:8000/api/v1/diagnose', {
            method: 'POST',
            body: formData
        });
        if (!response.ok) throw new Error("API 連線異常");
        const submitData = await response.json();
        
        // ... (下方維持原本的 pollJobResult 邏輯) ...
        if (!submitData.job_id) throw new Error("後端未回傳 job_id");
        submitBtn.innerText = "AI 診斷運算中...";
        const result = await pollJobResult(submitData.job_id, submitBtn);
        updateUIWithData(result);

    } catch (error) {
        console.warn("診斷逾時或失敗:", error);
        if (error.isTimeout && error.jobId) {
            lastTimeoutJobId = error.jobId;
            alert(`${error.message}\n\n您可以稍後點擊「查詢先前結果」按鈕查看，不需要重新填表單送出。`);
        } else {
            alert(`診斷過程發生問題：${error.message}\n（將顯示展示用範例資料）`);
            // 此處省略範例資料，沿用你原本的寫法
            updateUIWithData({
                success_rate: 80,
                radar_chart_data: { "專案執行力": 85, "價格競爭力": 85, "文案說服力": 85, "影像吸引力": 85, "產品市場契合度": 85 },
                dimensions_evaluation: [],
                diagnosis_report: []
            });
        }
    } finally {
        hideProgressCard(); 
        submitBtn.innerText = "開始診斷 ➔";
        submitBtn.disabled = false;
    }
}

// 7. 更新 UI 與暫存分數
function updateUIWithData(data) {
    // 💡 關鍵防呆：若傳入 null 或非物件，立即中斷，避免崩潰
    if (!data || typeof data !== 'object') {
        console.error("updateUIWithData 收到無效的資料:", data);
        return;
    }

    const previewCard = document.getElementById('resultPreviewCard');
    previewCard.style.display = 'block';

    // 更新總分與環狀圖
    const score = data.success_rate !== undefined ? data.success_rate : 80;
    currentSuccessRate = score;
    currentDimensions = data.dimensions_evaluation || [];
    document.getElementById('previewScoreText').innerText = score + '%';
    
    const circle = document.getElementById('successRateCircle');
    if (circle) {
        // 決定顏色：大於70亮綠色，大於50橘黃色，其餘紅色
        let color = score >= 70 ? '#10B981' : (score >= 50 ? '#F59E0B' : '#EF4444');
        let angle = score * 3.6; // 1% = 3.6度
        // 💡 將後面的 #e4e4e4 改為 transparent，就能去掉灰色的底軌
        circle.style.background = `conic-gradient(${color} ${angle}deg, transparent 0deg)`;
    }

    // 依照 5 大維度名稱精確對齊後端欄位，並暫存至全域變數
    if (data.radar_chart_data) {
        currentRadarScores = RADAR_LABELS.map(label => {
            if (data.radar_chart_data[label] !== undefined) return data.radar_chart_data[label];
            if (label === '產品市場契合度' && data.radar_chart_data['市場契合度(PMF)'] !== undefined) {
                return data.radar_chart_data['市場契合度(PMF)'];
            }
            return null;
        });
    } else {
        currentRadarScores = [85, 85, 85, 85, 85];
    }

    // 繪製兩個分頁的雷達圖
    renderCharts(currentRadarScores);

    // 更新手風琴細項評分
    if (data.dimensions_evaluation && data.dimensions_evaluation.length > 0) {
        renderAccordion(data.dimensions_evaluation);
    }

    // 更新診斷報告卡片
    if (data.diagnosis_report) {
        currentDiagnosisReport = data.diagnosis_report;
        let redCount = 0, yellowCount = 0, greenCount = 0;
        
        currentDiagnosisReport.forEach(item => {
            if (item.tag_type === 'negative' || item.tag_type === 'red') redCount++;
            else if (item.tag_type === 'warning' || item.tag_type === 'yellow') yellowCount++;
            else if (item.tag_type === 'positive' || item.tag_type === 'green') greenCount++;
        });

        const sumCards = document.querySelectorAll('.summary-cards-grid .sum-card');
        if (sumCards.length >= 3) {
            sumCards[0].querySelector('.sum-content-row div:nth-child(2)').innerHTML = `${redCount} <small style="font-size:1rem; color:#7A6855;">處</small>`;
            sumCards[1].querySelector('.sum-content-row div:nth-child(2)').innerHTML = `${yellowCount} <small style="font-size:1rem; color:#7A6855;">處</small>`;
            sumCards[2].querySelector('.sum-content-row div:nth-child(2)').innerHTML = `${greenCount} <small style="font-size:1rem; color:#7A6855;">處</small>`;
        }

        renderFilterTabs(currentDiagnosisReport);
    }

    previewCard.scrollIntoView({ behavior: 'smooth' });
}

window.onload = () => {
    renderCharts([null, null, null, null, null]);

    // 頁面載入時檢查有沒有上次填寫過的資料，有才顯示「套用上次填寫資料」按鈕，
    // 避免第一次使用的人看到一個按了也沒反應的按鈕
    try {
        if (localStorage.getItem(LAST_FORM_STORAGE_KEY)) {
            const fillBtn = document.getElementById('fillLastInputBtn');
            if (fillBtn) fillBtn.style.display = 'inline-flex';
        }
    } catch (e) {
        // localStorage 無法存取（例如瀏覽器設定封鎖）就當作沒有存過資料即可，不用特別處理
    }
};


// ── PDF 報表：專用版面（不截取網頁畫面）──────────────────────────
function _scoreColor(s) {
    if (s === null || s === undefined) return '#B0A99A';
    return s >= 70 ? '#10B981' : (s >= 50 ? '#F59E0B' : '#EF4444');
}

function buildPdfReportElement() {
    const e = _escapeHtml;
    const today = new Date().toLocaleDateString('zh-TW');
    const rate = currentSuccessRate ?? 0;
    const rateColor = _scoreColor(rate);

    // 雷達圖轉成圖片
    let radarImg = '';
    try {
        const canvas = document.getElementById('detailRadarChart') || document.getElementById('previewRadarChart');
        if (canvas) radarImg = canvas.toDataURL('image/png', 1.0);
    } catch (err) { /* 沒圖就略過 */ }

    // 專案基本資料
    const info = currentProjectInfo;
    const infoHtml = info ? `
        <table style="width:100%; border-collapse:collapse; font-size:12px;">
            <tr>
                <td style="padding:4px 0; width:50%;"><b>專案性質：</b>${e(info.project_type)}</td>
                <td style="padding:4px 0;"><b>主題分類：</b>${e(info.category)}</td>
            </tr>
            <tr>
                <td style="padding:4px 0;"><b>募資天數：</b>${e(info.funding_days)} 天</td>
                <td style="padding:4px 0;"><b>目標金額：</b>NT$ ${Number(info.target_amount).toLocaleString()}</td>
            </tr>
            <tr>
                <td colspan="2" style="padding:4px 0;"><b>各層價格：</b>${info.prices.map(p => 'NT$ ' + Number(p).toLocaleString()).join('、')}</td>
            </tr>
        </table>` : '<div style="font-size:12px; color:#8A7865;">（無專案基本資料）</div>';

    // 各維度分數 + 細項說明
    const dims = [...currentDimensions].sort((a, b) => {
        const ia = DIMENSION_ORDER.indexOf(a.dimension_name), ib = DIMENSION_ORDER.indexOf(b.dimension_name);
        return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
    });

    const dimsHtml = dims.map(dim => {
        const featRows = dim.features.map(f => {
            const desc = getFeatureDescription(f.feature_name);
            const has = f.score !== null && f.score !== undefined;
            return `
            <div class="pdf-avoid" style="padding:8px 0; border-bottom:1px solid #EFE4CC;">
                <div style="display:flex; justify-content:space-between; align-items:center; font-size:12px;">
                    <b>${e(f.feature_name)}</b>
                    <b style="color:${_scoreColor(f.score)};">${has ? f.score + ' 分' : '尚未分析'}</b>
                </div>
                ${has ? `<div style="height:5px; background:#F3E8D8; border-radius:3px; margin:5px 0;"><div style="height:5px; width:${f.score}%; background:${_scoreColor(f.score)}; border-radius:3px;"></div></div>` : ''}
                ${desc ? `<div style="font-size:10.5px; color:#7A6855; line-height:1.6; margin-top:3px;">${e(desc)}</div>` : ''}
            </div>`;
        }).join('');

        return `
        <div style="margin-bottom:18px;">
            <div class="pdf-avoid" style="display:flex; justify-content:space-between; align-items:center; background:#FCEABA; border-radius:8px; padding:8px 12px; margin-bottom:4px;">
                <b style="font-size:14px;">${e(dim.dimension_name)}</b>
                <b style="font-size:14px; color:${_scoreColor(dim.score)};">${dim.score === null || dim.score === undefined ? '尚未分析' : dim.score + ' 分'}</b>
            </div>
            ${featRows}
        </div>`;
    }).join('') || '<div style="font-size:12px; color:#8A7865;">無細項評分資料</div>';

    // 診斷建議（依維度分組）
    const dimNames = [...new Set(currentDiagnosisReport.map(i => i.dimension))].sort((a, b) => {
        const ia = DIMENSION_ORDER.indexOf(a), ib = DIMENSION_ORDER.indexOf(b);
        return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
    });

    const styleOf = t => {
        if (t === 'negative' || t === 'red') return { bg: '#FFEAE7', bd: '#F9C6C0', tag: '建議立即修改', c: '#D9473F' };
        if (t === 'warning' || t === 'yellow') return { bg: '#FDF5E0', bd: '#FBE2A0', tag: '建議進行優化', c: '#C08D23' };
        return { bg: '#EAF7EE', bd: '#BFE6CE', tag: '請繼續保持', c: '#2E9E5B' };
    };

    const reportHtml = dimNames.map(name => {
        const cards = currentDiagnosisReport.filter(i => i.dimension === name).map(item => {
            const s = styleOf(item.tag_type);
            return `
            <div class="pdf-avoid" style="background:${s.bg}; border:1px solid ${s.bd}; border-radius:8px; padding:10px 12px; margin-bottom:8px;">
                <div style="margin-bottom:5px;"><span style="color:${s.c}; font-weight:bold; font-size:11px; margin-right:8px;">【${s.tag}】</span><b style="font-size:12.5px;">${e(item.title)}</b></div>
                <div style="font-size:10.5px; color:#8A7865; margin-bottom:4px;">${e(item.original_setting)}</div>
                <div style="font-size:11.5px; line-height:1.6;">${item.suggestion}</div>
            </div>`;
        }).join('');
        return `<div style="margin-bottom:14px;"><div style="font-weight:bold; font-size:13px; margin:10px 0 6px; color:#7A6855;">▍${e(name)}</div>${cards}</div>`;
    }).join('') || '<div style="font-size:12px; color:#8A7865;">目前沒有需要特別注意的改善建議。</div>';

    const sectionTitle = t => `<div style="font-size:15px; font-weight:bold; border-left:5px solid #ED723F; padding-left:8px; margin:22px 0 10px;">${t}</div>`;

    const wrap = document.createElement('div');
    wrap.style.cssText = "width:718px; padding:0; font-family:'Noto Sans TC','PingFang TC','Microsoft JhengHei',sans-serif; color:#4A3420; background:#fff;";
    wrap.innerHTML = `
        <div style="background:#F8C345; border-radius:10px; padding:18px 22px; margin-bottom:16px;">
            <div style="font-size:20px; font-weight:bold;">募資專案診斷報告</div>
            <div style="font-size:11px; margin-top:4px;">群眾募資多模態分析之評分與診斷系統　｜　產出日期：${today}</div>
        </div>

        ${sectionTitle('專案基本資料')}
        ${infoHtml}

        ${sectionTitle('募資成功率與雷達圖')}
        <div class="pdf-avoid" style="display:flex; align-items:center; gap:20px;">
            <div style="width:230px; text-align:center;">
                <div style="font-size:12px; color:#7A6855; margin-bottom:6px;">預估募資成功機率</div>
                <div style="font-size:52px; font-weight:800; color:${rateColor}; line-height:1.1;">${rate}%</div>
                <div style="font-size:11px; color:${rateColor}; font-weight:bold; margin-top:4px;">${rate >= 70 ? '成功機率高' : (rate >= 50 ? '仍有進步空間' : '建議優先改善')}</div>
            </div>
            <div style="flex:1; text-align:center;">
                ${radarImg ? `<img src="${radarImg}" style="max-width:100%; max-height:240px;">` : ''}
                <div style="font-size:10px; color:#8A7865;">灰色＝同類歷史平均　黃色＝本次診斷分數</div>
            </div>
        </div>

        ${sectionTitle('各維度評分與說明')}
        ${dimsHtml}

        ${sectionTitle('診斷建議')}
        ${reportHtml}

        <div style="margin-top:20px; padding-top:8px; border-top:1px solid #EADDBF; font-size:10px; color:#988775; text-align:center;">
            本報告由 AI 模型與歷史資料推估產生，僅供參考，不保證實際募資結果。
        </div>`;
    return wrap;
}

function downloadFullPagePDF() {
    if (currentSuccessRate === null) {
        alert('請先完成一次診斷，再下載報告');
        return;
    }
    const el = buildPdfReportElement();
    const opt = {
        margin: [10, 10, 12, 10],
        filename: `募資診斷報告_${new Date().toISOString().split('T')[0]}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, backgroundColor: '#ffffff' },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait', compress: true },
        pagebreak: { mode: ['css', 'legacy'], avoid: '.pdf-avoid' }
    };
    html2pdf().set(opt).from(el).save();
}



// ★ 價格防呆
// true = 允許相鄰兩層價格相同；改成 false 則必須「嚴格高於」上一層
const PRICE_ALLOW_EQUAL = true;

function validatePriceFields() {
    const targetInput = document.querySelector('input[name="target_amount"]');
    const target = parseFloat(targetInput ? targetInput.value : '');
    const inputs = Array.from(document.querySelectorAll('input[name="prices"]'));
    const fmt = n => 'NT$ ' + Number(n).toLocaleString();
    const errors = [];

    let prevVal = null, prevIdx = -1;   // 只拿「通過檢查的上一層」來比較

    inputs.forEach((input, i) => {
        input.classList.remove('input-error');
        input.setCustomValidity('');

        const v = parseFloat(input.value);
        if (isNaN(v)) return;           // 還沒填的不檢查

        const msgs = [];
        let orderOk = true;

        if (prevVal !== null) {
            const bad = PRICE_ALLOW_EQUAL ? v < prevVal : v <= prevVal;
            if (bad) {
                orderOk = false;
                msgs.push(`第 ${i + 1} 層價格（${fmt(v)}）不可${PRICE_ALLOW_EQUAL ? '低於' : '小於或等於'}第 ${prevIdx + 1} 層（${fmt(prevVal)}）`);
            }
        }
        if (!isNaN(target) && v > target) {
            msgs.push(`第 ${i + 1} 層價格（${fmt(v)}）不可超過目標金額（${fmt(target)}）`);
        }

        if (msgs.length) {
            input.classList.add('input-error');
            input.setCustomValidity(msgs[0]);   // 讓瀏覽器原生送出檢查也會擋下
            errors.push(...msgs);
        }
        if (orderOk) { prevVal = v; prevIdx = i; }
    });

    const box = document.getElementById('priceErrorBox');
    if (box) {
        if (errors.length) {
            box.innerHTML = errors.map(m => `<div>${m}</div>`).join('');
            box.style.display = 'block';
        } else {
            box.style.display = 'none';
            box.innerHTML = '';
        }
    }
    return errors.length === 0;
}

// 事件代理：價格欄位或目標金額一變動就即時檢查（動態產生的欄位也吃得到）
document.addEventListener('input', (e) => {
    if (e.target.matches('input[name="prices"], input[name="target_amount"]')) {
        validatePriceFields();
    }
});


// ★ 進度顯示（步驟名稱要跟後端 report_progress 的 step 編號對應）
const PROGRESS_STEPS = [
    "文案語意分析",
    "市場價格比對",
    "市場契合度（PMF）分析",
    "影片畫面分析",
    "AI 模型評分（XGBoost + SHAP）",
    "生成改善建議",
];

function showProgressCard() {
    document.getElementById('progressCard').style.display = 'block';
    renderProgress(null, 0);
    document.getElementById('progressCard').scrollIntoView({ behavior: 'smooth', block: 'center' });
}
function hideProgressCard() {
    document.getElementById('progressCard').style.display = 'none';
}

function renderProgress(progress, elapsedSec) {
    const step = progress ? progress.step : 0;
    const total = progress ? progress.total : PROGRESS_STEPS.length;
    const msg = progress ? progress.message : '已送出，等待伺服器開始處理…';

    document.getElementById('progressBarFill').style.width =
        Math.max(3, Math.round(((Math.max(step, 1) - 1) / total) * 100)) + '%';
    document.getElementById('progressDetail').innerText =
        `${msg}（已等待 ${elapsedSec} 秒）`;

    document.getElementById('progressStepList').innerHTML = PROGRESS_STEPS.map((name, i) => {
        const n = i + 1;
        let cls = '', icon = 'fa-regular fa-circle';
        if (n < step)       { cls = 'done';   icon = 'fa-solid fa-circle-check'; }
        else if (n === step) { cls = 'active'; icon = 'fa-solid fa-spinner fa-spin'; }
        return `<li class="${cls}"><i class="${icon}"></i>${n}. ${name}</li>`;
    }).join('');
}