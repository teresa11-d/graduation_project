# 負責載入 joblib、跑 XGBoost 與 SHAP 解釋
import joblib
import shap
import pandas as pd
import numpy as np
from scipy.special import expit
import xgboost as xgb
import os
import json                 
from google import genai     
from services.feature_labels import get_feature_label, get_dimension_for_feature

class MLService:
    def __init__(self, model_path: str = "model_bundle.joblib"):
        try:
            self.bundle = joblib.load(model_path)
            
            self.model = self.bundle["model"]

            self.iso = self.bundle.get("isotonic")
            self.all_features = self.bundle["all_features"]
            self.dimension_map = self.bundle["dimension_map"]

            self.explainer = shap.TreeExplainer(
                self.model, feature_perturbation="tree_path_dependent", model_output="raw"
            )
            self.is_ready = True
            print("✅ 模型載入成功！")
        except Exception as e:
            print(f"⚠️ 模型載入失敗，將啟動 Mock 模式。原因: {e}")
            self.is_ready = False

    def predict_and_format(self, x_row: pd.DataFrame, content_text: str = "") -> dict:
        """
        跑模型預測、計算 SHAP，並將結果轉換為前端要求的 DiagnosisResponse 格式
        """
        if not self.is_ready:
            raise RuntimeError("模型未準備就緒")

        # 記錄這次輸入裡「真的有值」的特徵——還沒被分析出來的（NaN）不該被拿去
        # 生成「強勢特徵」「需優化弱點」這種聽起來很篤定的建議卡片。SHAP 對
        # 缺值算出來的貢獻，只是模型內部學到的「沒資料時的預設分支」反應，
        # 不代表對這個專案的真實判斷，講出來等於是沒根據的斷言。
        known_features = set(x_row.columns[x_row.notna().iloc[0]])

        # 1. 執行推論與 SHAP 解釋 (沿用 colab 中的核心邏輯)
        shap_values = self.explainer.shap_values(x_row)
        base_log_odds = self.explainer.expected_value
        if isinstance(base_log_odds, (list, np.ndarray)):
            base_log_odds = base_log_odds[0]

        feat_shap = shap_values[0]
        total_log_odds = base_log_odds + feat_shap.sum()

        base_prob = float(expit(base_log_odds))
        raw_prob = float(expit(total_log_odds))
        final_prob = float(self.iso.transform([raw_prob])[0]) if self.iso else raw_prob
        score_100 = int(round(final_prob * 100))

        # 計算特徵貢獻百分比
        sum_abs_shap = np.sum(np.abs(feat_shap))
        feature_contrib_pct = (feat_shap / sum_abs_shap) * 100 if sum_abs_shap > 0 else np.zeros_like(feat_shap)

        feature_report = sorted(
            zip(self.all_features, feature_contrib_pct, feat_shap),
            key=lambda t: abs(t[1]), reverse=True,
        )

        # 2. 將 SHAP 維度分數轉換為雷達圖所需的 0-100 分制
        radar_chart_data = {}
        dimensions_evaluation = []

        for dim, feats in self.dimension_map.items():
            idxs = [self.all_features.index(f) for f in feats]
            dim_known = any(f in known_features for f in feats)

            clean_dim_name = dim.split(". ")[-1]  # 移除 "1. ", "2. " 前綴

            if clean_dim_name == "專案屬性":
                continue

            # 改用：將該維度下「有資料的特徵分數」做平均，符合人類直覺
            valid_feature_scores = []
            for f in feats:
                if f in known_features:
                    f_idx = self.all_features.index(f)
                    f_score = min(max(int(score_100 + (feature_contrib_pct[f_idx] * 2)), 0), 100)
                    valid_feature_scores.append(f_score)
            
            if valid_feature_scores:
                dim_score = int(sum(valid_feature_scores) / len(valid_feature_scores))
            else:
                dim_score = None

            # 這個維度底下全部特徵都還沒被分析（例如「市場契合度(PMF)」目前
            # 唯一的欄位還沒接 Google Trends），就不要顯示一個看起來煞有其事
            # 的分數，回傳 None，讓前端顯示「尚未分析」。
            radar_chart_data[clean_dim_name] = dim_score if dim_known else None

            feature_scores = []
            for f in feats:
                f_idx = self.all_features.index(f)
                f_score = min(max(int(score_100 + (feature_contrib_pct[f_idx] * 2)), 0), 100)
                feature_scores.append({
                    "feature_name": get_feature_label(f),
                    "score": f_score if f in known_features else None,
                })

            dimensions_evaluation.append({
                "dimension_name": clean_dim_name,
                "score": dim_score if dim_known else None,
                "weight": "",  # 可依實際邏輯調整
                "features": feature_scores
            })

        # 3. 整理正負面特徵為報告卡片——只從「真的有值」的特徵裡挑
        # 貢獻強度分三段：|貢獻| < 1% 算「影響輕微，建議優化」（黃），
        # 其餘依正負號分「強勢特徵」（綠）／「需優化弱點」（紅）
        # 3. 整理正負面特徵為報告卡片——只從「真的有值」的特徵裡挑
        diagnosis_report = []
        WEAK_CONTRIBUTION_THRESHOLD = 1.0

        # 🛡️ 在源頭排除屬於「專案屬性」的特徵
        strong_pos_feats = [(f, p) for f, p, s in feature_report if s > 0 and f in known_features and abs(p) >= WEAK_CONTRIBUTION_THRESHOLD and get_dimension_for_feature(f, self.dimension_map) != "專案屬性"][:5]
        strong_neg_feats = [(f, p) for f, p, s in feature_report if s < 0 and f in known_features and abs(p) >= WEAK_CONTRIBUTION_THRESHOLD and get_dimension_for_feature(f, self.dimension_map) != "專案屬性"][:5]
        weak_feats = [(f, p) for f, p, s in feature_report if f in known_features and abs(p) < WEAK_CONTRIBUTION_THRESHOLD and get_dimension_for_feature(f, self.dimension_map) != "專案屬性"][:5]

        # 初始化 Gemini API
        api_key = os.environ.get("GEMINI_API_KEY", "")
        client = genai.Client(api_key=api_key) if api_key else None
        safe_content = content_text[:1500] if content_text else "使用者未提供文字內容。"
        import re

        # 💡 建立「全域專案狀態摘要」，讓 AI 看到完整數據，避免給出與現狀矛盾的指引
        project_context_dict = x_row.iloc[0].to_dict()
        context_lines = []
        for k, v in project_context_dict.items():
            if pd.notna(v):
                context_lines.append(f"- {get_feature_label(k)}: {v}")
        full_context_str = "\n".join(context_lines)

        # 💡 將重複的呼叫邏輯整合成單一函式，進行「動態排版分流」與「邏輯防呆」
        def _generate_advice(feat_key, p_value, tag_type):
            feature_name = get_feature_label(feat_key)
            feature_val = x_row[feat_key].iloc[0] if feat_key in x_row.columns else "未知"
            
            # 判斷是「文案特徵」還是「數值/架構特徵」
            text_keywords = ["文案", "字", "詞", "標點", "句長", "故事", "情感", "信任", "風險提示", "豐富度"]
            is_text_feature = any(kw in feature_name for kw in text_keywords)

            # 依據標籤決定提示詞的用語
            if tag_type == "negative":
                impact_str = f"嚴重的需優化弱點（拉低成功率 {abs(p_value):.1f}%）"
                action_instruction = "請根據上方的【專案所有特徵數值】，給出具體、白話且『符合現狀』的修改指引。絕對不可給出與現有數據矛盾的建議。"
                prefix_q, prefix_a = "需修改出處", "行動指引"
            elif tag_type == "warning":
                impact_str = f"影響輕微的次要優化項目（影響 {p_value:+.1f}%）"
                action_instruction = "請根據上方的【專案所有特徵數值】，給出具體的微調指引，當作『若有餘力時的加分項目』來建議。"
                prefix_q, prefix_a = "可優化出處", "微調指引"
            else:
                impact_str = f"強勢加分特徵（提升成功率 {p_value:.1f}%）"
                action_instruction = "請結合【專案所有特徵數值】，說明為什麼這個特徵現況對募資是好的，並建議如何在行銷上放大這個優勢。"
                prefix_q, prefix_a = "優勢出處", "放大優勢"

            if not client:
                return f"【{prefix_q}】：『系統未設定 API Key』<br><br>【{prefix_a}】：無法生成動態建議。"

            # 🛡️ 徹底分流：針對文案與數值，給予完全不同的 JSON 格式要求
            if is_text_feature:
                quote_instruction = f"請從下方的「原始文案」中，精準擷取 1~2 句與「{feature_name}」最相關的原文。"
                json_format = '{"quote": "擷取的原文", "action": "具體指引"}'
            else:
                quote_instruction = "此項目為專案客觀數值設定，請【絕對不要】從文案中擷取不相關的句子，你只需要專心給出 action 建議即可。"
                json_format = '{"action": "具體指引"}'

            prompt = f"""你是專業的群眾募資顧問。SHAP 診斷指出「{feature_name}」是一個{impact_str}。
【當前 {feature_name} 系統偵測數值】：{feature_val}

為了避免你給出錯誤的建議，以下提供該專案目前的完整數據狀態供你參考（請務必依此數據為準）：
--- 專案所有特徵數值 ---
{full_context_str}
------------------------

使用者的原始文案如下：
{safe_content}

🚨 嚴格任務指示：
1. 擷取規則：{quote_instruction}
2. action 欄位：{action_instruction}
3. ⛔ 致命邏輯錯誤絕對禁止（請仔細檢查你的 action 建議）：
   - 【數值比較邏輯】：系統已告知你當前數值為 {feature_val}。如果你的建議包含具體數字（如價格），該數字必須「大於」或「小於」當前數值，絕對不可建議「新增一個跟目前數值一模一樣」的方案。例如：若目前最高金額已是 8888，你可以建議新增破萬的頂級方案，絕對不能再叫他新增 8888 的方案。
   - 【存在性邏輯】：只要系統的 FAQ題數 或 FAQ更新頻率 大於 0，就代表「該專案已經有 FAQ 文件了」！絕對禁止建議使用者「新增常見問題區塊」，而是要建議他「如何增加更多題數」或「如何在專案更新中向贊助者展現頻繁更新 FAQ 的誠意」。

回傳 JSON 格式：
{json_format}"""

            try:
                import time
                response = client.models.generate_content(
                    model="gemini-3.5-flash-lite", 
                    contents=prompt, 
                    config=genai.types.GenerateContentConfig(response_mime_type="application/json", temperature=0.2)
                )
                time.sleep(1.5)
                
                match = re.search(r'\{[\s\S]*\}', response.text)
                res_data = json.loads(match.group(0) if match else response.text)
                
                # 🛡️ 動態排版：如果不是文案特徵，Python 直接印出乾淨的數值狀態，不加『』引號！
                if is_text_feature:
                    return f"【{prefix_q}】：『{res_data.get('quote', '')}』<br><br>【{prefix_a}】：{res_data.get('action', '')}"
                else:
                    return f"【當前數值狀態】：{feature_val}<br><br>【{prefix_a}】：{res_data.get('action', '')}"
            except Exception as e:
                print(f"Gemini 建議生成失敗 ({tag_type}): {e}")
                return f"【系統狀態】：解析失敗<br><br>【{prefix_a}】：建議生成失敗，請稍後再試。"

        # 生成報告卡片 (透過迴圈自動套用上方函數，程式碼大瘦身！)
        for f, p in strong_neg_feats:
            diagnosis_report.append({
                "tag_type": "negative", "dimension": get_dimension_for_feature(f, self.dimension_map),
                "title": get_feature_label(f), "original_setting": f"該特徵拉低了成功率約 {abs(p):.1f}%",
                "suggestion": _generate_advice(f, p, "negative")
            })

        for f, p in weak_feats:
            diagnosis_report.append({
                "tag_type": "warning", "dimension": get_dimension_for_feature(f, self.dimension_map),
                "title": get_feature_label(f), "original_setting": f"該特徵對成功率影響約 {p:+.1f}%",
                "suggestion": _generate_advice(f, p, "warning")
            })

        for f, p in strong_pos_feats:
            diagnosis_report.append({
                "tag_type": "positive", "dimension": get_dimension_for_feature(f, self.dimension_map),
                "title": get_feature_label(f), "original_setting": f"該特徵提升了成功率約 {p:.1f}%",
                "suggestion": _generate_advice(f, p, "positive")
            })

        # 回傳最終打包好的結果
        return {
            "success_rate": score_100,
            "radar_chart_data": radar_chart_data,
            "dimensions_evaluation": dimensions_evaluation,
            "diagnosis_report": diagnosis_report
        }