# 負責載入 joblib、跑 XGBoost 與 SHAP 解釋
import joblib
import shap
import pandas as pd
import numpy as np
from scipy.special import expit
import xgboost as xgb
import os
import json                 
from google import genai     
from services.feature_labels import get_feature_label, get_dimension_for_feature

class MLService:
    def __init__(self, model_path: str = "model_bundle.joblib"):
        try:
            self.bundle = joblib.load(model_path)
            
            self.model = self.bundle["model"]

            self.iso = self.bundle.get("isotonic")
            self.all_features = self.bundle["all_features"]
            self.dimension_map = self.bundle["dimension_map"]

            self.explainer = shap.TreeExplainer(
                self.model, feature_perturbation="tree_path_dependent", model_output="raw"
            )
            self.is_ready = True
            print("✅ 模型載入成功！")
        except Exception as e:
            print(f"⚠️ 模型載入失敗，將啟動 Mock 模式。原因: {e}")
            self.is_ready = False

    def predict_and_format(self, x_row: pd.DataFrame, content_text: str = "") -> dict:
        """
        跑模型預測、計算 SHAP，並將結果轉換為前端要求的 DiagnosisResponse 格式
        """
        if not self.is_ready:
            raise RuntimeError("模型未準備就緒")

        # 記錄這次輸入裡「真的有值」的特徵——還沒被分析出來的（NaN）不該被拿去
        # 生成「強勢特徵」「需優化弱點」這種聽起來很篤定的建議卡片。SHAP 對
        # 缺值算出來的貢獻，只是模型內部學到的「沒資料時的預設分支」反應，
        # 不代表對這個專案的真實判斷，講出來等於是沒根據的斷言。
        known_features = set(x_row.columns[x_row.notna().iloc[0]])

        # 1. 執行推論與 SHAP 解釋 (沿用 colab 中的核心邏輯)
        shap_values = self.explainer.shap_values(x_row)
        base_log_odds = self.explainer.expected_value
        if isinstance(base_log_odds, (list, np.ndarray)):
            base_log_odds = base_log_odds[0]

        feat_shap = shap_values[0]
        total_log_odds = base_log_odds + feat_shap.sum()

        base_prob = float(expit(base_log_odds))
        raw_prob = float(expit(total_log_odds))
        final_prob = float(self.iso.transform([raw_prob])[0]) if self.iso else raw_prob
        score_100 = int(round(final_prob * 100))

        # 計算特徵貢獻百分比
        sum_abs_shap = np.sum(np.abs(feat_shap))
        feature_contrib_pct = (feat_shap / sum_abs_shap) * 100 if sum_abs_shap > 0 else np.zeros_like(feat_shap)

        feature_report = sorted(
            zip(self.all_features, feature_contrib_pct, feat_shap),
            key=lambda t: abs(t[1]), reverse=True,
        )

        # 2. 將 SHAP 維度分數轉換為雷達圖所需的 0-100 分制
        radar_chart_data = {}
        dimensions_evaluation = []

        for dim, feats in self.dimension_map.items():
            idxs = [self.all_features.index(f) for f in feats]
            dim_known = any(f in known_features for f in feats)

            clean_dim_name = dim.split(". ")[-1]  # 移除 "1. ", "2. " 前綴

            if clean_dim_name == "專案屬性":
                continue

            # 改用：將該維度下「有資料的特徵分數」做平均，符合人類直覺
            valid_feature_scores = []
            for f in feats:
                if f in known_features:
                    f_idx = self.all_features.index(f)
                    f_score = min(max(int(70 + (feature_contrib_pct[f_idx] * 2)), 0), 100)
                    valid_feature_scores.append(f_score)
            
            if valid_feature_scores:
                dim_score = int(sum(valid_feature_scores) / len(valid_feature_scores))
            else:
                dim_score = None

            # 這個維度底下全部特徵都還沒被分析（例如「市場契合度(PMF)」目前
            # 唯一的欄位還沒接 Google Trends），就不要顯示一個看起來煞有其事
            # 的分數，回傳 None，讓前端顯示「尚未分析」。
            radar_chart_data[clean_dim_name] = dim_score if dim_known else None

            feature_scores = []
            for f in feats:
                f_idx = self.all_features.index(f)
                f_score = min(max(int(70 + (feature_contrib_pct[f_idx] * 2)), 0), 100)
                feature_scores.append({
                    "feature_name": get_feature_label(f),
                    "score": f_score if f in known_features else None,
                })

            dimensions_evaluation.append({
                "dimension_name": clean_dim_name,
                "score": dim_score if dim_known else None,
                "weight": "",  # 可依實際邏輯調整
                "features": feature_scores
            })

        # 3. 整理正負面特徵為報告卡片——只從「真的有值」的特徵裡挑
        # 貢獻強度分三段：|貢獻| < 1% 算「影響輕微，建議優化」（黃），
        # 其餘依正負號分「強勢特徵」（綠）／「需優化弱點」（紅）
        diagnosis_report = []
        WEAK_CONTRIBUTION_THRESHOLD = 1.0

        strong_pos_feats = [(f, p) for f, p, s in feature_report if s > 0 and f in known_features and abs(p) >= WEAK_CONTRIBUTION_THRESHOLD and get_dimension_for_feature(f, self.dimension_map) != "專案屬性"][:5]
        strong_neg_feats = [(f, p) for f, p, s in feature_report if s < 0 and f in known_features and abs(p) >= WEAK_CONTRIBUTION_THRESHOLD and get_dimension_for_feature(f, self.dimension_map) != "專案屬性"][:5]
        weak_feats = [(f, p) for f, p, s in feature_report if f in known_features and abs(p) < WEAK_CONTRIBUTION_THRESHOLD and get_dimension_for_feature(f, self.dimension_map) != "專案屬性"][:5]

# 初始化 Gemini API (用於動態生成優化建議)
        api_key = os.environ.get("GEMINI_API_KEY", "")
        client = genai.Client(api_key=api_key) if api_key else None
        safe_content = content_text[:2000] if content_text else "使用者未提供文字內容。"

        # 🔴 紅色特徵
        for f, p in strong_neg_feats:
            suggestion_text = "建議針對此項目重新檢視定價或補充相關資料。" 
            feature_name = get_feature_label(f)
            if client:
                prompt = f"""你是專業的群眾募資顧問。本專案的 SHAP 診斷指出「{feature_name}」是一個嚴重的需優化弱點（拉低成功率 {abs(p):.1f}%）。
                    使用者的原始文案如下：
                    {safe_content}
                    請針對「{feature_name}」給出具體的修改指引。回傳 JSON 格式：
                    {{"quote": "引述文案中寫得不好或缺乏該特徵的具體段落。若無原文可引，請直接點出目前的設定狀態",
                     "action": "給出具體且白話的『修改範例』或『執行方向』，不要只說需要優化"}}"""
                try:
                    response = client.models.generate_content(model="gemini-3.5-flash-lite", contents=prompt, config=genai.types.GenerateContentConfig(response_mime_type="application/json", temperature=0.2))
                    res_data = json.loads(response.text.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip())
                    suggestion_text = f"【需修改出處】：『{res_data.get('quote', '')}』\n【行動指引】：{res_data.get('action', '')}"
                except Exception as e: pass

            diagnosis_report.append({
                "tag_type": "negative",
                "dimension": get_dimension_for_feature(f, self.dimension_map),
                "title": feature_name, # 移除「需優化弱點：」前綴
                "original_setting": f"該特徵拉低了成功率約 {abs(p):.1f}%",
                "suggestion": suggestion_text
            })

        # 🟡 黃色特徵
        for f, p in weak_feats:
            suggestion_text = "此項目目前影響有限，若有餘力可作為次要優化項目。" 
            feature_name = get_feature_label(f)
            if client:
                prompt = f"""你是專業的群眾募資顧問。本專案的 SHAP 診斷指出「{feature_name}」是一個影響輕微的次要優化項目（影響 {p:+.1f}%）。
                        使用者的原始文案如下：
                        {safe_content}
                        請回傳 JSON 格式：
                        {{"quote": "引述文案中可微調的具體段落",
                         "action": "給出具體微調指引，當作『若有餘力時的加分項目』來建議"}}"""
                try:
                    response = client.models.generate_content(model="gemini-3.5-flash-lite", contents=prompt, config=genai.types.GenerateContentConfig(response_mime_type="application/json", temperature=0.2))
                    res_data = json.loads(response.text.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip())
                    suggestion_text = f"【可優化出處】：『{res_data.get('quote', '')}』\n【微調指引】：{res_data.get('action', '')}"
                except Exception as e: pass

            diagnosis_report.append({
                "tag_type": "warning",
                "dimension": get_dimension_for_feature(f, self.dimension_map),
                "title": feature_name, # 移除「影響輕微：」前綴
                "original_setting": f"該特徵對成功率影響約 {p:+.1f}%",
                "suggestion": suggestion_text
            })

        # 🟢 綠色特徵
        for f, p in strong_pos_feats:
            suggestion_text = "此項目表現極佳，請繼續保持並在行銷上放大此優勢！"
            feature_name = get_feature_label(f)
            if client:
                prompt = f"""你是專業的群眾募資顧問。本專案的 SHAP 診斷指出「{feature_name}」是一個強勢加分特徵（提升成功率 {p:.1f}%）。
                        使用者的原始文案如下：
                        {safe_content}
                        請針對「{feature_name}」給出說明。回傳 JSON 格式：
                        {{"quote": "引述文案中做得很好的具體段落。若無原文可引述，直接點出目前的良好狀態",
                         "action": "具體說明為什麼這個特徵對群眾募資是好的，並建議如何在行銷上放大這個優勢"}}"""
                try:
                    response = client.models.generate_content(model="gemini-3.5-flash-lite", contents=prompt, config=genai.types.GenerateContentConfig(response_mime_type="application/json", temperature=0.2))
                    res_data = json.loads(response.text.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip())
                    suggestion_text = f"【優勢出處】：『{res_data.get('quote', '')}』\n【放大優勢】：{res_data.get('action', '')}"
                except Exception as e: pass

            diagnosis_report.append({
                "tag_type": "positive",
                "dimension": get_dimension_for_feature(f, self.dimension_map),
                "title": feature_name, # 移除「強勢特徵：」前綴
                "original_setting": f"該特徵提升了成功率約 {p:.1f}%",
                "suggestion": suggestion_text
            })

        return {
                    "success_rate": score_100,
                    "radar_chart_data": radar_chart_data,
                    "dimensions_evaluation": dimensions_evaluation,
                    "diagnosis_report": diagnosis_report
        }